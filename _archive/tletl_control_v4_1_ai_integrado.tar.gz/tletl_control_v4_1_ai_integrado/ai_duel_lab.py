#!/usr/bin/env python3
import argparse
from pathlib import Path

import cv2
import mediapipe as mp

from tletl_control.ai_bank import append_sample, load_samples, count_by_label
from tletl_control.ai_classifier import KNNGestureClassifier
from tletl_control.ai_critic import GestureCritic
from tletl_control.features import extract_features
from tletl_control.geometry import points_from_landmarks
from tletl_control.ui import draw_text_box


KEY_TO_LABEL = {
    ord("1"): "OPEN_PALM",
    ord("2"): "FIST",
    ord("3"): "POINT",
    ord("4"): "VICTORY",
    ord("5"): "PINCH",
    ord("6"): "THREE",
    ord("7"): "NEUTRAL",
}

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


def open_camera(camera, width, height, fps):
    cap = cv2.VideoCapture(camera)
    if not cap.isOpened():
        raise RuntimeError(f"No pude abrir cámara {camera}. Prueba --camera 1.")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def counts_line(counts):
    order = ["OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"]
    return " | ".join(f"{g}:{counts.get(g,0)}" for g in order)


def main():
    ap = argparse.ArgumentParser(description="Tletl AI Duel Lab V4.5")
    ap.add_argument("--dataset", default="tletl_gesture_bank.jsonl")
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--det-conf", type=float, default=0.50)
    ap.add_argument("--track-conf", type=float, default=0.50)
    ap.add_argument("--k", type=int, default=21)
    ap.add_argument("--critic-min-conf", type=float, default=0.80)
    ap.add_argument("--save-easy", action="store_true", help="También permite guardar casos fáciles con SPACE.")
    args = ap.parse_args()

    dataset_path = Path(args.dataset).expanduser().resolve()

    rows = load_samples(dataset_path)
    clf = KNNGestureClassifier(k=args.k)
    clf.fit(rows)

    critic = GestureCritic(min_conf=args.critic_min_conf, cooldown_frames=5)

    cap = open_camera(args.camera, args.width, args.height, args.fps)

    last_saved = "-"
    selected = "FIST"
    last_decision = None

    print("[TLETL AI DUEL LAB]")
    print("La IA principal predice. La IA crítica busca casos difíciles.")
    print("Cuando te pregunte, presiona la etiqueta correcta:")
    print("1 palma | 2 puño | 3 índice | 4 victoria | 5 pinza | 6 tres | 7 neutral | SPACE guardar seleccionada | Q salir")

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=1,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands:
        while True:
            ok, frame = cap.read()
            if not ok:
                break

            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = hands.process(rgb)

            features = None
            pred, conf, info = "NO_HAND", 0.0, {}
            decision = None

            if result.multi_hand_landmarks:
                hand_landmarks = result.multi_hand_landmarks[0]
                points = points_from_landmarks(hand_landmarks)
                features = extract_features(points)
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                if clf.ready():
                    pred, conf, info = clf.predict(features)
                    decision = critic.evaluate(pred, conf, info)
                    if decision.should_ask:
                        last_decision = decision
                else:
                    pred, conf, info = "UNKNOWN", 0.0, {"reason": "dataset insuficiente"}

            rows = load_samples(dataset_path)
            counts = count_by_label(rows)

            votes = info.get("votes", {}) if isinstance(info, dict) else {}
            specialist = info.get("specialist", "-") if isinstance(info, dict) else "-"
            reason = info.get("reason", "") if isinstance(info, dict) else ""

            if last_decision and last_decision.should_ask:
                ask = "CRÍTICO: CASO DIFÍCIL. Etiquetas posibles: " + ", ".join(last_decision.suggested_labels)
                ask2 = "Presiona la tecla REAL del gesto. No la que dijo la IA."
                priority = last_decision.priority
                critic_reason = last_decision.reason
            else:
                ask = "Crítico: sin caso difícil ahora."
                ask2 = "Mueve la mano en fronteras raras para buscar errores útiles."
                priority = 0
                critic_reason = "-"

            lines = [
                "TLETL V4.5 AI DUEL LAB",
                f"Predicción IA: {pred} | Conf: {conf:.2f} | Especialista: {specialist}",
                f"Crítico prioridad: {priority} | Razón: {critic_reason}",
                ask,
                ask2,
                f"Votos: {votes} | Raw reason: {reason}",
                counts_line(counts),
                f"Seleccionada: {selected} | Último guardado: {last_saved}",
                "1 palma 2 puño 3 índice 4 victoria 5 pinza 6 tres 7 neutral | SPACE guardar | Q salir",
            ]

            if features is None:
                lines.append("No veo mano completa.")

            draw_text_box(frame, lines, font_scale=0.42)
            cv2.imshow("Tletl AI Duel Lab V4.5", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break

            if key in KEY_TO_LABEL:
                selected = KEY_TO_LABEL[key]
                if features is not None:
                    hard = bool(last_decision and last_decision.should_ask)
                    append_sample(dataset_path, selected, features, meta={
                        "source": "ai-duel-lab",
                        "teacher": "critic",
                        "hard": hard,
                        "pred": pred,
                        "conf": conf,
                        "critic_reason": last_decision.reason if last_decision else "",
                        "critic_suggestions": last_decision.suggested_labels if last_decision else [],
                        "votes": votes,
                        "specialist": specialist,
                    })
                    rows = load_samples(dataset_path)
                    clf.fit(rows)
                    last_saved = f"{selected} | pred={pred} | hard={hard}"
                    last_decision = None
                    print("[OK]", last_saved)

            elif key == 32 and features is not None and (args.save_easy or (last_decision and last_decision.should_ask)):
                append_sample(dataset_path, selected, features, meta={
                    "source": "ai-duel-lab-space",
                    "teacher": "critic",
                    "hard": bool(last_decision and last_decision.should_ask),
                    "pred": pred,
                    "conf": conf,
                    "critic_reason": last_decision.reason if last_decision else "",
                    "critic_suggestions": last_decision.suggested_labels if last_decision else [],
                    "votes": votes,
                    "specialist": specialist,
                })
                rows = load_samples(dataset_path)
                clf.fit(rows)
                last_saved = f"{selected} manual | pred={pred}"
                last_decision = None
                print("[OK]", last_saved)

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
