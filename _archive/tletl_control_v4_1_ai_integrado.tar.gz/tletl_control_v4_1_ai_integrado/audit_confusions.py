#!/usr/bin/env python3
from pathlib import Path
import argparse
import json
from collections import Counter, defaultdict


def main():
    ap = argparse.ArgumentParser(description="Auditar muestras difíciles de Tletl.")
    ap.add_argument("--dataset", default="tletl_gesture_bank.jsonl")
    args = ap.parse_args()

    p = Path(args.dataset)
    if not p.exists():
        print("No existe:", p)
        return

    rows = []
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except Exception:
            pass

    counts = Counter(row.get("label", "UNKNOWN") for row in rows)
    print("=== Conteos ===")
    for k in sorted(counts):
        print(f"{k}: {counts[k]}")
    print("TOTAL:", sum(counts.values()))

    hard_counts = Counter()
    pair_counts = Counter()
    source_counts = Counter()

    for row in rows:
        label = row.get("label", "UNKNOWN")
        meta = row.get("meta", {}) or {}
        source = meta.get("source", "unknown")
        source_counts[source] += 1

        pred = meta.get("pred")
        hard = meta.get("hard", False)
        if hard:
            hard_counts[label] += 1
        if pred and pred != label:
            pair_counts[(pred, label)] += 1

    print("\n=== Fuentes ===")
    for src, n in source_counts.most_common():
        print(f"{src}: {n}")

    print("\n=== Muestras difíciles por etiqueta ===")
    for label, n in hard_counts.most_common():
        print(f"{label}: {n}")

    print("\n=== Confusiones corregidas pred -> real ===")
    for (pred, real), n in pair_counts.most_common(20):
        print(f"{pred} -> {real}: {n}")

    print("\nConsejo:")
    print("- Si una confusión sale mucho, entrena justo esa frontera con ai_duel_lab.py.")
    print("- Si PINCH aparece como predicción equivocada muchas veces, mantén PINCH más estricta.")


if __name__ == "__main__":
    main()
