# Tletl Control V4 Modular

Esta versión separa Tletl Control en capas para que sea más estable y mantenible.

## Capas

```text
main.py
└── tletl_control/
    ├── cli.py          # argumentos
    ├── app.py          # orquestador principal
    ├── vision.py       # cámara + MediaPipe
    ├── gestures.py     # reglas de gestos
    ├── profile.py      # perfil calibrado + aprendizaje adaptativo
    ├── filters.py      # suavizado, swipes, timers, cursor
    ├── low_light.py    # mejora de baja luz
    ├── actions.py      # ydotool
    ├── ui.py           # ventanas y texto
    ├── features.py     # extracción de features
    ├── geometry.py     # puntos/distancias
    └── constants.py    # configuración base
```

## Instalar

```bash
cd ~/Documentos/tletl_control_v3
source .venv/bin/activate
pip install opencv-python mediapipe numpy
```

Copia o descomprime esta carpeta ahí.

## Probar seguro

```bash
export YDOTOOL_SOCKET=/tmp/.ydotool_socket
python main.py --profile tletl_profile_v3_4.json --dry-run --width 640 --height 480 --det-conf 0.50 --track-conf 0.50
```

## Ejecutar normal

```bash
export YDOTOOL_SOCKET=/tmp/.ydotool_socket
python main.py --profile tletl_profile_v3_4.json --width 640 --height 480 --det-conf 0.50 --track-conf 0.50
```

## Si falla la ventana extra

```bash
python main.py --profile tletl_profile_v3_4.json --status-backend cv2
```

o:

```bash
python main.py --profile tletl_profile_v3_4.json --no-status-window
```

## Limpiar aprendizaje adaptativo

```bash
rm tletl_adaptive_memory_v4.json
```

## Modos

- NAVEGADOR
- CURSOR
- VENTANAS
- SISTEMA

Cambias de modo con tres dedos sostenidos. Puño apaga por emergencia.


---

# V4.1 IA integrada

Esta versión ya conecta una IA ligera k-NN al detector principal.

## Crear banco de gestos

```bash
python main.py --collect-gestures --ai-dataset tletl_gesture_bank.jsonl --width 640 --height 480 --det-conf 0.50 --track-conf 0.50
```

Teclas:

```text
1 = OPEN_PALM
2 = FIST
3 = POINT
4 = VICTORY
5 = PINCH
6 = THREE
7 = NEUTRAL
SPACE = guardar muestra
A = autoguardar
Q = salir
```

## Probar Tletl con IA en dry-run

```bash
export YDOTOOL_SOCKET=/tmp/.ydotool_socket
python main.py --ai --ai-dataset tletl_gesture_bank.jsonl --profile ~/Documentos/tletl_control_v3/tletl_profile_v3_4.json --dry-run --width 640 --height 480 --det-conf 0.50 --track-conf 0.50
```

## Ejecutar normal con IA

```bash
export YDOTOOL_SOCKET=/tmp/.ydotool_socket
python main.py --ai --ai-dataset tletl_gesture_bank.jsonl --profile ~/Documentos/tletl_control_v3/tletl_profile_v3_4.json --width 640 --height 480 --det-conf 0.50 --track-conf 0.50
```

## Corregir mientras usas Tletl

Durante ejecución con `--ai`, si detecta mal un gesto, presiona:

```text
1 = era palma
2 = era puño
3 = era índice
4 = era victoria
5 = era pinza
6 = eran tres dedos
7 = era neutral
```

Eso guarda una corrección en el banco y la IA se actualiza en caliente.

## Recomendación de muestras

Primera ronda:

```text
30 muestras por gesto
```

Ronda decente:

```text
100 muestras por gesto
```

Ronda buena:

```text
200+ muestras por gesto
```

Graba con variaciones: cerca, lejos, izquierda, derecha, arriba, abajo, buena luz, baja luz, lento y rápido.
