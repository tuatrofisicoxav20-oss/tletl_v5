#!/usr/bin/env python3
"""
Tletl V4.7.1 - Backfill de orientación desde landmarks.

Lee un banco JSONL y, si cada muestra conserva landmarks de MediaPipe,
calcula las 13 features de orientación y escribe un banco nuevo.

Si el banco solo tiene features ya procesadas y NO guarda landmarks, no inventa datos.
Porque inventar datos de entrenamiento es entrenar una IA para mentirte con confianza,
la tradición favorita de la civilización digital.

Uso:
  python tools/tletl_orientation_backfill.py datasets/tletl_gesture_bank_v2_features.jsonl \
    --out datasets/tletl_gesture_bank_v47_orientation.jsonl
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from tletl_control.hand_orientation import ORIENTATION_FEATURE_KEYS, extract_orientation_features, has_orientation_features
except Exception as exc:  # pragma: no cover
    raise SystemExit(
        "[ERROR] No pude importar tletl_control.hand_orientation. "
        "Primero aplica el parche V4.7 Orientation. Detalle: " + str(exc)
    )


LANDMARK_CONTAINER_KEYS = (
    "landmarks",
    "points",
    "lm",
    "hand_landmarks",
    "raw_landmarks",
    "mediapipe_landmarks",
    "normalized_landmarks",
)

NESTED_KEYS = (
    "hand",
    "sample",
    "data",
    "raw",
    "input",
    "observation",
    "mediapipe",
)

HANDEDNESS_KEYS = (
    "handedness",
    "mp_handedness",
    "hand_label",
    "hand",
    "side",
    "label_handedness",
)


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def _point_like(item: Any) -> bool:
    if hasattr(item, "x") and hasattr(item, "y"):
        return True
    if isinstance(item, dict):
        return "x" in item and "y" in item
    if isinstance(item, (list, tuple)):
        return len(item) >= 2 and _is_number(item[0]) and _is_number(item[1])
    return False


def _landmarks_like(value: Any) -> bool:
    if hasattr(value, "landmark"):
        value = value.landmark
    if isinstance(value, dict) and isinstance(value.get("landmark"), list):
        value = value["landmark"]
    if not isinstance(value, list) or len(value) < 21:
        return False
    return all(_point_like(p) for p in value[:21])


def _find_landmarks_direct(obj: Any) -> Optional[Any]:
    if _landmarks_like(obj):
        if isinstance(obj, dict) and "landmark" in obj:
            return obj["landmark"]
        return obj
    if not isinstance(obj, dict):
        return None

    for key in LANDMARK_CONTAINER_KEYS:
        value = obj.get(key)
        if _landmarks_like(value):
            if isinstance(value, dict) and "landmark" in value:
                return value["landmark"]
            return value
    return None


def _find_landmarks_nested(row: Dict[str, Any]) -> Optional[Any]:
    direct = _find_landmarks_direct(row)
    if direct is not None:
        return direct

    for key in NESTED_KEYS:
        value = row.get(key)
        if isinstance(value, dict):
            found = _find_landmarks_direct(value)
            if found is not None:
                return found

    # Último intento: buscar un nivel más abajo sin hacer una expedición arqueológica infinita.
    for value in row.values():
        if isinstance(value, dict):
            for subvalue in value.values():
                found = _find_landmarks_direct(subvalue)
                if found is not None:
                    return found
    return None


def _landmarks_from_flat_keys(row: Dict[str, Any]) -> Optional[list[dict[str, float]]]:
    """Reconstruye landmarks si están guardados como lm_0_x, landmark_0_y, etc."""
    places = []
    features = row.get("features")
    if isinstance(features, dict):
        places.append(features)
    places.append(row)

    patterns = [
        ("lm_{i}_{axis}",),
        ("landmark_{i}_{axis}",),
        ("p{i}_{axis}",),
        ("{axis}{i}",),
    ]

    for source in places:
        for pattern_group in patterns:
            pts = []
            ok = True
            for i in range(21):
                p = {}
                for axis in ("x", "y", "z"):
                    found = None
                    for pat in pattern_group:
                        key = pat.format(i=i, axis=axis)
                        if _is_number(source.get(key)):
                            found = float(source[key])
                            break
                    if found is None:
                        if axis == "z":
                            found = 0.0
                        else:
                            ok = False
                            break
                    p[axis] = found
                if not ok:
                    break
                pts.append(p)
            if ok and len(pts) == 21:
                return pts
    return None


def find_landmarks(row: Dict[str, Any]) -> Optional[Any]:
    return _find_landmarks_nested(row) or _landmarks_from_flat_keys(row)


def get_handedness(row: Dict[str, Any]) -> Optional[str]:
    for key in HANDEDNESS_KEYS:
        value = row.get(key)
        if isinstance(value, str) and value.lower() in {"left", "right"}:
            return value
    meta = row.get("meta")
    if isinstance(meta, dict):
        for key in HANDEDNESS_KEYS:
            value = meta.get(key)
            if isinstance(value, str) and value.lower() in {"left", "right"}:
                return value
    return None


def get_features_container(row: Dict[str, Any]) -> Tuple[Dict[str, Any], str]:
    features = row.get("features")
    if isinstance(features, dict):
        return features, "nested"
    return row, "root"


def get_label(row: Dict[str, Any]) -> str:
    for key in ("label", "gesture", "target", "y", "class"):
        value = row.get(key)
        if value:
            return str(value)
    return "UNKNOWN"


def default_out_path(input_path: Path) -> Path:
    return input_path.with_name(input_path.stem + "_v47_orientation.jsonl")


def backfill(input_path: Path, output_path: Path, force: bool = False, keep_bad: bool = True) -> Dict[str, Any]:
    stats = Counter()
    by_label = Counter()
    enriched_by_label = Counter()

    output_path.parent.mkdir(parents=True, exist_ok=True)

    with input_path.open("r", encoding="utf-8") as src, output_path.open("w", encoding="utf-8") as dst:
        for line_no, line in enumerate(src, 1):
            raw = line.strip()
            if not raw:
                continue
            try:
                row = json.loads(raw)
                if not isinstance(row, dict):
                    raise ValueError("la línea no es objeto JSON")
            except Exception:
                stats["bad_lines"] += 1
                if keep_bad:
                    dst.write(line if line.endswith("\n") else line + "\n")
                continue

            stats["total"] += 1
            label = get_label(row)
            by_label[label] += 1
            features, mode = get_features_container(row)

            if has_orientation_features(features, strict=True) and not force:
                stats["already_full"] += 1
                dst.write(json.dumps(row, ensure_ascii=False) + "\n")
                continue

            landmarks = find_landmarks(row)
            if landmarks is None:
                stats["missing_landmarks"] += 1
                dst.write(json.dumps(row, ensure_ascii=False) + "\n")
                continue

            try:
                orientation = extract_orientation_features(landmarks, get_handedness(row))
                if not orientation or not all(k in orientation for k in ORIENTATION_FEATURE_KEYS):
                    raise ValueError("orientación incompleta")
            except Exception:
                stats["orientation_errors"] += 1
                dst.write(json.dumps(row, ensure_ascii=False) + "\n")
                continue

            features.update(orientation)
            if mode == "nested":
                row["features"] = features
            else:
                row.update(orientation)
            stats["enriched"] += 1
            enriched_by_label[label] += 1
            dst.write(json.dumps(row, ensure_ascii=False) + "\n")

    return {
        "input": str(input_path),
        "output": str(output_path),
        "stats": dict(stats),
        "by_label": dict(by_label),
        "enriched_by_label": dict(enriched_by_label),
    }


def print_report(report: Dict[str, Any]) -> None:
    stats = Counter(report["stats"])
    total = stats.get("total", 0)
    enriched = stats.get("enriched", 0)
    already = stats.get("already_full", 0)
    missing = stats.get("missing_landmarks", 0)
    errors = stats.get("orientation_errors", 0)
    bad = stats.get("bad_lines", 0)

    print("\nTLETL V4.7.1 ORIENTATION BACKFILL")
    print("=" * 48)
    print(f"Entrada: {report['input']}")
    print(f"Salida:  {report['output']}")
    print(f"Total: {total} | enriquecidas: {enriched} | ya completas: {already}")
    print(f"Sin landmarks: {missing} | errores orientación: {errors} | líneas malas: {bad}")

    if report.get("enriched_by_label"):
        print("\nEnriquecidas por gesto:")
        for label, count in sorted(report["enriched_by_label"].items()):
            print(f"  {label:12s} {count:5d}")

    print("\nLectura honesta:")
    if enriched > 0:
        print("- Sí se pudo calcular orientación desde landmarks guardados.")
        print("- Ahora corre coverage sobre el archivo de salida y, si sale bien, úsalo como banco V4.7.")
    elif total > 0 and missing >= total - already:
        print("- Este banco NO guarda landmarks. No hay de dónde reconstruir orientación real.")
        print("- Toca recapturar muestras o modificar el capturador para guardar landmarks/features V4.7 desde ahora.")
    else:
        print("- No se enriqueció nada. Revisa el schema del JSONL; puede tener landmarks con otro nombre raro, porque claro, nombrar cosas bien era demasiado pedir.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("bank", type=Path, help="Banco JSONL de entrada")
    parser.add_argument("--out", type=Path, default=None, help="Banco JSONL de salida")
    parser.add_argument("--force", action="store_true", help="Recalcula aunque ya existan features de orientación")
    parser.add_argument("--no-keep-bad", action="store_true", help="No conserva líneas JSON malas")
    args = parser.parse_args()

    input_path = args.bank.expanduser().resolve()
    if not input_path.exists():
        raise SystemExit(f"[ERROR] No existe banco: {input_path}")
    output_path = args.out.expanduser().resolve() if args.out else default_out_path(input_path)

    report = backfill(input_path, output_path, force=args.force, keep_bad=not args.no_keep_bad)
    print_report(report)


if __name__ == "__main__":
    main()
