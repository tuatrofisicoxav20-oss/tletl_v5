#!/usr/bin/env python3
from __future__ import annotations

# --- TLETL PROJECT ROOT IMPORT FIX ---
from pathlib import Path as _TletlPath
import sys as _tletl_sys
_TLETL_PROJECT_ROOT = _TletlPath(__file__).resolve().parents[1]
if str(_TLETL_PROJECT_ROOT) not in _tletl_sys.path:
    _tletl_sys.path.insert(0, str(_TLETL_PROJECT_ROOT))
# --- END TLETL PROJECT ROOT IMPORT FIX ---

import argparse
import json
import os
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Tletl V4.7 runtime check")
    parser.add_argument("--bank", default="datasets/tletl_gesture_bank_v2_features.jsonl")
    args = parser.parse_args()

    bank = Path(args.bank).expanduser().resolve()
    os.environ["TLETL_AI_V47_BANK"] = str(bank)

    print("TLETL V4.7.3 LIVE AI RUNTIME CHECK")
    print("=" * 42)
    print(f"Python: {sys.version.split()[0]}")
    print(f"Banco:  {bank}")

    try:
        from tletl_control.ai_runtime_v47_live import get_live_runtime_v47
        rt = get_live_runtime_v47()
        info = rt.info()
    except Exception as exc:
        print(f"ERROR cargando runtime: {exc}")
        return 2

    print("\nRuntime:")
    print(json.dumps(info, indent=2, ensure_ascii=False))

    gestures = info.get("gestures", {})
    missing = [g for g in ["OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"] if int(gestures.get(g, 0)) <= 0]
    if missing:
        print(f"\nERROR: faltan gestos en banco: {missing}")
        return 3

    if int(info.get("feature_keys", 0)) < 12:
        print("\nERROR: muy pocas features útiles. Algo raro pasó con el banco o el extractor.")
        return 4

    print("\nOK: runtime listo para interfaz.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
