#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

LABEL_KEYS = ("label", "gesture", "target", "class", "y")
NON_FEATURE_KEYS = set(LABEL_KEYS) | {
    "timestamp", "time", "created_at", "source", "orientation", "bucket", "handedness", "score",
    "landmarks", "raw_landmarks", "hand_landmarks", "features",
}
ORIENTATION_KEYS = {
    "palm_normal_x", "palm_normal_y", "palm_normal_z", "palm_roll", "palm_yaw", "palm_pitch",
    "palm_facing_score", "back_hand_score", "side_hand_score", "palm_flatness_score",
    "wrist_depth_score", "thumb_side_score", "finger_depth_spread",
}


def get_label(obj: dict) -> str | None:
    for k in LABEL_KEYS:
        v = obj.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip().upper()
    return None


def get_features(obj: dict) -> dict[str, float]:
    src = obj.get("features") if isinstance(obj.get("features"), dict) else obj
    out: dict[str, float] = {}
    for k, v in src.items():
        if k in NON_FEATURE_KEYS:
            continue
        if isinstance(v, (int, float)):
            out[k] = float(v)
    return out


def orientation_bucket(feat: dict[str, float]) -> str:
    pf = float(feat.get("palm_facing_score", 0.0))
    bh = float(feat.get("back_hand_score", 0.0))
    sh = float(feat.get("side_hand_score", 0.0))
    if sh >= max(pf, bh) and sh > 0.40:
        return "SIDE_HAND"
    if bh >= pf and bh > 0.35:
        return "BACK_HAND"
    if pf > 0.35:
        return "PALM_FRONT"
    return "UNKNOWN"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bank", required=True)
    args = ap.parse_args()
    path = Path(args.bank).expanduser().resolve()
    counts = Counter()
    buckets = Counter()
    feature_counts = Counter()
    bad = 0
    total = 0
    full_orientation = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except Exception:
            bad += 1
            continue
        label = get_label(obj) or "UNKNOWN"
        feat = get_features(obj)
        total += 1
        counts[label] += 1
        if ORIENTATION_KEYS.issubset(set(feat)):
            full_orientation += 1
        buckets[(label, orientation_bucket(feat))] += 1
        for k in feat:
            feature_counts[k] += 1
    useful = sum(1 for _, c in feature_counts.items() if c >= max(5, int(total * 0.25)))
    print("TLETL V4.8 BANK PROBE")
    print("=====================")
    print(f"Banco: {path}")
    print(f"Total: {total} | malas: {bad} | orientación completa: {full_orientation}/{total}")
    print(f"Features útiles aproximadas: {useful}")
    print(f"Conteo: {dict(counts)}")
    print("Buckets:")
    for label in sorted(counts):
        parts = {b: buckets[(label, b)] for b in ["PALM_FRONT", "BACK_HAND", "SIDE_HAND", "UNKNOWN"] if buckets[(label, b)]}
        print(f"  {label:10s} {parts}")
    if total == 0:
        print("ERROR: banco vacío.")
        return 2
    if full_orientation != total:
        print("AVISO: no todo tiene orientación completa.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
