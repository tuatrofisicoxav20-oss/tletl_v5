#!/usr/bin/env python3
from __future__ import annotations

# --- TLETL PROJECT ROOT IMPORT FIX ---
from pathlib import Path as _TletlPath
import sys as _tletl_sys
_TLETL_PROJECT_ROOT = _TletlPath(__file__).resolve().parents[1]
if str(_TLETL_PROJECT_ROOT) not in _tletl_sys.path:
    _tletl_sys.path.insert(0, str(_TLETL_PROJECT_ROOT))
# --- END TLETL PROJECT ROOT IMPORT FIX ---

import argparse
import json
import os
import random
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

from tletl_control.ai_runtime_v47_live import RobustKNNBankClassifier, _extract_label, _flatten_features

ORDER = ["OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"]


def read_samples(path: Path) -> List[Tuple[str, Dict[str, float], str]]:
    out = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        raw = line.strip()
        if not raw:
            continue
        try:
            obj = json.loads(raw)
        except Exception:
            continue
        if not isinstance(obj, Mapping):
            continue
        label = _extract_label(obj)
        feats = _flatten_features(obj)
        if label and len(feats) >= 8:
            out.append((label, feats, raw))
    return out


def write_bank(lines: List[str]) -> Path:
    tmp = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False, encoding="utf-8")
    with tmp:
        for line in lines:
            tmp.write(line.rstrip() + "\n")
    return Path(tmp.name)


def main() -> int:
    ap = argparse.ArgumentParser(description="Autoprueba del banco V4.7 con split train/test")
    ap.add_argument("--bank", default="datasets/tletl_gesture_bank_v2_features.jsonl")
    ap.add_argument("--seed", type=int, default=47)
    ap.add_argument("--test-ratio", type=float, default=0.22)
    args = ap.parse_args()

    bank = Path(args.bank).expanduser().resolve()
    samples = read_samples(bank)
    by_label = defaultdict(list)
    for label, feats, raw in samples:
        by_label[label].append((label, feats, raw))

    print("TLETL V4.7.3 BANK SELFTEST")
    print("=" * 36)
    print(f"Banco: {bank}")
    print(f"Muestras válidas: {len(samples)}")
    print("Conteo:", dict(Counter(label for label, _, _ in samples)))

    rng = random.Random(args.seed)
    train_lines: List[str] = []
    test: List[Tuple[str, Dict[str, float]]] = []

    for label in ORDER:
        group = list(by_label.get(label, []))
        rng.shuffle(group)
        if len(group) < 10:
            print(f"ERROR: muy pocas muestras para {label}: {len(group)}")
            return 2
        n_test = max(5, int(len(group) * args.test_ratio))
        test.extend((lab, feats) for lab, feats, raw in group[:n_test])
        train_lines.extend(raw for lab, feats, raw in group[n_test:])

    tmp_bank = write_bank(train_lines)
    try:
        clf = RobustKNNBankClassifier(tmp_bank)
        cm = {a: Counter() for a in ORDER}
        correct = 0
        tested = 0
        low_margin = 0
        for true, feats in test:
            pred = clf.predict(feats)
            got = pred.get("gesture", "NEUTRAL")
            cm[true][got] += 1
            correct += int(got == true)
            tested += 1
            if float(pred.get("margin", 0.0)) < 0.10:
                low_margin += 1
    finally:
        try:
            tmp_bank.unlink()
        except Exception:
            pass

    acc = correct / max(tested, 1)
    print(f"\nAccuracy holdout: {acc*100:.2f}% ({correct}/{tested})")
    print(f"Predicciones de bajo margen: {low_margin}/{tested}")
    print("\nMatriz de confusión:")
    header = "true\\pred".ljust(12) + " ".join(g[:7].rjust(8) for g in ORDER)
    print(header)
    for true in ORDER:
        row = true.ljust(12)
        for pred in ORDER:
            row += str(cm[true][pred]).rjust(8)
        print(row)

    if acc < 0.82:
        print("\nLECTURA: El banco o el extractor todavía producen clases mezcladas. No culpes a la UI todavía.")
        return 3
    if low_margin / max(tested, 1) > 0.35:
        print("\nLECTURA: Accuracy aceptable, pero margen bajo. El crítico debe bloquear más o falta balance lateral.")
    else:
        print("\nOK: Banco razonablemente separable. Si en vivo falla, el problema es runtime/iluminación/acciones.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
