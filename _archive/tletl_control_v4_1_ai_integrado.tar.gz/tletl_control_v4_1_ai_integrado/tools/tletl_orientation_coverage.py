#!/usr/bin/env python3
"""
Analizador de cobertura de orientación para bancos Tletl JSONL.

Uso:
  python tools/tletl_orientation_coverage.py datasets/tletl_gesture_bank_v2_features.jsonl
  python tools/tletl_orientation_coverage.py tletl_gesture_bank.jsonl --json report.json

Soporta muestras tipo:
  {"label": "PINCH", "features": {...}}
  {"gesture": "PINCH", "features": {...}}
  {"y": "PINCH", ...features al nivel raíz...}
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, Optional


ORIENTATION_KEYS = [
    "palm_normal_x",
    "palm_normal_y",
    "palm_normal_z",
    "palm_roll",
    "palm_yaw",
    "palm_pitch",
    "palm_facing_score",
    "back_hand_score",
    "side_hand_score",
    "palm_flatness_score",
    "wrist_depth_score",
    "thumb_side_score",
    "finger_depth_spread",
]


def get_label(row: Dict[str, Any]) -> str:
    for key in ("label", "gesture", "target", "y", "class"):
        if row.get(key):
            return str(row[key])
    return "UNKNOWN"


def get_features(row: Dict[str, Any]) -> Dict[str, Any]:
    features = row.get("features")
    if isinstance(features, dict):
        return features
    return {k: v for k, v in row.items() if isinstance(v, (int, float))}


def orientation_bucket(features: Dict[str, Any]) -> str:
    palm = float(features.get("palm_facing_score", 0.0) or 0.0)
    back = float(features.get("back_hand_score", 0.0) or 0.0)
    side = float(features.get("side_hand_score", 0.0) or 0.0)
    if not any(k in features for k in ORIENTATION_KEYS):
        return "MISSING"
    if side >= 0.64 and side >= palm * 0.90 and side >= back * 0.90:
        return "SIDE_HAND"
    if palm >= back:
        return "PALM_FRONT"
    return "BACK_HAND"


def mean(values: Iterable[float]) -> Optional[float]:
    vals = [float(v) for v in values if isinstance(v, (int, float))]
    if not vals:
        return None
    return sum(vals) / len(vals)


def pct(num: int, den: int) -> float:
    return 100.0 * num / max(den, 1)


def analyze(path: Path) -> Dict[str, Any]:
    total = 0
    full = 0
    partial = 0
    missing = 0
    labels = Counter()
    full_by_label = Counter()
    orientation_by_label = defaultdict(Counter)
    feature_values = defaultdict(lambda: defaultdict(list))
    bad_lines = 0

    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except Exception:
                bad_lines += 1
                continue

            total += 1
            label = get_label(row)
            features = get_features(row)
            labels[label] += 1

            present = [k for k in ORIENTATION_KEYS if k in features and isinstance(features.get(k), (int, float))]
            if len(present) == len(ORIENTATION_KEYS):
                full += 1
                full_by_label[label] += 1
            elif present:
                partial += 1
            else:
                missing += 1

            bucket = orientation_bucket(features)
            orientation_by_label[label][bucket] += 1

            for k in ORIENTATION_KEYS:
                v = features.get(k)
                if isinstance(v, (int, float)):
                    feature_values[label][k].append(float(v))

    per_label = {}
    for label, n in labels.items():
        means = {}
        for key, vals in feature_values[label].items():
            m = mean(vals)
            if m is not None:
                means[key] = round(m, 4)
        per_label[label] = {
            "total": n,
            "full_orientation": full_by_label[label],
            "coverage_pct": round(pct(full_by_label[label], n), 2),
            "orientation_buckets": dict(orientation_by_label[label]),
            "means": means,
        }

    return {
        "file": str(path),
        "total": total,
        "bad_lines": bad_lines,
        "full_orientation": full,
        "partial_orientation": partial,
        "missing_orientation": missing,
        "coverage_pct": round(pct(full, total), 2),
        "labels": dict(labels),
        "per_label": per_label,
    }


def print_report(report: Dict[str, Any]) -> None:
    print("\nTLETL V4.7 ORIENTATION COVERAGE")
    print("=" * 44)
    print(f"Archivo: {report['file']}")
    print(f"Total: {report['total']} | líneas malas: {report['bad_lines']}")
    print(
        f"Orientación completa: {report['full_orientation']} "
        f"({report['coverage_pct']}%) | parcial: {report['partial_orientation']} | falta: {report['missing_orientation']}"
    )

    print("\nPor gesto:")
    print("-" * 44)
    for label, data in sorted(report["per_label"].items()):
        print(
            f"{label:12s} total={data['total']:5d} "
            f"full={data['full_orientation']:5d} cov={data['coverage_pct']:6.2f}% "
            f"buckets={data['orientation_buckets']}"
        )

    print("\nLectura honesta:")
    if report["coverage_pct"] < 99.0:
        print("- Este banco NO está listo como banco V4.7 real: faltan features de orientación.")
        print("- Sirve para fallback, pero no para presumir 'Strict Critic' sin entrenar. La realidad, esa desgraciada.")
    else:
        print("- Banco listo para entrenar V4.7 con orientación interna.")
        print("- Siguiente paso: entrenar y correr ai_duel_lab con casos difíciles palma/dorso/lateral.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("bank", type=Path)
    parser.add_argument("--json", type=Path, default=None)
    args = parser.parse_args()

    report = analyze(args.bank.expanduser())
    print_report(report)

    if args.json:
        args.json.expanduser().write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\nReporte JSON guardado en: {args.json}")


if __name__ == "__main__":
    main()
