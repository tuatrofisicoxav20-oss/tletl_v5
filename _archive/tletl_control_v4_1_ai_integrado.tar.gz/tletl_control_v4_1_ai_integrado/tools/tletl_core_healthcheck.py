#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from tletl_core.classifier import RobustKNNRuntime
from tletl_core.state import TletlFrameState
from tletl_core.intent import gesture_to_common_intent
from tletl_core.bus import TletlStateBus


def main() -> int:
    ap = argparse.ArgumentParser(description="Tletl Core healthcheck")
    ap.add_argument("--bank", default="datasets/tletl_gesture_bank_v2_features.jsonl")
    ap.add_argument("--bus", default="tletl_state_core_test.json")
    args = ap.parse_args()

    bank = Path(args.bank).expanduser().resolve()
    print("TLETL V4.9.1 CORE HEALTHCHECK")
    print("================================")
    print(f"Banco: {bank}")

    runtime = RobustKNNRuntime(bank)
    print(f"OK runtime: {len(runtime.samples)} muestras balanceadas, {len(runtime.keys)} features")
    print(f"Labels: {dict(runtime.counts)}")

    state = TletlFrameState(app_version="4.9.1-core-healthcheck")
    state.intent = gesture_to_common_intent(state)
    bus = TletlStateBus(args.bus)
    bus.write(state)
    loaded = bus.read()
    if not loaded:
        raise RuntimeError("No pude leer de vuelta el bus de prueba")
    print(f"OK bus: {args.bus}")
    print("OK: núcleo común listo.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
