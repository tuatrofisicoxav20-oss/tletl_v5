#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"
STAMP="$(date +%Y%m%d_%H%M%S)"

cd "$PROJECT"
source "$VENV/bin/activate"

echo
echo "=============================================="
echo " TLETL V4.9 CORE SPLIT MIGRATION"
echo "=============================================="
echo "Proyecto: $PROJECT"
echo "Python:   $(python --version)"
echo "Fecha:    $STAMP"
echo

if [[ ! -f "main_v48_clean_ai.py" ]]; then
  echo "ERROR: No encuentro main_v48_clean_ai.py"
  exit 1
fi

if [[ ! -f "datasets/tletl_gesture_bank_v2_features.jsonl" ]]; then
  echo "ERROR: No encuentro datasets/tletl_gesture_bank_v2_features.jsonl"
  exit 1
fi

if [[ ! -d "tletl_control" ]]; then
  echo "ERROR: No encuentro tletl_control/"
  exit 1
fi

mkdir -p ".tletl_backups/v49_core_split_$STAMP"

echo "[1/10] Backup de archivos críticos..."
cp -av main_v48_clean_ai.py ".tletl_backups/v49_core_split_$STAMP/" >/dev/null
cp -av datasets/tletl_gesture_bank_v2_features.jsonl ".tletl_backups/v49_core_split_$STAMP/" >/dev/null
cp -av launchers ".tletl_backups/v49_core_split_$STAMP/launchers_backup" >/dev/null 2>&1 || true
cp -av tletl_control ".tletl_backups/v49_core_split_$STAMP/tletl_control_backup" >/dev/null

echo "[2/10] Creando estructura..."
mkdir -p tletl_core
mkdir -p apps/fedora_control
mkdir -p apps/blender_control
mkdir -p apps/shared
mkdir -p launchers
mkdir -p datasets/active
mkdir -p datasets/backups_v49
mkdir -p _legacy_disabled/launchers
mkdir -p _legacy_disabled/old_mains
mkdir -p _legacy_disabled/old_tools
mkdir -p _legacy_disabled/old_datasets
mkdir -p docs

echo "[3/10] Creando tletl_core inicial..."

cat > tletl_core/__init__.py <<'PY'
"""
Tletl Core común.

Cerebro compartido entre:
- Fedora/navegador
- Blender
- futuros adaptadores

No debe ejecutar acciones directas del sistema.
Solo debe detectar, clasificar, estabilizar y producir estado/intención.
"""

__version__ = "4.9-core-split"
PY

cat > tletl_core/state.py <<'PY'
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

Point2D = Tuple[float, float]


@dataclass
class TletlHandState:
    present: bool = False
    side: str = "unknown"

    gesture: str = "NO_HAND"
    raw_gesture: str = "NO_HAND"
    stable_gesture: str = "NO_HAND"

    orientation: str = "UNKNOWN"
    confidence: float = 0.0
    margin: float = 0.0

    critic_ok: bool = False
    critic_reason: str = "NO_HAND"

    palm: Optional[Point2D] = None
    index: Optional[Point2D] = None
    middle: Optional[Point2D] = None
    thumb: Optional[Point2D] = None

    velocity: Point2D = (0.0, 0.0)
    features: Dict[str, float] = field(default_factory=dict)


@dataclass
class TletlIntent:
    name: str = "NONE"
    active: bool = False
    strength: float = 0.0
    mode: str = "NONE"
    reason: str = ""


@dataclass
class TletlFrameState:
    version: int = 4
    app_version: str = "4.9-core-split"
    timestamp: float = 0.0

    frame_width: int = 0
    frame_height: int = 0
    fps: float = 0.0

    dom: TletlHandState = field(default_factory=TletlHandState)
    mod: TletlHandState = field(default_factory=TletlHandState)
    intent: TletlIntent = field(default_factory=TletlIntent)

    mode: str = "NONE"
    action: str = "NOOP"

    selected: bool = False
    grabbed: bool = False
    snap_enabled: bool = False

    transform: Dict[str, Any] = field(default_factory=lambda: {
        "x": 0.0,
        "y": 0.0,
        "z": 0.0,
        "rot_x": 0.0,
        "rot_y": 0.0,
        "rot_z": 0.0,
        "scale": 1.0,
    })

    extra: Dict[str, Any] = field(default_factory=dict)
PY

cat > tletl_core/bus.py <<'PY'
from __future__ import annotations

import json
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Dict

from .state import TletlFrameState


def _safe_data(obj: Any) -> Dict[str, Any]:
    if is_dataclass(obj):
        return asdict(obj)
    if isinstance(obj, dict):
        return obj
    raise TypeError(f"No puedo serializar objeto tipo {type(obj)!r}")


class TletlStateBus:
    """
    Bus común para exportar estado de Tletl.

    Fedora puede usarlo para debug.
    Blender puede leerlo para manipular objetos.
    """

    def __init__(self, path: str | Path = "tletl_state.json"):
        self.path = Path(path)

    def write(self, state: TletlFrameState | Dict[str, Any]) -> None:
        data = _safe_data(state)
        data.setdefault("timestamp", time.time())

        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)

    def read(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {}
        return json.loads(self.path.read_text(encoding="utf-8"))
PY

cat > tletl_core/intent.py <<'PY'
from __future__ import annotations

from .state import TletlFrameState, TletlIntent


def gesture_to_common_intent(state: TletlFrameState) -> TletlIntent:
    """
    Convierte gesto final en intención común.

    Esta capa NO debe saber si está en Fedora o Blender.
    Solo produce intención abstracta.
    """

    hand = state.dom

    if not hand.present:
        return TletlIntent(name="NONE", active=False, strength=0.0, mode=state.mode, reason="NO_HAND")

    if not hand.critic_ok:
        return TletlIntent(
            name="BLOCKED",
            active=False,
            strength=hand.confidence,
            mode=state.mode,
            reason=hand.critic_reason,
        )

    g = hand.gesture
    conf = float(hand.confidence)

    if g == "PINCH":
        return TletlIntent(name="GRAB_OR_SELECT", active=True, strength=conf, mode=state.mode, reason="PINCH")
    if g == "POINT":
        return TletlIntent(name="POINT", active=True, strength=conf, mode=state.mode, reason="POINT")
    if g == "OPEN_PALM":
        return TletlIntent(name="RELEASE_OR_TOGGLE", active=True, strength=conf, mode=state.mode, reason="OPEN_PALM")
    if g == "FIST":
        return TletlIntent(name="SAFETY_STOP", active=True, strength=conf, mode=state.mode, reason="FIST")
    if g == "THREE":
        return TletlIntent(name="MODE_NEXT", active=True, strength=conf, mode=state.mode, reason="THREE")
    if g == "VICTORY":
        return TletlIntent(name="SECONDARY_ACTION", active=True, strength=conf, mode=state.mode, reason="VICTORY")
    if g == "NEUTRAL":
        return TletlIntent(name="IDLE", active=False, strength=conf, mode=state.mode, reason="NEUTRAL")

    return TletlIntent(name="UNKNOWN", active=False, strength=conf, mode=state.mode, reason=g)
PY

cat > tletl_core/README.md <<'MD'
# Tletl Core

Núcleo común de Tletl.

Reglas:
- `tletl_core` no ejecuta acciones del sistema.
- No depende de Blender.
- No depende de ydotool.
- Solo produce estado, gesto, orientación, confianza, crítico e intención.
MD

echo "[4/10] Copiando V4.8 Clean AI como app Fedora activa..."
cp -av main_v48_clean_ai.py apps/fedora_control/main.py >/dev/null

cat > apps/fedora_control/README.md <<'MD'
# Fedora Control

App activa para Fedora/navegador.

Launcher oficial:
- ../../launchers/tletl-run-current.sh
MD

echo "[5/10] Creando base Blender Bus..."

cat > apps/blender_control/blender_state_reader.py <<'PY'
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


def read_tletl_state(path: str | Path = "tletl_state.json") -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def summarize_state(state: Dict[str, Any]) -> str:
    if not state:
        return "NO_STATE"

    dom = state.get("dom") or state.get("hands", {}).get("dom", {})
    intent = state.get("intent", {})

    gesture = dom.get("gesture", "NO_HAND")
    orientation = dom.get("orientation", "UNKNOWN")
    conf = float(dom.get("confidence", 0.0) or 0.0)
    intent_name = intent.get("name", "NONE")

    return f"gesture={gesture} orientation={orientation} conf={conf:.2f} intent={intent_name}"


if __name__ == "__main__":
    state = read_tletl_state()
    print(summarize_state(state))
PY

cat > apps/blender_control/README.md <<'MD'
# Blender Control

Puente inicial para Blender.

Blender no debe usar directamente la app Fedora.
Debe leer `tletl_state.json` o importar `tletl_core`.

Siguiente fase:
- Tletl Blender V5.1 Orientation Bus
MD

echo "[6/10] Organizando dataset activo..."
cp -av datasets/tletl_gesture_bank_v2_features.jsonl datasets/active/tletl_gesture_bank_v49_active.jsonl >/dev/null
ln -sf tletl_gesture_bank_v49_active.jsonl datasets/active/current.jsonl

echo "[7/10] Creando launchers oficiales..."

cat > launchers/tletl-run-current.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"

export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"
export YDOTOOL_SOCKET=/tmp/.ydotool_socket

export TLETL_GESTURE_BANK="$BANK"
export TLETL_BANK_PATH="$BANK"
export TLETL_DATASET_PATH="$BANK"

export TLETL_AI_V48="${TLETL_AI_V48:-1}"
export TLETL_AI_V48_STRICT="${TLETL_AI_V48_STRICT:-1}"
export TLETL_AI_V48_TEMPORAL="${TLETL_AI_V48_TEMPORAL:-1}"
export TLETL_AI_V48_ORIENTATION_WEIGHT="${TLETL_AI_V48_ORIENTATION_WEIGHT:-0.45}"

echo
echo "TLETL CURRENT"
echo "============="
echo "Versión: V4.9 Core Split / Fedora usa V4.8 Clean AI"
echo "Python:  $(python --version)"
echo "Banco:   $BANK"
echo "DryRun:  ${TLETL_DRY_RUN:-0}"
echo

python apps/fedora_control/main.py
SH
chmod +x launchers/tletl-run-current.sh

cat > launchers/tletl-run-fedora.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail
exec "$(dirname "$0")/tletl-run-current.sh" "$@"
SH
chmod +x launchers/tletl-run-fedora.sh

cat > launchers/tletl-run-safe.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail
export TLETL_DRY_RUN=1
exec "$(dirname "$0")/tletl-run-current.sh" "$@"
SH
chmod +x launchers/tletl-run-safe.sh

cat > launchers/tletl-bank-check-current.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"
export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"

python tools/tletl_orientation_coverage.py "$BANK"
python tools/tletl_v47_bank_selftest.py --bank "$BANK"
SH
chmod +x launchers/tletl-bank-check-current.sh

cat > launchers/tletl-blender-bus-test.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"

cd "$PROJECT"
source "$VENV/bin/activate"
export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"

python apps/blender_control/blender_state_reader.py
SH
chmod +x launchers/tletl-blender-bus-test.sh

echo "[8/10] Moviendo launchers viejos a legacy..."
for f in launchers/*.sh; do
  base="$(basename "$f")"
  case "$base" in
    tletl-run-current.sh|tletl-run-fedora.sh|tletl-run-safe.sh|tletl-bank-check-current.sh|tletl-blender-bus-test.sh|tletl-capture-v47.sh|tletl-orientation-coverage.sh|tletl-run-v48-clean-ai.sh)
      echo "Activo: $f"
      ;;
    *)
      echo "Legacy launcher: $f"
      mv "$f" "_legacy_disabled/launchers/${base%.sh}_legacy_$STAMP.sh"
      ;;
  esac
done

echo "[9/10] Escribiendo documentación..."

cat > README_TLETL_ACTUAL.md <<MD
# Tletl versión activa

Versión activa:
- Tletl V4.9 Core Split
- Fedora/navegador usa V4.8 Clean AI como app activa

Launcher oficial:
\`\`\`bash
./launchers/tletl-run-current.sh
\`\`\`

Modo seguro sin acciones reales:
\`\`\`bash
./launchers/tletl-run-safe.sh
\`\`\`

Revisión del banco:
\`\`\`bash
./launchers/tletl-bank-check-current.sh
\`\`\`

Banco activo:
\`\`\`text
datasets/tletl_gesture_bank_v2_features.jsonl
\`\`\`

App Fedora:
\`\`\`text
apps/fedora_control/main.py
\`\`\`

Núcleo común inicial:
\`\`\`text
tletl_core/
\`\`\`

Blender bus inicial:
\`\`\`text
apps/blender_control/
\`\`\`

Launchers viejos:
\`\`\`text
_legacy_disabled/launchers/
\`\`\`

Backup de migración:
\`\`\`text
.tletl_backups/v49_core_split_$STAMP/
\`\`\`

Regla:
No ejecutar launchers viejos salvo para comparar.
No borrar \`tletl_control/\` todavía porque la app activa puede seguir importando módulos internos.
MD

cat > docs/TLETL_V49_CORE_SPLIT_PLAN.md <<'MD'
# Tletl V4.9 Core Split Plan

## Objetivo

Separar Tletl en:

1. Núcleo común
2. App Fedora/navegador
3. App Blender/bus

## Regla técnica

El núcleo común no debe ejecutar acciones de sistema.

Correcto:

```text
frame -> tletl_core -> TletlFrameState -> adapter específico
```

Incorrecto:

```text
frame -> gesto -> acción directa mezclada
```

## Próxima fase

Extraer poco a poco de `main_v48_clean_ai.py` hacia:

- `tletl_core/features.py`
- `tletl_core/orientation.py`
- `tletl_core/classifier.py`
- `tletl_core/critic.py`
- `tletl_core/temporal.py`

Sin romper `apps/fedora_control/main.py`.
MD

echo "[10/10] Verificando compilación..."
python -m py_compile \
  tletl_core/*.py \
  apps/fedora_control/main.py \
  apps/blender_control/blender_state_reader.py

echo
echo "Revisando banco..."
./launchers/tletl-bank-check-current.sh || {
  echo
  echo "AVISO: El banco tuvo advertencias. No borro nada."
}

echo
echo "=============================================="
echo " MIGRACIÓN COMPLETADA"
echo "=============================================="
echo
echo "Arranque normal:"
echo "  ./launchers/tletl-run-current.sh"
echo
echo "Arranque seguro:"
echo "  ./launchers/tletl-run-safe.sh"
echo
echo "Revisar banco:"
echo "  ./launchers/tletl-bank-check-current.sh"
echo
echo "Probar bus Blender:"
echo "  ./launchers/tletl-blender-bus-test.sh"
echo
