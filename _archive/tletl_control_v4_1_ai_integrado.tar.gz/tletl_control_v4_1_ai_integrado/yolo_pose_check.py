
#!/usr/bin/env python3
import argparse
import cv2
from tletl_control.yolo_pose_helper import YOLOPoseContext


def main():
    ap = argparse.ArgumentParser(description="Probar Ultralytics YOLO11 Pose en Tletl.")
    ap.add_argument("--model", default="yolo11n-pose.pt")
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--every-n", type=int, default=2)
    ap.add_argument("--conf", type=float, default=0.35)
    args = ap.parse_args()

    ctx = YOLOPoseContext(args.model, every_n=args.every_n, conf=args.conf)
    if not ctx.ready():
        print("[ERROR] YOLO no está listo. Instala con: pip install ultralytics")
        print("Detalle:", ctx.last_info.get("error", ""))
        return

    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        print("[ERROR] No pude abrir cámara.")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
    cap.set(cv2.CAP_PROP_FPS, args.fps)

    print("[YOLO CHECK] Q para salir.")

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        frame = cv2.flip(frame, 1)
        ctx.process_and_draw(frame)

        cv2.putText(frame, "YOLO11 Pose check | Q salir", (20, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)

        cv2.imshow("Tletl YOLO11 Pose Check", frame)
        if (cv2.waitKey(1) & 0xFF) == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
