# Tletl local organizado V4.6

## Carpetas

- `datasets/`: bancos de gestos.
- `backups/`: respaldos antes de parches.
- `launchers/`: scripts para correr sin escribir comandos eternos.
- `logs/`: espacio para logs.

## Dataset recomendado

Usa:

`datasets/tletl_gesture_bank_v2_features.jsonl`

No borres el viejo:

`datasets/tletl_gesture_bank_legacy_backup.jsonl`

## Comandos rápidos

```bash
./launchers/tletl-check.sh
./launchers/tletl-train-fist-pinch.sh
./launchers/tletl-train-three-pinch.sh
./launchers/tletl-duel.sh
./launchers/tletl-dry-run.sh
./launchers/tletl-run.sh
```
