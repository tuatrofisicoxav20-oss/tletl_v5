#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"

export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"
export YDOTOOL_SOCKET=/tmp/.ydotool_socket

export TLETL_GESTURE_BANK="$BANK"
export TLETL_BANK_PATH="$BANK"
export TLETL_DATASET_PATH="$BANK"

export TLETL_AI_V49_STRICT="${TLETL_AI_V49_STRICT:-1}"
export TLETL_AI_V49_TEMPORAL="${TLETL_AI_V49_TEMPORAL:-1}"
export TLETL_AI_V49_ORIENTATION_WEIGHT="${TLETL_AI_V49_ORIENTATION_WEIGHT:-0.45}"
export TLETL_STATE_PATH="${TLETL_STATE_PATH:-tletl_state.json}"

echo
echo "TLETL V4.9.1 CORE"
echo "=================="
echo "Python:  $(python --version)"
echo "Banco:   $BANK"
echo "DryRun:  ${TLETL_DRY_RUN:-0}"
echo "Bus:     $TLETL_STATE_PATH"
echo

python apps/fedora_control/main_core.py "$@"
