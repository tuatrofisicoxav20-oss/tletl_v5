#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
STAMP="$(date +%Y%m%d_%H%M%S)"
cd "$PROJECT"

mkdir -p .tletl_backups/promote_core_$STAMP

if [[ -f launchers/tletl-run-current.sh ]]; then
  cp -v launchers/tletl-run-current.sh ".tletl_backups/promote_core_$STAMP/tletl-run-current_before_core.sh"
fi

cat > launchers/tletl-run-current.sh <<'INNER'
#!/usr/bin/env bash
set -euo pipefail
exec "$(dirname "$0")/tletl-run-core.sh" "$@"
INNER
chmod +x launchers/tletl-run-current.sh

echo "OK: tletl-run-current.sh ahora apunta a tletl-run-core.sh"
echo "Backup: .tletl_backups/promote_core_$STAMP/"
