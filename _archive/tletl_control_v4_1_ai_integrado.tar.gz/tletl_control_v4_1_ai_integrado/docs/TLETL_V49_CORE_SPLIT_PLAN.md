# Tletl V4.9 Core Split Plan

## Objetivo

Separar Tletl en:

1. Núcleo común
2. App Fedora/navegador
3. App Blender/bus

## Regla técnica

El núcleo común no debe ejecutar acciones de sistema.

Correcto:

```text
frame -> tletl_core -> TletlFrameState -> adapter específico
```

Incorrecto:

```text
frame -> gesto -> acción directa mezclada
```

## Próxima fase

Extraer poco a poco de `main_v48_clean_ai.py` hacia:

- `tletl_core/features.py`
- `tletl_core/orientation.py`
- `tletl_core/classifier.py`
- `tletl_core/critic.py`
- `tletl_core/temporal.py`

Sin romper `apps/fedora_control/main.py`.
