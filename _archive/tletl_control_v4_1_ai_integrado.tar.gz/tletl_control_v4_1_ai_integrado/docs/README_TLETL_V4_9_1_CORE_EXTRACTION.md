# Tletl V4.9.1 Core Extraction

Esta fase extrae el cerebro real de V4.8 hacia `tletl_core/` sin romper la app actual.

## Qué agrega

- `tletl_core/geometry.py`
- `tletl_core/orientation.py`
- `tletl_core/features.py`
- `tletl_core/classifier.py`
- `tletl_core/temporal.py`
- `apps/fedora_control/action_adapter.py`
- `apps/fedora_control/main_core.py`
- `launchers/tletl-run-core.sh`
- `launchers/tletl-run-core-safe.sh`
- `launchers/tletl-promote-core.sh`
- `tools/tletl_core_healthcheck.py`

## Importante

No reemplaza `tletl-run-current.sh` automáticamente.
Primero pruebas `tletl-run-core-safe.sh`; si funciona, promueves con:

```bash
./launchers/tletl-promote-core.sh
```

## Flujo nuevo

```text
MediaPipe landmarks
→ tletl_core.geometry
→ tletl_core.features + orientation
→ tletl_core.classifier
→ tletl_core.temporal
→ TletlFrameState
→ intent común
→ Fedora action_adapter
→ bus JSON para Blender
```

## Pruebas

```bash
python tools/tletl_core_healthcheck.py --bank datasets/tletl_gesture_bank_v2_features.jsonl
TLETL_DRY_RUN=1 ./launchers/tletl-run-core.sh
```
