
#!/usr/bin/env python3
from pathlib import Path
import argparse
import json
from collections import Counter, defaultdict

NEW_FEATURES = {
    "index_tip_palm",
    "middle_tip_palm",
    "ring_tip_palm",
    "pinky_tip_palm",
    "pinch_thumb_index",
    "pinch_thumb_middle",
    "pinch_thumb_ring",
    "pinch_index_to_mcp",
    "closed_fingers_mean",
    "pinch_cleanliness",
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="tletl_gesture_bank.jsonl")
    args = ap.parse_args()

    p = Path(args.dataset)
    if not p.exists():
        print("No existe:", p)
        return

    rows = []
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except Exception:
            pass

    counts = Counter(row.get("label", "UNKNOWN") for row in rows)
    print("=== Conteos ===")
    for k in sorted(counts):
        print(f"{k}: {counts[k]}")
    print("TOTAL:", sum(counts.values()))

    print("\\n=== Cobertura de features nuevas ===")
    by_label = defaultdict(lambda: [0, 0])
    for row in rows:
        label = row.get("label", "UNKNOWN")
        feats = row.get("features", {})
        by_label[label][1] += 1
        if NEW_FEATURES.issubset(set(feats.keys())):
            by_label[label][0] += 1

    for label in sorted(by_label):
        ok, total = by_label[label]
        pct = (ok / total * 100) if total else 0
        print(f"{label}: {ok}/{total} con features nuevas ({pct:.1f}%)")

if __name__ == "__main__":
    main()
