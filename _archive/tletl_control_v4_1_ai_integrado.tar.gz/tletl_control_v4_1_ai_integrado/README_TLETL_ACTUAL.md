# Tletl versión activa

Versión activa:
- Tletl V4.9 Core Split
- Fedora/navegador usa V4.8 Clean AI como app activa

Launcher oficial:
```bash
./launchers/tletl-run-current.sh
```

Modo seguro sin acciones reales:
```bash
./launchers/tletl-run-safe.sh
```

Revisión del banco:
```bash
./launchers/tletl-bank-check-current.sh
```

Banco activo:
```text
datasets/tletl_gesture_bank_v2_features.jsonl
```

App Fedora:
```text
apps/fedora_control/main.py
```

Núcleo común inicial:
```text
tletl_core/
```

Blender bus inicial:
```text
apps/blender_control/
```

Launchers viejos:
```text
_legacy_disabled/launchers/
```

Backup de migración:
```text
.tletl_backups/v49_core_split_20260503_233132/
```

Regla:
No ejecutar launchers viejos salvo para comparar.
No borrar `tletl_control/` todavía porque la app activa puede seguir importando módulos internos.
