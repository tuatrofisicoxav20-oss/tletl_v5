#!/usr/bin/env python3
import argparse
from pathlib import Path

import cv2
import mediapipe as mp

from tletl_control.ai_bank import append_sample, load_samples, count_by_label
from tletl_control.ai_classifier import KNNGestureClassifier
from tletl_control.features import extract_features
from tletl_control.geometry import points_from_landmarks
from tletl_control.ui import draw_text_box

GESTURES = ["OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"]
KEY_TO_LABEL = {
    ord("1"): "OPEN_PALM",
    ord("2"): "FIST",
    ord("3"): "POINT",
    ord("4"): "VICTORY",
    ord("5"): "PINCH",
    ord("6"): "THREE",
    ord("7"): "NEUTRAL",
}
FOCUS = {
    "fist_pinch": ["FIST", "PINCH", "NEUTRAL"],
    "three_pinch": ["THREE", "PINCH", "NEUTRAL"],
    "point_pinch": ["POINT", "PINCH", "NEUTRAL"],
    "victory_three": ["VICTORY", "THREE", "NEUTRAL"],
    "neutral_actions": ["NEUTRAL", "PINCH", "FIST", "POINT"],
    "all": GESTURES,
}

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


def open_camera(camera, width, height, fps):
    cap = cv2.VideoCapture(camera)
    if not cap.isOpened():
        raise RuntimeError(f"No pude abrir cámara {camera}. Prueba --camera 1.")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def main():
    ap = argparse.ArgumentParser(description="Tletl Training Lab V4.6")
    ap.add_argument("--dataset", default="datasets/tletl_gesture_bank_v2_features.jsonl")
    ap.add_argument("--focus", choices=list(FOCUS.keys()), default="fist_pinch")
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--det-conf", type=float, default=0.50)
    ap.add_argument("--track-conf", type=float, default=0.50)
    ap.add_argument("--k", type=int, default=21)
    args = ap.parse_args()

    dataset_path = Path(args.dataset).expanduser().resolve()
    dataset_path.parent.mkdir(parents=True, exist_ok=True)
    dataset_path.touch(exist_ok=True)

    selected = FOCUS[args.focus][0]
    last_saved = "-"

    rows = load_samples(dataset_path)
    clf = KNNGestureClassifier(k=args.k)
    clf.fit(rows)

    cap = open_camera(args.camera, args.width, args.height, args.fps)

    print("[TLETL TRAINING LAB V4.6]")
    print("1 palma | 2 puño | 3 índice | 4 victoria | 5 pinza | 6 tres | 7 neutral")
    print("SPACE guarda como etiqueta seleccionada | tecla correcta = corregir+guardar | Q salir")

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=1,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands:
        while True:
            ok, frame = cap.read()
            if not ok:
                break

            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = hands.process(rgb)

            features = None
            pred, conf, info = "NO_HAND", 0.0, {}
            if result.multi_hand_landmarks:
                hand_landmarks = result.multi_hand_landmarks[0]
                points = points_from_landmarks(hand_landmarks)
                features = extract_features(points)
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                if clf.ready():
                    pred, conf, info = clf.predict(features)
                else:
                    pred, conf, info = "UNKNOWN", 0.0, {"reason": "dataset insuficiente"}

            rows = load_samples(dataset_path)
            counts = count_by_label(rows)

            focus_labels = FOCUS[args.focus]
            focus_line = " | ".join(f"{g}:{counts.get(g,0)}" for g in focus_labels)
            votes = info.get("votes", {}) if isinstance(info, dict) else {}
            specialist = info.get("specialist", "-") if isinstance(info, dict) else "-"

            lines = [
                "TLETL V4.6 TRAINING LAB",
                f"Focus: {args.focus} | Etiqueta seleccionada: {selected}",
                f"Predicción: {pred} | Conf: {conf:.2f} | Especialista: {specialist}",
                f"Focus counts: {focus_line}",
                f"Total dataset: {sum(counts.values())} | Último: {last_saved}",
                f"Votos: {votes}",
                "1 palma 2 puño 3 índice 4 victoria 5 pinza 6 tres 7 neutral",
                "SPACE=guardar seleccionada | tecla correcta=corregir+guardar | Q=salir",
            ]

            if features is None:
                lines.append("No veo mano completa.")
            elif pred != selected:
                lines.append("MUESTRA DIFÍCIL: si tu etiqueta seleccionada es correcta, guarda/corrige.")
            else:
                lines.append("Predicción coincide. Guarda pocas, busca variaciones difíciles.")

            draw_text_box(frame, lines, font_scale=0.43)
            cv2.imshow("Tletl Training Lab V4.6", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break

            if key in KEY_TO_LABEL:
                selected = KEY_TO_LABEL[key]
                if features is not None:
                    append_sample(dataset_path, selected, features, meta={
                        "source": "training-lab-v4.6-correction",
                        "focus": args.focus,
                        "pred": pred,
                        "conf": conf,
                        "hard": pred != selected,
                    })
                    rows = load_samples(dataset_path)
                    clf.fit(rows)
                    last_saved = f"{selected} correction pred={pred}"
                    print("[OK]", last_saved)

            elif key == 32 and features is not None:
                append_sample(dataset_path, selected, features, meta={
                    "source": "training-lab-v4.6-manual",
                    "focus": args.focus,
                    "pred": pred,
                    "conf": conf,
                    "hard": pred != selected,
                })
                rows = load_samples(dataset_path)
                clf.fit(rows)
                last_saved = f"{selected} manual pred={pred}"
                print("[OK]", last_saved)

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
