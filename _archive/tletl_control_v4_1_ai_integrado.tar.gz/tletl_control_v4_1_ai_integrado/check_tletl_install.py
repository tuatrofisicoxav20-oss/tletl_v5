#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import json
from collections import Counter

ROOT = Path.cwd()

FILES = [
    "main.py",
    "train_gesture_lab.py",
    "ai_duel_lab.py",
    "audit_confusions.py",
    "analyze_gesture_bank.py",
    "yolo_pose_check.py",
    "tletl_control/features.py",
    "tletl_control/ai_classifier.py",
    "tletl_control/ai_bank.py",
    "tletl_control/ai_runtime.py",
    "tletl_control/ai_critic.py",
    "tletl_control/yolo_pose_helper.py",
]

print("=== Tletl install check ===")
print("Root:", ROOT)

print("\\n=== Archivos ===")
for rel in FILES:
    p = ROOT / rel
    print(("OK   " if p.exists() else "MISS ") + rel)

print("\\n=== Paquetes Python ===")
for mod in ["cv2", "mediapipe", "numpy", "ultralytics"]:
    spec = importlib.util.find_spec(mod)
    print(("OK   " if spec else "MISS ") + mod)

print("\\n=== Datasets ===")
for rel in [
    "tletl_gesture_bank.jsonl",
    "datasets/tletl_gesture_bank_legacy_backup.jsonl",
    "datasets/tletl_gesture_bank_v2_features.jsonl",
]:
    p = ROOT / rel
    if not p.exists():
        print("MISS", rel)
        continue
    rows = []
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except Exception:
            pass
    counts = Counter(r.get("label", "UNKNOWN") for r in rows)
    print("OK  ", rel, "| total", sum(counts.values()), "|", dict(counts))

print("\\n=== Compilación rápida ===")
for rel in FILES:
    if not rel.endswith(".py"):
        continue
    p = ROOT / rel
    if not p.exists():
        continue
    try:
        import py_compile
        py_compile.compile(str(p), doraise=True)
        print("OK  ", rel)
    except Exception as e:
        print("ERR ", rel, "->", e)
