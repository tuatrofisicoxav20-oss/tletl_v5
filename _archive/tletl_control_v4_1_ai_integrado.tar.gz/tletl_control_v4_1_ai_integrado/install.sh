#!/usr/bin/env bash
set -euo pipefail

python3.12 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
python -m pip install --upgrade pip
pip install opencv-python mediapipe numpy

echo "Listo. Ejecuta:"
echo "source .venv/bin/activate"
echo "export YDOTOOL_SOCKET=/tmp/.ydotool_socket"
echo "python main.py --profile tletl_profile_v3_4.json --dry-run --width 640 --height 480"
