#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import time
from pathlib import Path
from typing import Optional, Tuple

import cv2
import mediapipe as mp
import numpy as np

from tletl_core.bus import TletlStateBus
from tletl_core.classifier import Prediction, RobustKNNRuntime
from tletl_core.features import extract_live_features
from tletl_core.geometry import palm_center, points_from_mediapipe
from tletl_core.intent import gesture_to_common_intent
from tletl_core.state import TletlFrameState, TletlHandState
from tletl_core.temporal import CursorDelta, Hold, MotionTracker, TemporalFilter
from apps.fedora_control.action_adapter import FedoraActions

APP = "Tletl V4.9.1 Core Fedora"

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


def draw_panel(frame: np.ndarray, lines: list[str], color: Tuple[int, int, int]) -> None:
    h, w = frame.shape[:2]
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (w - 10, 205), (10, 10, 10), -1)
    cv2.addWeighted(overlay, 0.68, frame, 0.32, 0, frame)

    y = 35
    for i, line in enumerate(lines):
        c = color if i == 0 else (255, 255, 255)
        cv2.putText(frame, line, (22, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, c, 2, cv2.LINE_AA)
        y += 26

    cv2.line(frame, (0, int(h * 0.39)), (w, int(h * 0.39)), (255, 255, 0), 1)
    cv2.line(frame, (0, int(h * 0.61)), (w, int(h * 0.61)), (255, 255, 0), 1)


def open_camera(index: int, width: int, height: int, fps: int) -> cv2.VideoCapture:
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"No pude abrir cámara {index}. Prueba --camera 1 o --camera 2.")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def build_frame_state(
    *,
    pred: Prediction,
    hand_seen: bool,
    cx: float,
    cy: float,
    fps: float,
    frame_w: int,
    frame_h: int,
    mode: str,
    control: bool,
    last_action: str,
    swipe: Optional[str],
    features: dict,
) -> TletlFrameState:
    dom = TletlHandState(
        present=hand_seen,
        side="dom",
        gesture=pred.label,
        raw_gesture=pred.raw_label,
        stable_gesture=pred.label,
        orientation=pred.orientation,
        confidence=float(pred.confidence),
        margin=float(pred.margin),
        critic_ok=bool(pred.ok),
        critic_reason=pred.reason,
        palm=(float(cx), float(cy)) if hand_seen else None,
        features=features if hand_seen else {},
    )

    state = TletlFrameState(
        version=4,
        app_version="4.9.1-core-fedora",
        timestamp=time.time(),
        frame_width=frame_w,
        frame_height=frame_h,
        fps=fps,
        dom=dom,
        mode=mode,
        action=last_action,
        selected=control,
        grabbed=pred.label == "PINCH" and pred.ok,
        extra={"swipe": swipe or "-", "control": control},
    )
    state.intent = gesture_to_common_intent(state)
    return state


def run(args: argparse.Namespace) -> int:
    bank = Path(args.bank).expanduser().resolve()
    strict = os.environ.get("TLETL_AI_V48_STRICT", os.environ.get("TLETL_AI_V49_STRICT", "1")) != "0"
    temporal_enabled = os.environ.get("TLETL_AI_V48_TEMPORAL", os.environ.get("TLETL_AI_V49_TEMPORAL", "1")) != "0"
    orientation_weight = float(os.environ.get("TLETL_AI_V48_ORIENTATION_WEIGHT", os.environ.get("TLETL_AI_V49_ORIENTATION_WEIGHT", "0.45")))
    dry_run = args.dry_run or os.environ.get("TLETL_DRY_RUN", "0") == "1"
    bus_path = os.environ.get("TLETL_STATE_PATH", "tletl_state.json")

    runtime = RobustKNNRuntime(bank, k=args.k, orientation_weight=orientation_weight)
    cap = open_camera(args.camera, args.width, args.height, args.fps)
    actions = FedoraActions(dry_run=dry_run)
    bus = TletlStateBus(bus_path)

    temporal = TemporalFilter(size=7, min_count=4)
    motion = MotionTracker()
    cursor = CursorDelta()
    hold_toggle = Hold()
    hold_mode = Hold()

    modes = ["NAVEGADOR", "CURSOR", "VENTANAS"]
    mode_i = 0
    control = False
    last_action = "-"
    last_click = 0.0
    last_scroll = 0.0
    last_tab = 0.0
    last_big = 0.0
    last_toggle = 0.0
    drag = False
    pinch_t0: Optional[float] = None

    window = APP
    cv2.namedWindow(window, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window, args.width, args.height)

    prev_t = time.time()
    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=1,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands_model:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("No pude leer frame.")
                break

            frame = cv2.flip(frame, 1)
            now = time.time()
            fps = 1.0 / max(now - prev_t, 1e-6)
            prev_t = now

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = hands_model.process(rgb)

            pred = Prediction("NO_HAND", "NO_HAND", 0.0, 0.0, "-", "NO_HAND", False, {})
            cx = cy = 0.0
            swipe = None
            hand_seen = False
            toggle_progress = 0.0
            mode_progress = 0.0
            features = {}

            if result.multi_hand_landmarks:
                hand_seen = True
                hand_landmarks = result.multi_hand_landmarks[0]
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                lm = points_from_mediapipe(hand_landmarks)
                features = extract_live_features(lm)
                cx, cy = palm_center(lm)
                motion.update(cx, cy)
                swipe = motion.swipe()

                raw_pred = runtime.predict(features, strict=strict)
                pred = temporal.update(raw_pred) if temporal_enabled else raw_pred

                px, py = int(cx * frame.shape[1]), int(cy * frame.shape[0])
                cv2.circle(frame, (px, py), 12, (0, 255, 255), 2)
                cv2.putText(
                    frame,
                    f"{pred.label}/{pred.raw_label} {pred.confidence:.2f}",
                    (px - 70, py - 25),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.50,
                    (0, 255, 255),
                    2,
                    cv2.LINE_AA,
                )
            else:
                motion.reset()
                cursor.reset()
                temporal.reset()
                hold_toggle.reset()
                hold_mode.reset()
                if drag:
                    actions.mouse_up()
                    drag = False
                pinch_t0 = None

            if hand_seen and pred.label == "OPEN_PALM":
                required = 2.0 if control else 1.25
                toggle_progress = hold_toggle.progress("OPEN_PALM", required)
                if toggle_progress >= 1.0 and now - last_toggle > 1.0:
                    control = not control
                    last_toggle = now
                    hold_toggle.reset()
                    temporal.reset()
                    last_action = "Control ON" if control else "Control OFF"
                    if not control and drag:
                        actions.mouse_up()
                        drag = False
                    print(f"[TLETL] {last_action}")
            else:
                hold_toggle.reset()

            if control and pred.label == "FIST" and pred.confidence > 0.55:
                control = False
                last_action = "Pausa seguridad"
                if drag:
                    actions.mouse_up()
                    drag = False
                pinch_t0 = None

            if control and pred.label == "THREE":
                mode_progress = hold_mode.progress("THREE", 0.85)
                if mode_progress >= 1.0 and now - last_big > 1.0:
                    mode_i = (mode_i + 1) % len(modes)
                    last_big = now
                    hold_mode.reset()
                    temporal.reset()
                    cursor.reset()
                    last_action = f"Modo {modes[mode_i]}"
            else:
                hold_mode.reset()

            mode = modes[mode_i]
            can_act = control and hand_seen and pred.ok and pred.confidence >= args.action_conf

            if can_act:
                if mode == "NAVEGADOR":
                    if pred.label == "POINT" and now - last_scroll > 0.11:
                        if cy < 0.22:
                            actions.page_up(); last_action = "PageUp"; last_scroll = now + 0.12
                        elif cy > 0.78:
                            actions.page_down(); last_action = "PageDown"; last_scroll = now + 0.12
                        elif cy < 0.39:
                            actions.scroll_up(); last_action = "Scroll arriba"; last_scroll = now
                        elif cy > 0.61:
                            actions.scroll_down(); last_action = "Scroll abajo"; last_scroll = now
                    elif pred.label == "PINCH" and now - last_click > 0.34:
                        actions.click_left(); last_action = "Click"; last_click = now
                    elif pred.label == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab > 0.65:
                        if swipe == "RIGHT":
                            actions.next_tab(); last_action = "Tab siguiente"
                        else:
                            actions.prev_tab(); last_action = "Tab anterior"
                        last_tab = now
                    elif pred.label == "OPEN_PALM" and swipe in {"LEFT", "RIGHT"} and toggle_progress < 0.55 and now - last_tab > 0.75:
                        if swipe == "LEFT":
                            actions.back(); last_action = "Atrás"
                        else:
                            actions.forward(); last_action = "Adelante"
                        last_tab = now

                elif mode == "CURSOR":
                    if pred.label in {"POINT", "OPEN_PALM", "PINCH"}:
                        dx, dy = cursor.update(cx, cy)
                        actions.mousemove(dx, dy)
                    else:
                        cursor.reset()
                    if pred.label == "PINCH":
                        if pinch_t0 is None:
                            pinch_t0 = now
                        if not drag and now - pinch_t0 > 0.32:
                            actions.mouse_down(); drag = True; last_action = "Drag ON"
                    else:
                        if pinch_t0 is not None:
                            held = now - pinch_t0
                            if drag:
                                actions.mouse_up(); drag = False; last_action = "Drag OFF"
                            elif held < 0.24 and now - last_click > 0.28:
                                actions.click_left(); last_click = now; last_action = "Click"
                        pinch_t0 = None

                elif mode == "VENTANAS":
                    if pred.label == "OPEN_PALM" and swipe == "UP" and now - last_big > 0.9:
                        actions.overview(); last_big = now; last_action = "Overview"
                    elif pred.label == "PINCH" and now - last_click > 0.38:
                        actions.enter(); last_click = now; last_action = "Enter"
            else:
                cursor.reset()
                if drag and pred.label != "PINCH":
                    actions.mouse_up()
                    drag = False
                    pinch_t0 = None

            state = build_frame_state(
                pred=pred,
                hand_seen=hand_seen,
                cx=cx,
                cy=cy,
                fps=fps,
                frame_w=frame.shape[1],
                frame_h=frame.shape[0],
                mode=mode,
                control=control,
                last_action=last_action,
                swipe=swipe,
                features=features,
            )
            bus.write(state)

            state_txt = "ON" if control else "OFF"
            color = (0, 255, 0) if control else (0, 0, 255)
            lines = [
                f"TLETL V4.9.1 CORE {state_txt} | MODO:{mode} | FPS:{fps:.1f} | DRY:{dry_run}",
                f"AI final:{pred.label} | raw:{pred.raw_label} | conf:{pred.confidence:.2f} | margin:{pred.margin:.2f} | ok:{pred.ok}",
                f"Orientation:{pred.orientation} | Critic:{pred.reason} | Intent:{state.intent.name} | Swipe:{swipe or '-'}",
                f"Runtime: tletl_core.KNN | Strict:{strict} | Temporal:{temporal_enabled} | orient_weight:{orientation_weight:.2f}",
                f"Action:{last_action} | Bus:{bus_path}",
                "OPEN_PALM hold=ON/OFF | FIST=seguridad | THREE=modo | Q/ESC=salir",
            ]
            if toggle_progress > 0:
                lines.append(f"Toggle progress: {int(toggle_progress * 100)}%")
            if mode_progress > 0:
                lines.append(f"Mode progress: {int(mode_progress * 100)}%")
            draw_panel(frame, lines, color)
            cv2.circle(frame, (frame.shape[1] - 34, 34), 17, color, -1)

            cv2.imshow(window, frame)
            key = cv2.waitKey(1) & 0xFF
            if key in {27, ord("q")}:
                break
            if key == ord("t"):
                control = not control
                last_action = "Control ON tecla" if control else "Control OFF tecla"
            elif key == ord("m"):
                mode_i = (mode_i + 1) % len(modes)
                last_action = f"Modo {modes[mode_i]} tecla"

    if drag:
        actions.mouse_up()
    cap.release()
    cv2.destroyAllWindows()
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=APP)
    ap.add_argument("--bank", default=os.environ.get("TLETL_GESTURE_BANK", "datasets/tletl_gesture_bank_v2_features.jsonl"))
    ap.add_argument("--camera", type=int, default=int(os.environ.get("TLETL_CAMERA", "0")))
    ap.add_argument("--width", type=int, default=960)
    ap.add_argument("--height", type=int, default=540)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--det-conf", type=float, default=0.72)
    ap.add_argument("--track-conf", type=float, default=0.72)
    ap.add_argument("--action-conf", type=float, default=0.52)
    ap.add_argument("--k", type=int, default=13)
    ap.add_argument("--dry-run", action="store_true")
    return ap


if __name__ == "__main__":
    try:
        raise SystemExit(run(build_parser().parse_args()))
    except KeyboardInterrupt:
        print("\n[TLETL] Interrumpido.")
    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        print("Tips: prueba --camera 1, o TLETL_DRY_RUN=1 ./launchers/tletl-run-core.sh")
        raise
