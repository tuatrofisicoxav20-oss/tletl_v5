from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


def read_tletl_state(path: str | Path = "tletl_state.json") -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def summarize_state(state: Dict[str, Any]) -> str:
    if not state:
        return "NO_STATE"

    dom = state.get("dom") or state.get("hands", {}).get("dom", {})
    intent = state.get("intent", {})

    gesture = dom.get("gesture", "NO_HAND")
    orientation = dom.get("orientation", "UNKNOWN")
    conf = float(dom.get("confidence", 0.0) or 0.0)
    intent_name = intent.get("name", "NONE")

    return f"gesture={gesture} orientation={orientation} conf={conf:.2f} intent={intent_name}"


if __name__ == "__main__":
    state = read_tletl_state()
    print(summarize_state(state))
