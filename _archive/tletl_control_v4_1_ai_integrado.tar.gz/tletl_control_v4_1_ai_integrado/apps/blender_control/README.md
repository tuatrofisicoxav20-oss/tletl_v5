# Blender Control

Puente inicial para Blender.

Blender no debe usar directamente la app Fedora.
Debe leer `tletl_state.json` o importar `tletl_core`.

Siguiente fase:
- Tletl Blender V5.1 Orientation Bus
