#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"

export YDOTOOL_SOCKET=/tmp/.ydotool_socket

# Banco V4.7 real con orientación.
export TLETL_GESTURE_BANK="$BANK"
export TLETL_BANK_PATH="$BANK"
export TLETL_DATASET_PATH="$BANK"

# Modo estricto.
export TLETL_AI_ENABLED=1
export TLETL_V47_ORIENTATION=1
export TLETL_STRICT_CRITIC=1
export TLETL_SHOW_CRITIC=1
export TLETL_SHOW_ORIENTATION=1

echo
echo "TLETL V4.7 UI"
echo "============="
echo "Proyecto: $PROJECT"
echo "Python:   $(python --version)"
echo "Banco:    $BANK"
echo

python tools/tletl_orientation_coverage.py "$BANK" || true

echo
echo "Arrancando interfaz V4.7..."
echo

python main.py
