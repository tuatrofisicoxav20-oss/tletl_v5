#!/usr/bin/env bash
cd ~/Documentos/tletl_control_v4_1_ai_integrado
source ~/Documentos/tletl_control_v4_modular/.venv/bin/activate
export YDOTOOL_SOCKET=/tmp/.ydotool_socket
python main.py --ai --ai-dataset datasets/tletl_gesture_bank_v2_features.jsonl --profile ~/Documentos/tletl_control_v3/tletl_profile_v3_4.json --width 640 --height 480 --det-conf 0.50 --track-conf 0.50 --ai-min-conf 0.72 --ai-k 21 --history 9 --stable-count 6
