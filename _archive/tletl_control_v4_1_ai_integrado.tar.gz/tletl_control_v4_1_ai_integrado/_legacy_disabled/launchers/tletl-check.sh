#!/usr/bin/env bash
cd ~/Documentos/tletl_control_v4_1_ai_integrado
source ~/Documentos/tletl_control_v4_modular/.venv/bin/activate
python check_tletl_install.py
