#!/usr/bin/env bash
cd ~/Documentos/tletl_control_v4_1_ai_integrado
source ~/Documentos/tletl_control_v4_modular/.venv/bin/activate
python train_gesture_lab.py --dataset datasets/tletl_gesture_bank_v2_features.jsonl --focus three_pinch --width 640 --height 480 --det-conf 0.50 --track-conf 0.50 --k 21
