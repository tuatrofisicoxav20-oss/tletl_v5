#!/usr/bin/env bash
set -euo pipefail

PROJECT="/home/exitili/Documentos/tletl_control_v4_1_ai_integrado"
VENV="/home/exitili/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"

export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"
export YDOTOOL_SOCKET=/tmp/.ydotool_socket

# IA V4.7.3 estabilizada
export TLETL_AI_V47=1
export TLETL_AI_V47_STRICT=1
export TLETL_AI_V47_BANK="$BANK"
export TLETL_GESTURE_BANK="$BANK"
export TLETL_BANK_PATH="$BANK"
export TLETL_DATASET_PATH="$BANK"

# Clasificador robusto: KNN multimodal + pesos + guardia de reglas.
export TLETL_AI_V47_K="11"
export TLETL_AI_V47_SOFTMAX_TEMP="3.0"
export TLETL_AI_V47_ORIENTATION_WEIGHT="0.55"
export TLETL_AI_V47_RULE_GUARD="1"
export TLETL_AI_V47_TEMPORAL="1"
export TLETL_AI_V47_TEMPORAL_SIZE="5"
export TLETL_AI_V47_TEMPORAL_MIN="3"
export TLETL_AI_V47_NEUTRAL_RAW="UNKNOWN"

# Si se siente demasiado bloqueado, prueba temporalmente:
# TLETL_AI_V47_TEMPORAL=0 ./launchers/tletl-run-v47-ai.sh
# TLETL_AI_V47_STRICT=0 ./launchers/tletl-run-v47-ai.sh

clear

echo
echo "TLETL V4.7.3 LIVE AI ESTABILIZADA"
echo "=================================="
echo "Proyecto: $PROJECT"
echo "Python:   $(python --version)"
echo "Banco:    $BANK"
echo

python tools/tletl_v47_runtime_check.py --bank "$BANK" || true

echo
echo "Arrancando interfaz con IA V4.7.3..."
echo

python main.py
