#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import time
from collections import Counter, deque, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Deque, Dict, Iterable, List, Optional, Tuple

import cv2
import mediapipe as mp
import numpy as np

APP = "Tletl V4.8 Clean AI"
LABELS = ["OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"]
LABEL_KEYS = ("label", "gesture", "target", "class", "y")
NON_FEATURE_KEYS = set(LABEL_KEYS) | {
    "timestamp", "time", "created_at", "source", "orientation", "bucket", "handedness", "score",
    "landmarks", "raw_landmarks", "hand_landmarks", "features",
}
EXCLUDED_FEATURES = {
    "palm_center_x", "palm_center_y", "screen_x", "screen_y", "cx", "cy",
}
ORIENTATION_KEYS = {
    "palm_normal_x", "palm_normal_y", "palm_normal_z", "palm_roll", "palm_yaw", "palm_pitch",
    "palm_facing_score", "back_hand_score", "side_hand_score", "palm_flatness_score",
    "wrist_depth_score", "thumb_side_score", "finger_depth_spread",
}
META_KEYS = NON_FEATURE_KEYS | EXCLUDED_FEATURES

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


@dataclass
class Point:
    x: float
    y: float
    z: float


def dist(a: Point, b: Point) -> float:
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)


def points_from_mediapipe(hand_landmarks: Any) -> List[Point]:
    return [Point(float(p.x), float(p.y), float(p.z)) for p in hand_landmarks.landmark]


def palm_scale(lm: List[Point]) -> float:
    wrist_to_middle = dist(lm[0], lm[9])
    palm_width = dist(lm[5], lm[17])
    return max((wrist_to_middle + palm_width) / 2.0, 1e-6)


def palm_center(lm: List[Point]) -> Tuple[float, float]:
    ids = [0, 5, 9, 13, 17]
    return sum(lm[i].x for i in ids) / len(ids), sum(lm[i].y for i in ids) / len(ids)


def vec(a: Point, b: Point) -> np.ndarray:
    return np.array([b.x - a.x, b.y - a.y, b.z - a.z], dtype=float)


def norm_vec(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    if n < 1e-9:
        return np.zeros(3, dtype=float)
    return v / n


def compute_orientation(lm: List[Point]) -> Dict[str, float]:
    """Palm orientation from MediaPipe normalized 3D landmarks.

    MediaPipe z is relative/noisy, so these are not physics-grade rotations.
    They are stable enough as extra features. Shocking that webcams are not LiDAR.
    """
    scale = palm_scale(lm)
    wrist = lm[0]
    index_mcp = lm[5]
    middle_mcp = lm[9]
    pinky_mcp = lm[17]

    across = vec(pinky_mcp, index_mcp)   # pinky -> index
    up = vec(wrist, middle_mcp)          # wrist -> palm/fingers
    normal = norm_vec(np.cross(across, up))

    # Keep sign natural. Flipped cameras/left hand can invert, so scores are softened.
    nx, ny, nz = [float(x) for x in normal]

    roll = math.degrees(math.atan2(across[1], across[0])) if np.linalg.norm(across[:2]) > 1e-9 else 0.0
    yaw = math.degrees(math.atan2(nx, max(abs(nz), 1e-6)))
    pitch = math.degrees(math.atan2(ny, max(abs(nz), 1e-6)))

    abs_nz = abs(nz)
    side_score = clamp(1.0 - abs_nz, 0.0, 1.0)
    # In practice palm/back sign can flip by handedness/camera; runtime uses bucket mostly for debug.
    palm_facing = clamp((nz + 1.0) / 2.0, 0.0, 1.0)
    back_hand = clamp((-nz + 1.0) / 2.0, 0.0, 1.0)

    mcp_ids = [5, 9, 13, 17]
    z_vals = [lm[i].z for i in mcp_ids]
    z_spread = max(z_vals) - min(z_vals)
    palm_flatness = clamp(1.0 - abs(z_spread) / max(scale, 1e-6), 0.0, 1.0)
    wrist_depth_score = (lm[0].z - lm[9].z) / scale
    thumb_side_score = (lm[4].x - lm[5].x) / scale
    tip_z = [lm[i].z for i in [4, 8, 12, 16, 20]]
    finger_depth_spread = (max(tip_z) - min(tip_z)) / scale

    return {
        "palm_normal_x": nx,
        "palm_normal_y": ny,
        "palm_normal_z": nz,
        "palm_roll": roll / 180.0,
        "palm_yaw": yaw / 180.0,
        "palm_pitch": pitch / 180.0,
        "palm_facing_score": palm_facing,
        "back_hand_score": back_hand,
        "side_hand_score": side_score,
        "palm_flatness_score": palm_flatness,
        "wrist_depth_score": wrist_depth_score,
        "thumb_side_score": thumb_side_score,
        "finger_depth_spread": finger_depth_spread,
    }


def extract_live_features(lm: List[Point]) -> Dict[str, float]:
    scale = palm_scale(lm)
    wrist = lm[0]
    features: Dict[str, float] = {}

    fingers = {
        "index": (8, 6, 5),
        "middle": (12, 10, 9),
        "ring": (16, 14, 13),
        "pinky": (20, 18, 17),
    }
    for name, (tip, pip, mcp) in fingers.items():
        features[f"{name}_tip_wrist"] = dist(lm[tip], wrist) / scale
        features[f"{name}_pip_wrist"] = dist(lm[pip], wrist) / scale
        features[f"{name}_mcp_wrist"] = dist(lm[mcp], wrist) / scale
        features[f"{name}_tip_mcp"] = dist(lm[tip], lm[mcp]) / scale
        features[f"{name}_tip_pip"] = dist(lm[tip], lm[pip]) / scale
        features[f"{name}_vertical"] = (lm[pip].y - lm[tip].y) / scale
        features[f"{name}_curl"] = (dist(lm[tip], wrist) - dist(lm[pip], wrist)) / scale
        # Extra common features, harmless if bank lacks them.
        features[f"{name}_tip_y_mcp"] = (lm[mcp].y - lm[tip].y) / scale
        features[f"{name}_tip_z_mcp"] = (lm[tip].z - lm[mcp].z) / scale

    features["thumb_tip_wrist"] = dist(lm[4], wrist) / scale
    features["thumb_ip_wrist"] = dist(lm[3], wrist) / scale
    features["thumb_tip_index_mcp"] = dist(lm[4], lm[5]) / scale
    features["thumb_tip_index_tip"] = dist(lm[4], lm[8]) / scale
    features["thumb_tip_middle_tip"] = dist(lm[4], lm[12]) / scale
    features["thumb_horizontal"] = abs(lm[4].x - lm[3].x) / scale
    features["thumb_vertical"] = abs(lm[4].y - lm[3].y) / scale
    features["thumb_tip_palm"] = dist(lm[4], lm[9]) / scale

    features["index_middle_spread"] = dist(lm[8], lm[12]) / scale
    features["middle_ring_spread"] = dist(lm[12], lm[16]) / scale
    features["ring_pinky_spread"] = dist(lm[16], lm[20]) / scale
    features["index_pinky_spread"] = dist(lm[8], lm[20]) / scale
    features["index_ring_spread"] = dist(lm[8], lm[16]) / scale
    features["thumb_pinky_spread"] = dist(lm[4], lm[20]) / scale
    features["palm_width"] = dist(lm[5], lm[17]) / scale
    features["wrist_middle_mcp"] = dist(lm[0], lm[9]) / scale
    cx, cy = palm_center(lm)
    features["palm_center_x"] = cx
    features["palm_center_y"] = cy

    features.update(compute_orientation(lm))
    return features


def get_label(obj: dict) -> Optional[str]:
    for k in LABEL_KEYS:
        v = obj.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip().upper()
    return None


def get_features(obj: dict) -> Dict[str, float]:
    src = obj.get("features") if isinstance(obj.get("features"), dict) else obj
    out: Dict[str, float] = {}
    for k, v in src.items():
        if k in NON_FEATURE_KEYS:
            continue
        if isinstance(v, (int, float)) and math.isfinite(float(v)):
            out[k] = float(v)
    return out


def orientation_bucket(feat: Dict[str, float]) -> str:
    pf = float(feat.get("palm_facing_score", 0.0))
    bh = float(feat.get("back_hand_score", 0.0))
    sh = float(feat.get("side_hand_score", 0.0))
    if sh >= max(pf, bh) and sh > 0.40:
        return "SIDE_HAND"
    if bh >= pf and bh > 0.35:
        return "BACK_HAND"
    if pf > 0.35:
        return "PALM_FRONT"
    return "UNKNOWN"


@dataclass
class Prediction:
    label: str
    raw_label: str
    confidence: float
    margin: float
    orientation: str
    reason: str
    ok: bool
    votes: Dict[str, float]


class RobustKNNRuntime:
    def __init__(self, bank_path: Path, k: int = 13, orientation_weight: float = 0.45):
        self.bank_path = bank_path
        self.k = int(k)
        self.orientation_weight = float(orientation_weight)
        self.samples: List[Tuple[str, Dict[str, float]]] = []
        self.keys: List[str] = []
        self.mean: Dict[str, float] = {}
        self.std: Dict[str, float] = {}
        self.weights: Dict[str, float] = {}
        self.counts: Counter[str] = Counter()
        self.load()

    def load(self) -> None:
        rows: List[Tuple[str, Dict[str, float]]] = []
        for line in self.bank_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            label = get_label(obj)
            feat = get_features(obj)
            if not label or label not in LABELS or len(feat) < 12:
                continue
            rows.append((label, feat))
        if len(rows) < 20:
            raise RuntimeError(f"Banco insuficiente o ilegible: {self.bank_path} ({len(rows)} muestras válidas)")

        feat_counts = Counter()
        for _, feat in rows:
            for k in feat:
                if k not in META_KEYS and isinstance(feat[k], (int, float)):
                    feat_counts[k] += 1
        min_count = max(10, int(len(rows) * 0.25))
        keys = sorted(k for k, c in feat_counts.items() if c >= min_count)
        if len(keys) < 15:
            raise RuntimeError(f"Muy pocas features útiles compartidas: {len(keys)}")

        # Balance: cap per label so PINCH doesn't become king of the dataset for no reason.
        by_label: Dict[str, List[Dict[str, float]]] = defaultdict(list)
        for label, feat in rows:
            by_label[label].append(feat)
        cap = max(220, int(np.median([len(v) for v in by_label.values()])))
        balanced: List[Tuple[str, Dict[str, float]]] = []
        for label in LABELS:
            feats = by_label.get(label, [])
            if len(feats) > cap:
                step = len(feats) / cap
                feats = [feats[int(i * step)] for i in range(cap)]
            balanced.extend((label, f) for f in feats)

        vals_by_key: Dict[str, List[float]] = {k: [] for k in keys}
        for _, feat in balanced:
            for k in keys:
                if k in feat and math.isfinite(float(feat[k])):
                    vals_by_key[k].append(float(feat[k]))
        for k in keys:
            vals = vals_by_key[k]
            m = float(np.mean(vals)) if vals else 0.0
            s = float(np.std(vals)) if len(vals) > 1 else 1.0
            self.mean[k] = m
            self.std[k] = max(s, 0.055)

        self.weights = {}
        for k in keys:
            w = 1.0
            if k in ORIENTATION_KEYS or k.startswith("palm_normal") or k.startswith("palm_") or "depth" in k or "roll" in k or "yaw" in k or "pitch" in k:
                w = self.orientation_weight
            if "thumb_tip_index_tip" in k or "pinch" in k:
                w *= 1.25
            if "curl" in k or "vertical" in k or "tip_mcp" in k or "tip_wrist" in k:
                w *= 1.10
            self.weights[k] = w

        self.samples = balanced
        self.keys = keys
        self.counts = Counter(label for label, _ in balanced)
        print(f"[TLETL V4.8 Clean Runtime] Banco cargado: {len(self.samples)} muestras, {len(self.keys)} features, labels={dict(self.counts)}")

    def distance(self, a: Dict[str, float], b: Dict[str, float]) -> float:
        total = 0.0
        used = 0
        for k in self.keys:
            if k not in a or k not in b:
                continue
            av = float(a[k])
            bv = float(b[k])
            if not math.isfinite(av) or not math.isfinite(bv):
                continue
            z = (av - bv) / self.std[k]
            total += self.weights[k] * z * z
            used += 1
        if used < max(10, int(len(self.keys) * 0.35)):
            return 1e9
        return math.sqrt(total / max(used, 1))

    def predict(self, feat: Dict[str, float], strict: bool = True) -> Prediction:
        dists: List[Tuple[float, str]] = []
        for label, sample in self.samples:
            d = self.distance(feat, sample)
            if math.isfinite(d):
                dists.append((d, label))
        dists.sort(key=lambda x: x[0])
        neighbors = dists[: self.k]
        votes: Dict[str, float] = defaultdict(float)
        for d, label in neighbors:
            votes[label] += 1.0 / (d + 1e-6)
        if not votes:
            return Prediction("NEUTRAL", "UNKNOWN", 0.0, 0.0, orientation_bucket(feat), "NO_VOTES", False, {})
        ordered = sorted(votes.items(), key=lambda x: x[1], reverse=True)
        raw = ordered[0][0]
        top = ordered[0][1]
        second = ordered[1][1] if len(ordered) > 1 else 0.0
        total = sum(votes.values())
        conf = float(top / max(total, 1e-9))
        margin = float((top - second) / max(total, 1e-9))

        reason = "OK"
        ok = True
        if strict:
            if conf < 0.47:
                ok = False
                reason = "LOW_CONFIDENCE"
            elif margin < 0.18:
                ok = False
                reason = "LOW_MARGIN"
            elif len(neighbors) >= 5 and sum(1 for _, l in neighbors[:5] if l == raw) < 3:
                ok = False
                reason = "SPLIT_NEIGHBORS"
        final = raw if ok else "NEUTRAL"
        return Prediction(final, raw, conf, margin, orientation_bucket(feat), reason, ok, dict(votes))


class TemporalFilter:
    def __init__(self, size: int = 7, min_count: int = 4):
        self.history: Deque[str] = deque(maxlen=size)
        self.last = "NEUTRAL"
        self.min_count = min_count

    def update(self, pred: Prediction) -> Prediction:
        if pred.ok:
            self.history.append(pred.raw_label)
        else:
            self.history.append("NEUTRAL")
        if len(self.history) < self.history.maxlen:
            return Prediction("NEUTRAL", pred.raw_label, pred.confidence, pred.margin, pred.orientation, "WARMING_UP", False, pred.votes)
        label, count = Counter(self.history).most_common(1)[0]
        if count >= self.min_count:
            self.last = label
            if pred.ok and label == pred.raw_label:
                return Prediction(label, pred.raw_label, pred.confidence, pred.margin, pred.orientation, pred.reason, True, pred.votes)
            return Prediction(label, pred.raw_label, pred.confidence, pred.margin, pred.orientation, "TEMPORAL_HOLD", label != "NEUTRAL", pred.votes)
        return Prediction(self.last, pred.raw_label, pred.confidence, pred.margin, pred.orientation, "UNSTABLE_TEMPORAL", False, pred.votes)

    def reset(self) -> None:
        self.history.clear()
        self.last = "NEUTRAL"


class MotionTracker:
    def __init__(self, maxlen: int = 9):
        self.points: Deque[Tuple[float, float, float]] = deque(maxlen=maxlen)
        self.last_swipe_time = 0.0
        self.last_velocity = 0.0

    def update(self, x: float, y: float) -> None:
        now = time.time()
        if self.points:
            t0, x0, y0 = self.points[-1]
            dt = max(now - t0, 1e-3)
            self.last_velocity = math.sqrt((x - x0) ** 2 + (y - y0) ** 2) / dt
        self.points.append((now, x, y))

    def swipe(self) -> Optional[str]:
        if len(self.points) < 5:
            return None
        now = time.time()
        if now - self.last_swipe_time < 0.55:
            return None
        t0, x0, y0 = self.points[0]
        t1, x1, y1 = self.points[-1]
        dt = max(t1 - t0, 1e-3)
        dx = x1 - x0
        dy = y1 - y0
        if dt <= 0.90 and abs(dx) > 0.12 and abs(dx) > abs(dy) * 1.45:
            self.last_swipe_time = now
            self.points.clear()
            return "RIGHT" if dx > 0 else "LEFT"
        if dt <= 0.90 and abs(dy) > 0.12 and abs(dy) > abs(dx) * 1.45:
            self.last_swipe_time = now
            self.points.clear()
            return "DOWN" if dy > 0 else "UP"
        return None

    def reset(self) -> None:
        self.points.clear()
        self.last_velocity = 0.0


class CursorDelta:
    def __init__(self):
        self.prev: Optional[Tuple[float, float]] = None

    def update(self, x: float, y: float, gain: int = 1550, max_step: int = 70) -> Tuple[int, int]:
        if self.prev is None:
            self.prev = (x, y)
            return 0, 0
        px, py = self.prev
        self.prev = (x, y)
        dx = x - px
        dy = y - py
        if abs(dx) < 0.0045:
            dx = 0.0
        if abs(dy) < 0.0045:
            dy = 0.0
        return int(clamp(dx * gain, -max_step, max_step)), int(clamp(dy * gain, -max_step, max_step))

    def reset(self) -> None:
        self.prev = None


class Hold:
    def __init__(self):
        self.name: Optional[str] = None
        self.t0 = 0.0

    def progress(self, name: str, seconds: float) -> float:
        now = time.time()
        if self.name != name:
            self.name = name
            self.t0 = now
        return clamp((now - self.t0) / max(seconds, 1e-3), 0.0, 1.0)

    def reset(self) -> None:
        self.name = None
        self.t0 = 0.0


class Actions:
    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run

    def run(self, cmd: List[str], label: str) -> None:
        if self.dry_run:
            print(f"[DRY] {label}: {' '.join(cmd)}")
            return
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        except Exception as exc:
            print(f"[ydotool error] {exc}")

    def key(self, seq: str, label: str) -> None:
        self.run(["ydotool", "key", *seq.split()], label)

    def click_left(self) -> None: self.run(["ydotool", "click", "0xC0"], "click_left")
    def click_right(self) -> None: self.run(["ydotool", "click", "0xC1"], "click_right")
    def mouse_down(self) -> None: self.run(["ydotool", "click", "0x40"], "mouse_down")
    def mouse_up(self) -> None: self.run(["ydotool", "click", "0x80"], "mouse_up")
    def mousemove(self, dx: int, dy: int) -> None:
        if dx or dy:
            self.run(["ydotool", "mousemove", "-x", str(dx), "-y", str(dy)], f"mousemove {dx},{dy}")
    def scroll_down(self) -> None: self.key("108:1 108:0", "scroll_down")
    def scroll_up(self) -> None: self.key("103:1 103:0", "scroll_up")
    def page_down(self) -> None: self.key("109:1 109:0", "page_down")
    def page_up(self) -> None: self.key("104:1 104:0", "page_up")
    def next_tab(self) -> None: self.key("29:1 15:1 15:0 29:0", "next_tab")
    def prev_tab(self) -> None: self.key("29:1 42:1 15:1 15:0 42:0 29:0", "prev_tab")
    def back(self) -> None: self.key("56:1 105:1 105:0 56:0", "browser_back")
    def forward(self) -> None: self.key("56:1 106:1 106:0 56:0", "browser_forward")
    def overview(self) -> None: self.key("125:1 125:0", "overview")
    def enter(self) -> None: self.key("28:1 28:0", "enter")


def draw_panel(frame: np.ndarray, lines: List[str], color: Tuple[int, int, int]) -> None:
    h, w = frame.shape[:2]
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (w - 10, 190), (10, 10, 10), -1)
    cv2.addWeighted(overlay, 0.68, frame, 0.32, 0, frame)
    y = 35
    for i, line in enumerate(lines):
        c = color if i == 0 else (255, 255, 255)
        cv2.putText(frame, line, (22, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, c, 2, cv2.LINE_AA)
        y += 26
    cv2.line(frame, (0, int(h * 0.39)), (w, int(h * 0.39)), (255, 255, 0), 1)
    cv2.line(frame, (0, int(h * 0.61)), (w, int(h * 0.61)), (255, 255, 0), 1)


def open_camera(index: int, width: int, height: int, fps: int) -> cv2.VideoCapture:
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"No pude abrir cámara {index}. Prueba --camera 1 o --camera 2.")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def run(args: argparse.Namespace) -> int:
    bank = Path(args.bank).expanduser().resolve()
    strict = os.environ.get("TLETL_AI_V48_STRICT", "1") != "0"
    temporal_enabled = os.environ.get("TLETL_AI_V48_TEMPORAL", "1") != "0"
    orientation_weight = float(os.environ.get("TLETL_AI_V48_ORIENTATION_WEIGHT", "0.45"))
    dry_run = args.dry_run or os.environ.get("TLETL_DRY_RUN", "0") == "1"

    runtime = RobustKNNRuntime(bank, k=args.k, orientation_weight=orientation_weight)
    cap = open_camera(args.camera, args.width, args.height, args.fps)
    actions = Actions(dry_run=dry_run)
    temporal = TemporalFilter(size=7, min_count=4)
    motion = MotionTracker()
    cursor = CursorDelta()
    hold_toggle = Hold()
    hold_mode = Hold()

    modes = ["NAVEGADOR", "CURSOR", "VENTANAS"]
    mode_i = 0
    control = False
    last_action = "-"
    last_click = 0.0
    last_scroll = 0.0
    last_tab = 0.0
    last_big = 0.0
    last_toggle = 0.0
    drag = False
    pinch_t0: Optional[float] = None

    window = "Tletl V4.8 Clean AI"
    cv2.namedWindow(window, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window, args.width, args.height)

    prev_t = time.time()
    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=1,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands_model:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("No pude leer frame.")
                break
            frame = cv2.flip(frame, 1)
            now = time.time()
            fps = 1.0 / max(now - prev_t, 1e-6)
            prev_t = now

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = hands_model.process(rgb)

            pred = Prediction("NO_HAND", "NO_HAND", 0.0, 0.0, "-", "NO_HAND", False, {})
            cx = cy = 0.0
            swipe = None
            hand_seen = False
            toggle_progress = 0.0
            mode_progress = 0.0

            if result.multi_hand_landmarks:
                hand_seen = True
                hand_landmarks = result.multi_hand_landmarks[0]
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                lm = points_from_mediapipe(hand_landmarks)
                feat = extract_live_features(lm)
                cx, cy = palm_center(lm)
                motion.update(cx, cy)
                swipe = motion.swipe()
                raw_pred = runtime.predict(feat, strict=strict)
                pred = temporal.update(raw_pred) if temporal_enabled else raw_pred
                px, py = int(cx * frame.shape[1]), int(cy * frame.shape[0])
                cv2.circle(frame, (px, py), 12, (0, 255, 255), 2)
                cv2.putText(frame, f"{pred.label}/{pred.raw_label} {pred.confidence:.2f}", (px - 70, py - 25),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.50, (0, 255, 255), 2, cv2.LINE_AA)
            else:
                motion.reset()
                cursor.reset()
                temporal.reset()
                hold_toggle.reset()
                hold_mode.reset()
                if drag:
                    actions.mouse_up()
                    drag = False
                pinch_t0 = None

            # Toggle: open palm hold. Uses final label, not raw dinosaur rules.
            if hand_seen and pred.label == "OPEN_PALM":
                required = 2.0 if control else 1.25
                toggle_progress = hold_toggle.progress("OPEN_PALM", required)
                if toggle_progress >= 1.0 and now - last_toggle > 1.0:
                    control = not control
                    last_toggle = now
                    hold_toggle.reset()
                    temporal.reset()
                    last_action = "Control ON" if control else "Control OFF"
                    if not control and drag:
                        actions.mouse_up(); drag = False
                    print(f"[TLETL] {last_action}")
            else:
                hold_toggle.reset()

            # Safety: fist while active disables control.
            if control and pred.label == "FIST" and pred.confidence > 0.55:
                control = False
                last_action = "Pausa seguridad"
                if drag:
                    actions.mouse_up(); drag = False
                pinch_t0 = None

            # Mode switch with THREE hold.
            if control and pred.label == "THREE":
                mode_progress = hold_mode.progress("THREE", 0.85)
                if mode_progress >= 1.0 and now - last_big > 1.0:
                    mode_i = (mode_i + 1) % len(modes)
                    last_big = now
                    hold_mode.reset()
                    temporal.reset()
                    cursor.reset()
                    last_action = f"Modo {modes[mode_i]}"
            else:
                hold_mode.reset()

            mode = modes[mode_i]
            can_act = control and hand_seen and pred.ok and pred.confidence >= args.action_conf

            if can_act:
                if mode == "NAVEGADOR":
                    if pred.label == "POINT" and now - last_scroll > 0.11:
                        if cy < 0.22:
                            actions.page_up(); last_action = "PageUp"; last_scroll = now + 0.12
                        elif cy > 0.78:
                            actions.page_down(); last_action = "PageDown"; last_scroll = now + 0.12
                        elif cy < 0.39:
                            actions.scroll_up(); last_action = "Scroll arriba"; last_scroll = now
                        elif cy > 0.61:
                            actions.scroll_down(); last_action = "Scroll abajo"; last_scroll = now
                    elif pred.label == "PINCH" and now - last_click > 0.34:
                        actions.click_left(); last_action = "Click"; last_click = now
                    elif pred.label == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab > 0.65:
                        if swipe == "RIGHT": actions.next_tab(); last_action = "Tab siguiente"
                        else: actions.prev_tab(); last_action = "Tab anterior"
                        last_tab = now
                    elif pred.label == "OPEN_PALM" and swipe in {"LEFT", "RIGHT"} and toggle_progress < 0.55 and now - last_tab > 0.75:
                        if swipe == "LEFT": actions.back(); last_action = "Atrás"
                        else: actions.forward(); last_action = "Adelante"
                        last_tab = now

                elif mode == "CURSOR":
                    if pred.label in {"POINT", "OPEN_PALM", "PINCH"}:
                        dx, dy = cursor.update(cx, cy)
                        actions.mousemove(dx, dy)
                    else:
                        cursor.reset()
                    if pred.label == "PINCH":
                        if pinch_t0 is None:
                            pinch_t0 = now
                        if not drag and now - pinch_t0 > 0.32:
                            actions.mouse_down(); drag = True; last_action = "Drag ON"
                    else:
                        if pinch_t0 is not None:
                            held = now - pinch_t0
                            if drag:
                                actions.mouse_up(); drag = False; last_action = "Drag OFF"
                            elif held < 0.24 and now - last_click > 0.28:
                                actions.click_left(); last_click = now; last_action = "Click"
                        pinch_t0 = None

                elif mode == "VENTANAS":
                    if pred.label == "OPEN_PALM" and swipe == "UP" and now - last_big > 0.9:
                        actions.overview(); last_big = now; last_action = "Overview"
                    elif pred.label == "PINCH" and now - last_click > 0.38:
                        actions.enter(); last_click = now; last_action = "Enter"
            else:
                cursor.reset()
                if drag and pred.label != "PINCH":
                    actions.mouse_up(); drag = False
                    pinch_t0 = None

            state = "ON" if control else "OFF"
            color = (0, 255, 0) if control else (0, 0, 255)
            lines = [
                f"TLETL V4.8 CLEAN AI {state} | MODO: {mode} | FPS: {fps:.1f} | DRY:{dry_run}",
                f"AI final:{pred.label} | raw:{pred.raw_label} | conf:{pred.confidence:.2f} | margin:{pred.margin:.2f} | ok:{pred.ok}",
                f"Orientation:{pred.orientation} | Critic:{pred.reason} | Swipe:{swipe or '-'} | Action:{last_action}",
                f"Runtime: KNN robusto | Strict:{strict} | Temporal:{temporal_enabled} | orient_weight:{orientation_weight:.2f}",
                "OPEN_PALM hold=ON/OFF | FIST=seguridad | THREE=modo | Q/ESC=salir",
            ]
            if toggle_progress > 0:
                lines.append(f"Toggle progress: {int(toggle_progress * 100)}%")
            if mode_progress > 0:
                lines.append(f"Mode progress: {int(mode_progress * 100)}%")
            draw_panel(frame, lines, color)
            cv2.circle(frame, (frame.shape[1] - 34, 34), 17, color, -1)

            cv2.imshow(window, frame)
            key = cv2.waitKey(1) & 0xFF
            if key in {27, ord('q')}:
                break
            elif key == ord('t'):
                control = not control
                last_action = "Control ON tecla" if control else "Control OFF tecla"
            elif key == ord('m'):
                mode_i = (mode_i + 1) % len(modes)
                last_action = f"Modo {modes[mode_i]} tecla"

    if drag:
        actions.mouse_up()
    cap.release()
    cv2.destroyAllWindows()
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=APP)
    ap.add_argument("--bank", default=os.environ.get("TLETL_GESTURE_BANK", "datasets/tletl_gesture_bank_v2_features.jsonl"))
    ap.add_argument("--camera", type=int, default=int(os.environ.get("TLETL_CAMERA", "0")))
    ap.add_argument("--width", type=int, default=960)
    ap.add_argument("--height", type=int, default=540)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--det-conf", type=float, default=0.72)
    ap.add_argument("--track-conf", type=float, default=0.72)
    ap.add_argument("--action-conf", type=float, default=0.52)
    ap.add_argument("--k", type=int, default=13)
    ap.add_argument("--dry-run", action="store_true")
    return ap


if __name__ == "__main__":
    try:
        raise SystemExit(run(build_parser().parse_args()))
    except KeyboardInterrupt:
        print("\n[TLETL] Interrumpido.")
    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        print("Tips: prueba --camera 1, o TLETL_DRY_RUN=1 ./launchers/tletl-run-v48-clean-ai.sh")
        raise
