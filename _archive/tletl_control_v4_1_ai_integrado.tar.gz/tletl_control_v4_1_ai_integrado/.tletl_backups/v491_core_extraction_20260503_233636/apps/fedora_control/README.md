# Fedora Control

App activa para Fedora/navegador.

Launcher oficial:
- ../../launchers/tletl-run-current.sh
