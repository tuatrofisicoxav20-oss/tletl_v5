"""
Tletl Core común.

Cerebro compartido entre:
- Fedora/navegador
- Blender
- futuros adaptadores

No debe ejecutar acciones directas del sistema.
Solo debe detectar, clasificar, estabilizar y producir estado/intención.
"""

__version__ = "4.9-core-split"
