# Tletl Core

Núcleo común de Tletl.

Reglas:
- `tletl_core` no ejecuta acciones del sistema.
- No depende de Blender.
- No depende de ydotool.
- Solo produce estado, gesto, orientación, confianza, crítico e intención.
