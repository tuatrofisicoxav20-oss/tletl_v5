#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
cd "$PROJECT"

exec ./launchers/tletl-run-v48-clean-ai.sh "$@"
