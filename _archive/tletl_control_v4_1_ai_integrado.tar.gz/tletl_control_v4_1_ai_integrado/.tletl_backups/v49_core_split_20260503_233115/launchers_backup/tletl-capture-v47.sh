#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"

export YDOTOOL_SOCKET=/tmp/.ydotool_socket
export TLETL_GESTURE_BANK="$BANK"
export TLETL_BANK_PATH="$BANK"
export TLETL_DATASET_PATH="$BANK"

mkdir -p "$PROJECT/datasets"
touch "$BANK"

LABEL="${1:-}"

VALID_LABELS="OPEN_PALM FIST POINT VICTORY PINCH THREE NEUTRAL"

if [[ -z "$LABEL" ]]; then
  echo
  echo "TLETL V4.7 CAPTURE"
  echo "=================="
  echo "Elige gesto:"
  echo "1) OPEN_PALM"
  echo "2) FIST"
  echo "3) POINT"
  echo "4) VICTORY"
  echo "5) PINCH"
  echo "6) THREE"
  echo "7) NEUTRAL"
  echo
  read -rp "Número: " choice

  case "$choice" in
    1) LABEL="OPEN_PALM" ;;
    2) LABEL="FIST" ;;
    3) LABEL="POINT" ;;
    4) LABEL="VICTORY" ;;
    5) LABEL="PINCH" ;;
    6) LABEL="THREE" ;;
    7) LABEL="NEUTRAL" ;;
    *) echo "Opción inválida."; exit 1 ;;
  esac
fi

if ! echo "$VALID_LABELS" | grep -qw "$LABEL"; then
  echo "Label inválida: $LABEL"
  echo "Usa una de estas:"
  echo "$VALID_LABELS"
  exit 1
fi

echo
echo "TLETL V4.7 CAPTURE"
echo "=================="
echo "Proyecto: $PROJECT"
echo "Python:   $(python --version)"
echo "Banco:    $BANK"
echo "Gesto:    $LABEL"
echo

if [[ "$(python - <<'PY'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PY
)" != "3.12" ]]; then
  echo "ERROR: No estás usando Python 3.12. MediaPipe se puede poner dramático."
  exit 1
fi

BACKUP_DIR="$PROJECT/datasets/backups_v47"
mkdir -p "$BACKUP_DIR"

if [[ -s "$BANK" ]]; then
  cp -v "$BANK" "$BACKUP_DIR/tletl_gesture_bank_v2_features_before_capture_$(date +%Y%m%d_%H%M%S).jsonl" >/dev/null
  echo "Backup creado en datasets/backups_v47/"
fi

echo
echo "Antes de capturar:"
python tools/tletl_orientation_coverage.py "$BANK" || true

echo
echo "Iniciando captura para: $LABEL"
echo "Tip: captura variaciones de palma, dorso, lateral e inclinada."
echo

HELP_TEXT="$(python train_gesture_lab.py --help 2>&1 || true)"

CMD=(python train_gesture_lab.py)

if echo "$HELP_TEXT" | grep -q -- "--label"; then
  CMD+=(--label "$LABEL")
elif echo "$HELP_TEXT" | grep -q -- "--gesture"; then
  CMD+=(--gesture "$LABEL")
elif echo "$HELP_TEXT" | grep -q -- "--class"; then
  CMD+=(--class "$LABEL")
fi

if echo "$HELP_TEXT" | grep -q -- "--bank"; then
  CMD+=(--bank "$BANK")
elif echo "$HELP_TEXT" | grep -q -- "--dataset"; then
  CMD+=(--dataset "$BANK")
elif echo "$HELP_TEXT" | grep -q -- "--output"; then
  CMD+=(--output "$BANK")
elif echo "$HELP_TEXT" | grep -q -- "--out"; then
  CMD+=(--out "$BANK")
fi

echo "Comando:"
printf ' %q' "${CMD[@]}"
echo
echo

"${CMD[@]}"

echo
echo "Después de capturar:"
python tools/tletl_orientation_coverage.py "$BANK" || true

echo
echo "Listo. Si la cobertura sigue en 0%, el capturador todavía no está guardando orientación."
