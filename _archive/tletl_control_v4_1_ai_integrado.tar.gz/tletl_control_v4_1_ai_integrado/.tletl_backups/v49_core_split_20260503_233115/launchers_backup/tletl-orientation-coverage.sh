#!/usr/bin/env bash
set -euo pipefail
cd "/home/exitili/Documentos/tletl_control_v4_1_ai_integrado"
source "/home/exitili/Documentos/tletl_control_v4_modular/.venv/bin/activate"
python tools/tletl_orientation_coverage.py datasets/tletl_gesture_bank_v2_features.jsonl
