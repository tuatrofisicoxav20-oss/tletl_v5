#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"

export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"
export YDOTOOL_SOCKET="${YDOTOOL_SOCKET:-/tmp/.ydotool_socket}"

export TLETL_GESTURE_BANK="$BANK"
export TLETL_BANK_PATH="$BANK"
export TLETL_DATASET_PATH="$BANK"

# Runtime limpio. No usa la UI vieja ni el controller viejo.
export TLETL_AI_V48_CLEAN=1
export TLETL_AI_V48_STRICT="${TLETL_AI_V48_STRICT:-1}"
export TLETL_AI_V48_TEMPORAL="${TLETL_AI_V48_TEMPORAL:-1}"
export TLETL_AI_V48_ORIENTATION_WEIGHT="${TLETL_AI_V48_ORIENTATION_WEIGHT:-0.45}"
export TLETL_DRY_RUN="${TLETL_DRY_RUN:-0}"

printf '\nTLETL V4.8 CLEAN AI UI\n'
printf '======================\n'
printf 'Proyecto: %s\n' "$PROJECT"
printf 'Python:   %s\n' "$(python --version)"
printf 'Banco:    %s\n' "$BANK"
printf 'Dry run:  %s\n' "$TLETL_DRY_RUN"
printf '\n'

python tools/tletl_v48_bank_probe.py --bank "$BANK" || true
printf '\nArrancando UI limpia V4.8...\n\n'
python main_v48_clean_ai.py --bank "$BANK"
