"""
Tletl V4.7 - orientación de mano.

Objetivo:
- NO separar etiquetas por palma/dorso.
- Extraer orientación como features internas.
- Funcionar con landmarks de MediaPipe: objetos con .x/.y/.z, dicts o tuplas/listas.

Notas:
MediaPipe no da una normal física perfecta de la palma. Esto calcula una normal geométrica
estable a partir de muñeca + nudillos. Es suficientemente buena para clasificador y crítico;
si alguien esperaba rayos X de una webcam de laptop, felicidades, acaba de descubrir límites
del universo barato.
"""

from __future__ import annotations

import math
from typing import Any, Dict, Iterable, Optional

import numpy as np


ORIENTATION_FEATURE_KEYS = [
    "palm_normal_x",
    "palm_normal_y",
    "palm_normal_z",
    "palm_roll",
    "palm_yaw",
    "palm_pitch",
    "palm_facing_score",
    "back_hand_score",
    "side_hand_score",
    "palm_flatness_score",
    "wrist_depth_score",
    "thumb_side_score",
    "finger_depth_spread",
]


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def _sigmoid(x: float) -> float:
    x = max(-60.0, min(60.0, float(x)))
    return 1.0 / (1.0 + math.exp(-x))


def _as_xyz(point: Any) -> tuple[float, float, float]:
    if hasattr(point, "x") and hasattr(point, "y"):
        return float(point.x), float(point.y), float(getattr(point, "z", 0.0))
    if isinstance(point, dict):
        return float(point.get("x", 0.0)), float(point.get("y", 0.0)), float(point.get("z", 0.0))
    if isinstance(point, (list, tuple)):
        x = float(point[0]) if len(point) > 0 else 0.0
        y = float(point[1]) if len(point) > 1 else 0.0
        z = float(point[2]) if len(point) > 2 else 0.0
        return x, y, z
    raise TypeError(f"Landmark no compatible: {type(point)!r}")


def landmarks_to_np(landmarks: Any) -> np.ndarray:
    if hasattr(landmarks, "landmark"):
        landmarks = landmarks.landmark
    pts = [_as_xyz(p) for p in landmarks]
    arr = np.asarray(pts, dtype=float)
    if arr.shape[0] < 21 or arr.shape[1] < 3:
        raise ValueError(f"Se esperaban 21 landmarks con x/y/z, recibí shape={arr.shape}")
    return arr[:21, :3]


def _norm(vec: np.ndarray, eps: float = 1e-9) -> float:
    return float(np.linalg.norm(vec) + eps)


def _unit(vec: np.ndarray, eps: float = 1e-9) -> np.ndarray:
    n = _norm(vec, eps)
    if n <= eps * 2:
        return np.zeros(3, dtype=float)
    return vec / n


def _scale(lm: np.ndarray) -> float:
    wrist_to_middle = _norm(lm[9] - lm[0])
    palm_width = _norm(lm[17] - lm[5])
    return max((wrist_to_middle + palm_width) / 2.0, 1e-6)


def _std(values: Iterable[float]) -> float:
    vals = list(values)
    if not vals:
        return 0.0
    return float(np.std(np.asarray(vals, dtype=float)))


def extract_orientation_features(landmarks: Any, handedness: Optional[str] = None) -> Dict[str, float]:
    """
    Devuelve las 13 features de orientación pedidas para Tletl V4.7.

    handedness:
      "Left" / "Right" de MediaPipe si está disponible.
      Sirve para mantener una normal más consistente entre manos, pero el clasificador
      también puede aprender aunque no se lo pases.
    """
    try:
        lm = landmarks_to_np(landmarks)
        scale = _scale(lm)

        wrist = lm[0]
        index_mcp = lm[5]
        middle_mcp = lm[9]
        ring_mcp = lm[13]
        pinky_mcp = lm[17]
        thumb_tip = lm[4]

        # Ejes locales de la palma:
        # across: de índice a meñique.
        # up: de muñeca a nudillo medio.
        across = pinky_mcp - index_mcp
        up = middle_mcp - wrist

        normal = _unit(np.cross(across, up))

        # MediaPipe puede invertir consistencia por mano. Esto no pretende ser "verdad
        # anatómica absoluta"; pretende que el vector sea estable para aprendizaje.
        if handedness and str(handedness).lower().startswith("left"):
            normal = -normal

        nx, ny, nz = [float(x) for x in normal]
        across_u = _unit(across)

        # Ángulos en grados. Roll usa la línea nudillos índice-meñique en pantalla.
        palm_roll = math.degrees(math.atan2(across_u[1], across_u[0]))
        palm_yaw = math.degrees(math.atan2(nx, max(abs(nz), 1e-6)))
        palm_pitch = math.degrees(math.atan2(-ny, max(abs(nz), 1e-6)))

        # En MediaPipe, z negativo suele ser más cerca de la cámara.
        # Si tu cámara/flip invierte esto, el clasificador lo aprende porque guardamos
        # normal_z y no solo el score semántico.
        palm_facing_score = _sigmoid(-5.0 * nz)
        back_hand_score = _sigmoid(5.0 * nz)
        side_hand_score = _clamp(abs(nx) * 1.35)

        palm_anchor_ids = [0, 5, 9, 13, 17]
        palm_z_std = _std(lm[i, 2] for i in palm_anchor_ids)
        palm_flatness_score = 1.0 - _clamp(palm_z_std / max(scale * 0.24, 1e-6))

        mcp_mean_z = float(np.mean([index_mcp[2], middle_mcp[2], ring_mcp[2], pinky_mcp[2]]))
        # Score 0..1: muñeca más atras/adelante respecto a nudillos.
        wrist_depth_score = _sigmoid(4.0 * ((wrist[2] - mcp_mean_z) / scale))

        # Lado del pulgar respecto al eje índice->meñique. Firmado, comprimido a [-1, 1].
        thumb_vec = thumb_tip - wrist
        thumb_side_raw = float(np.dot(thumb_vec, across_u) / scale)
        thumb_side_score = max(-1.0, min(1.0, thumb_side_raw))

        finger_tip_ids = [8, 12, 16, 20]
        finger_depth_spread = _clamp(_std(lm[i, 2] for i in finger_tip_ids) / max(scale * 0.55, 1e-6))

        return {
            "palm_normal_x": round(nx, 6),
            "palm_normal_y": round(ny, 6),
            "palm_normal_z": round(nz, 6),
            "palm_roll": round(palm_roll, 6),
            "palm_yaw": round(palm_yaw, 6),
            "palm_pitch": round(palm_pitch, 6),
            "palm_facing_score": round(palm_facing_score, 6),
            "back_hand_score": round(back_hand_score, 6),
            "side_hand_score": round(side_hand_score, 6),
            "palm_flatness_score": round(palm_flatness_score, 6),
            "wrist_depth_score": round(wrist_depth_score, 6),
            "thumb_side_score": round(thumb_side_score, 6),
            "finger_depth_spread": round(finger_depth_spread, 6),
        }
    except Exception:
        # Fallback silencioso para no matar runtime por un frame raro.
        # El crítico detectará ausencia/ceros y bajará confianza.
        return {key: 0.0 for key in ORIENTATION_FEATURE_KEYS}


def has_orientation_features(features: Dict[str, Any], strict: bool = True) -> bool:
    if not isinstance(features, dict):
        return False
    if strict:
        return all(k in features and isinstance(features.get(k), (int, float)) for k in ORIENTATION_FEATURE_KEYS)
    return any(k in features and isinstance(features.get(k), (int, float)) for k in ORIENTATION_FEATURE_KEYS)


def orientation_summary(features: Dict[str, Any]) -> str:
    if not has_orientation_features(features, strict=False):
        return "ORIENTATION:missing"

    palm = float(features.get("palm_facing_score", 0.0))
    back = float(features.get("back_hand_score", 0.0))
    side = float(features.get("side_hand_score", 0.0))
    flat = float(features.get("palm_flatness_score", 0.0))

    if side >= 0.64 and side >= palm * 0.90 and side >= back * 0.90:
        label = "SIDE_HAND"
        score = side
    elif palm >= back:
        label = "PALM_FRONT"
        score = palm
    else:
        label = "BACK_HAND"
        score = back

    return f"{label} {score:.2f} flat={flat:.2f}"


def orientation_label(features: Dict[str, Any]) -> str:
    text = orientation_summary(features)
    return text.split(" ", 1)[0] if text else "UNKNOWN"
