import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import mediapipe as mp

from .actions import ActionRunner
from .yolo_pose_helper import YOLOPoseContext
from .ai_bank import KEY_TO_GESTURE
from .ai_runtime import GestureAI
from .constants import (
    APP_NAME, ACTION_COOLDOWN, BIG_ACTION_COOLDOWN, CLICK_MAX_SECONDS, DEFAULT_ADAPTIVE_MEMORY_PATH,
    DEFAULT_PROFILE_PATH, DOWN_ZONE, DRAG_START_SECONDS, EXTREME_DOWN_ZONE, EXTREME_UP_ZONE,
    FIST_COOLDOWN, MODE_HOLD_SECONDS, MODES, SWIPE_COOLDOWN, TAB_ACTION_COOLDOWN,
    TOGGLE_COOLDOWN, TOGGLE_HOLD_OFF_SECONDS, TOGGLE_HOLD_ON_SECONDS, UP_ZONE,
    CAMERA_WIDTH, CAMERA_HEIGHT, CAMERA_FPS, MIN_DETECTION_CONFIDENCE, MIN_TRACKING_CONFIDENCE,
    MODEL_COMPLEXITY, GESTURE_HISTORY_SIZE, STABLE_GESTURE_MIN_COUNT, SMOOTHING_SLOW_ALPHA,
    SMOOTHING_FAST_ALPHA, FAST_MOTION_THRESHOLD, CURSOR_GAIN, CURSOR_MAX_STEP, CURSOR_DEADZONE
)
from .filters import HoldTimer, TwoHandDistanceTracker
from .low_light import LowLightEnhancer
from .profile import AdaptiveGestureMemory, build_profile_ensemble, load_profile_optional
from .state import DetectedHand, HandState
from .ui import StatusNotifier, draw_progress_bar, draw_text_box, draw_zones
from .vision import detect_hands, open_camera


mp_hands = mp.solutions.hands


def hand_summary(hand: Optional[DetectedHand]) -> str:
    if not hand:
        return "-"
    return f"{hand.label}:{hand.action_gesture}/{hand.stable_gesture} {hand.confidence:.2f}"


def any_hand_with(hands: List[DetectedHand], gesture: str) -> bool:
    return any(h.action_gesture == gesture or h.stable_gesture == gesture for h in hands)


def both_stable(hands: List[DetectedHand], gesture: str) -> bool:
    return len(hands) >= 2 and all(h.stable_gesture == gesture for h in hands[:2])


def choose_main_hand(hands: List[DetectedHand]) -> Tuple[Optional[DetectedHand], Optional[DetectedHand]]:
    if not hands:
        return None, None
    main = hands[0]
    second = hands[1] if len(hands) > 1 else None
    return main, second


class TletlRuntime:
    """Orquestador principal.

    Este archivo NO detecta dedos, NO dibuja estado bajo nivel y NO sabe de perfiles internos.
    Solo conecta capas. Así deja de ser un monstruo de 900 líneas con crisis existencial.
    """

    def __init__(self, args):
        self.args = args

        profile_path = Path(args.profile).expanduser().resolve()
        self.base_profile = load_profile_optional(profile_path)

        self.adaptive_memory = AdaptiveGestureMemory(
            Path(args.adaptive_memory).expanduser().resolve(),
            enabled=not args.no_adaptive_learning,
            max_samples=args.adaptive_max_samples,
            min_conf=args.adaptive_min_conf,
            save_seconds=args.adaptive_save_seconds,
        )
        self.adaptive_profile = self.adaptive_memory.to_profile()
        self.profile = build_profile_ensemble(self.base_profile, self.adaptive_profile)
        self.last_adaptive_rebuild = 0.0

        self.gesture_ai = GestureAI(
            Path(args.ai_dataset).expanduser().resolve(),
            enabled=args.ai,
            k=args.ai_k,
            min_conf=args.ai_min_conf,
            auto_learn=args.ai_auto_learn,
            auto_learn_conf=args.ai_auto_conf,
        )

        if "YDOTOOL_SOCKET" not in os.environ and Path("/tmp/.ydotool_socket").exists():
            os.environ["YDOTOOL_SOCKET"] = "/tmp/.ydotool_socket"

        self.cap = open_camera(args.camera, args.width, args.height, args.fps)
        self.enhancer = LowLightEnhancer(enabled=not args.no_low_light)
        self.states: Dict[str, HandState] = {}
        self.actions = ActionRunner(dry_run=args.dry_run)
        self.hold_toggle = HoldTimer()
        self.hold_mode = HoldTimer()
        self.two_hand_distance = TwoHandDistanceTracker()

        self.mode_index = 0
        self.control_enabled = False

        self.last_toggle_time = 0.0
        self.last_fist_time = 0.0
        self.last_action_time = 0.0
        self.last_tab_time = 0.0
        self.last_big_time = 0.0
        self.last_mode_time = 0.0
        self.last_pinch_time = 0.0
        self.last_modifier_time = 0.0
        self.last_action_label = "-"

        self.pinch_active = False
        self.pinch_started_at = 0.0
        self.drag_active = False

        cv2.namedWindow(APP_NAME, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(APP_NAME, args.width, args.height)
        self.notifier = StatusNotifier(enabled=not args.no_status_window, backend=args.status_backend)
        self.yolo_pose = None
        if getattr(args, "yolo_pose", False):
            self.yolo_pose = YOLOPoseContext(
                getattr(args, "yolo_model", "yolo11n-pose.pt"),
                every_n=getattr(args, "yolo_every_n", 3),
                conf=getattr(args, "yolo_conf", 0.35),
            )

    @property
    def mode(self) -> str:
        return MODES[self.mode_index]

    def close(self):
        self.adaptive_memory.save_if_needed(force=True)
        self.notifier.close()
        self.cap.release()
        cv2.destroyAllWindows()

    def rebuild_adaptive_profile_if_needed(self, now: float):
        if not self.adaptive_memory.enabled:
            return
        if now - self.last_adaptive_rebuild > max(self.args.adaptive_rebuild_seconds, 1.0):
            self.adaptive_profile = self.adaptive_memory.to_profile()
            self.profile = build_profile_ensemble(self.base_profile, self.adaptive_profile)
            self.adaptive_memory.save_if_needed()
            self.last_adaptive_rebuild = now

    def observe_learning(self, detected: List[DetectedHand]):
        if not self.adaptive_memory.enabled:
            return
        for learned_hand in detected:
            self.adaptive_memory.observe(learned_hand)

    def handle_emergency(self, detected: List[DetectedHand], now: float):
        if detected and any_hand_with(detected, "FIST") and self.control_enabled and now - self.last_fist_time > FIST_COOLDOWN:
            if self.drag_active:
                self.actions.mouse_up_left()
            self.drag_active = False
            self.pinch_active = False
            self.control_enabled = False
            self.last_fist_time = now
            self.last_action_label = "Pausa de seguridad"
            print("[TLETL] Pausa de seguridad. Control OFF.")

    def handle_toggle(self, detected: List[DetectedHand], main: Optional[DetectedHand], second: Optional[DetectedHand], now: float) -> float:
        toggle_progress = 0.0

        if main and main.stable_gesture == "OPEN_PALM" and not (second and second.stable_gesture == "OPEN_PALM"):
            required = TOGGLE_HOLD_OFF_SECONDS if self.control_enabled else TOGGLE_HOLD_ON_SECONDS
            toggle_progress = self.hold_toggle.progress("OPEN_PALM", required)
            if toggle_progress >= 1.0 and now - self.last_toggle_time > TOGGLE_COOLDOWN:
                self.control_enabled = not self.control_enabled
                self.last_toggle_time = now
                self.hold_toggle.reset()
                for st in self.states.values():
                    st.stable.clear()
                    st.motion.reset()
                self.last_action_label = "Control ON" if self.control_enabled else "Control OFF"
                print(f"[TLETL] Control: {'ON' if self.control_enabled else 'OFF'}")
        else:
            self.hold_toggle.reset()

        if len(detected) >= 2 and both_stable(detected, "OPEN_PALM"):
            required = 1.20 if not self.control_enabled else 2.45
            toggle_progress = max(toggle_progress, self.hold_toggle.progress("BOTH_OPEN", required))
            if toggle_progress >= 1.0 and now - self.last_toggle_time > TOGGLE_COOLDOWN:
                self.control_enabled = not self.control_enabled
                self.last_toggle_time = now
                self.hold_toggle.reset()
                self.last_action_label = "Toggle dos manos"
                print(f"[TLETL] Control dos manos: {'ON' if self.control_enabled else 'OFF'}")

        return toggle_progress

    def handle_mode(self, main: Optional[DetectedHand], now: float) -> float:
        mode_progress = 0.0

        if self.control_enabled and main and main.stable_gesture == "THREE":
            mode_progress = self.hold_mode.progress("THREE", MODE_HOLD_SECONDS)
            if mode_progress >= 1.0 and now - self.last_mode_time > 1.0:
                if self.drag_active:
                    self.actions.mouse_up_left()
                self.drag_active = False
                self.pinch_active = False
                self.mode_index = (self.mode_index + 1) % len(MODES)
                self.last_mode_time = now
                self.hold_mode.reset()
                for st in self.states.values():
                    st.stable.clear()
                    st.motion.reset()
                    st.cursor.reset()
                self.last_action_label = f"Modo {self.mode}"
                print(f"[TLETL] Modo: {self.mode}")
        else:
            self.hold_mode.reset()

        return mode_progress

    def handle_two_hand_actions(self, detected: List[DetectedHand], main: DetectedHand, second: Optional[DetectedHand], now: float):
        two_hands_open = len(detected) >= 2 and detected[0].stable_gesture == "OPEN_PALM" and detected[1].stable_gesture == "OPEN_PALM"
        two_victory = len(detected) >= 2 and detected[0].stable_gesture == "VICTORY" and detected[1].stable_gesture == "VICTORY"

        if len(detected) >= 2 and two_hands_open:
            c1 = (detected[0].center_x, detected[0].center_y)
            c2 = (detected[1].center_x, detected[1].center_y)
            self.two_hand_distance.update(c1, c2)
            zoom = self.two_hand_distance.spread_or_pinch()
            if zoom == "SPREAD" and now - self.last_big_time > BIG_ACTION_COOLDOWN:
                self.actions.zoom_in()
                self.last_big_time = now
                self.last_action_label = "Zoom + dos manos"
                print("[TLETL] Zoom In dos manos")
            elif zoom == "PINCH_IN" and now - self.last_big_time > BIG_ACTION_COOLDOWN:
                self.actions.zoom_out()
                self.last_big_time = now
                self.last_action_label = "Zoom - dos manos"
                print("[TLETL] Zoom Out dos manos")
        else:
            self.two_hand_distance.reset()

        if two_victory:
            swipes = {h.swipe for h in detected[:2] if h.swipe}
            if "RIGHT" in swipes and now - self.last_big_time > BIG_ACTION_COOLDOWN:
                self.actions.workspace_next()
                self.last_big_time = now
                self.last_action_label = "Workspace siguiente"
                print("[TLETL] Workspace siguiente")
            elif "LEFT" in swipes and now - self.last_big_time > BIG_ACTION_COOLDOWN:
                self.actions.workspace_prev()
                self.last_big_time = now
                self.last_action_label = "Workspace anterior"
                print("[TLETL] Workspace anterior")

        modifier_open = second is not None and second.stable_gesture == "OPEN_PALM"
        if modifier_open and now - self.last_modifier_time > 0.55:
            if main.stable_gesture == "POINT" and main.center_y < UP_ZONE:
                self.actions.volume_up()
                self.last_modifier_time = now
                self.last_action_label = "Volumen +"
            elif main.stable_gesture == "POINT" and main.center_y > DOWN_ZONE:
                self.actions.volume_down()
                self.last_modifier_time = now
                self.last_action_label = "Volumen -"
            elif main.action_gesture == "PINCH":
                self.actions.click_right()
                self.last_modifier_time = now
                self.last_action_label = "Click derecho"

    def handle_browser_mode(self, main: DetectedHand, toggle_progress: float, now: float):
        swipe = main.swipe
        if main.stable_gesture == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - self.last_tab_time > TAB_ACTION_COOLDOWN:
            if swipe == "RIGHT":
                self.actions.next_tab(); self.last_action_label = "Siguiente pestaña"
            else:
                self.actions.previous_tab(); self.last_action_label = "Pestaña anterior"
            print(f"[TLETL] {self.last_action_label}")
            self.last_tab_time = now

        elif main.stable_gesture == "OPEN_PALM" and swipe in {"LEFT", "RIGHT"} and toggle_progress < 0.55 and now - self.last_tab_time > TAB_ACTION_COOLDOWN:
            if swipe == "LEFT":
                self.actions.browser_back(); self.last_action_label = "Atrás"
            else:
                self.actions.browser_forward(); self.last_action_label = "Adelante"
            print(f"[TLETL] {self.last_action_label}")
            self.last_tab_time = now

        elif main.stable_gesture == "POINT" and now - self.last_action_time > ACTION_COOLDOWN:
            if main.center_y < EXTREME_UP_ZONE:
                self.actions.page_up(); self.last_action_time = now + 0.18; self.last_action_label = "PageUp"
            elif main.center_y > EXTREME_DOWN_ZONE:
                self.actions.page_down(); self.last_action_time = now + 0.18; self.last_action_label = "PageDown"
            elif main.center_y < UP_ZONE:
                self.actions.scroll_up_small(); self.last_action_time = now; self.last_action_label = "Scroll arriba"
            elif main.center_y > DOWN_ZONE:
                self.actions.scroll_down_small(); self.last_action_time = now; self.last_action_label = "Scroll abajo"

        elif main.action_gesture == "PINCH" and now - self.last_pinch_time > 0.36:
            self.actions.click_left(); self.last_pinch_time = now; self.last_action_label = "Click izquierdo"

    def handle_cursor_mode(self, main: DetectedHand, second: Optional[DetectedHand], now: float) -> str:
        cursor_info = ""
        modifier_open = second is not None and second.stable_gesture == "OPEN_PALM"
        state = self.states.get(main.label)

        if state and main.action_gesture in {"POINT", "OPEN_PALM", "PINCH"}:
            dx, dy = state.cursor.update(main.center_x, main.center_y, velocity=main.speed)
            if dx or dy:
                self.actions.mousemove_relative(dx, dy)
                cursor_info = f"Mouse dx={dx} dy={dy} vel={main.speed:.2f}"
        elif state:
            state.cursor.reset()

        if main.action_gesture == "PINCH" and not modifier_open:
            if not self.pinch_active:
                self.pinch_active = True
                self.pinch_started_at = now
            if not self.drag_active and now - self.pinch_started_at >= DRAG_START_SECONDS:
                self.actions.mouse_down_left()
                self.drag_active = True
                self.last_action_label = "Drag ON"
                print("[TLETL] Drag ON / seleccionar")
        else:
            if self.pinch_active:
                held = now - self.pinch_started_at
                if self.drag_active:
                    self.actions.mouse_up_left()
                    self.last_action_label = "Drag OFF"
                    print("[TLETL] Drag OFF / soltar")
                elif held <= CLICK_MAX_SECONDS and now - self.last_pinch_time > 0.23:
                    self.actions.click_left()
                    self.last_pinch_time = now
                    self.last_action_label = "Click izquierdo"
                self.pinch_active = False
                self.drag_active = False

        if main.stable_gesture == "VICTORY" and main.swipe in {"LEFT", "RIGHT"} and now - self.last_tab_time > TAB_ACTION_COOLDOWN:
            if main.swipe == "RIGHT":
                self.actions.next_tab(); self.last_action_label = "Siguiente pestaña"
            else:
                self.actions.previous_tab(); self.last_action_label = "Pestaña anterior"
            self.last_tab_time = now

        return cursor_info

    def handle_windows_mode(self, main: DetectedHand, now: float):
        if main.stable_gesture == "VICTORY" and main.swipe in {"LEFT", "RIGHT"} and now - self.last_tab_time > TAB_ACTION_COOLDOWN:
            if main.swipe == "RIGHT":
                self.actions.alt_tab(); self.last_action_label = "Alt+Tab"
            else:
                self.actions.alt_shift_tab(); self.last_action_label = "Alt+Shift+Tab"
            print(f"[TLETL] {self.last_action_label}")
            self.last_tab_time = now
        elif main.stable_gesture == "OPEN_PALM" and main.swipe == "UP" and now - self.last_big_time > BIG_ACTION_COOLDOWN:
            self.actions.overview(); self.last_big_time = now; self.last_action_label = "Overview"
        elif main.action_gesture == "PINCH" and now - self.last_pinch_time > 0.36:
            self.actions.enter(); self.last_pinch_time = now; self.last_action_label = "Enter"

    def handle_system_mode(self, main: DetectedHand, now: float):
        if main.stable_gesture == "POINT" and now - self.last_action_time > 0.30:
            if main.center_y < UP_ZONE:
                self.actions.volume_up(); self.last_action_time = now; self.last_action_label = "Volumen +"
            elif main.center_y > DOWN_ZONE:
                self.actions.volume_down(); self.last_action_time = now; self.last_action_label = "Volumen -"
        elif main.action_gesture == "PINCH" and now - self.last_pinch_time > 0.45:
            self.actions.enter(); self.last_pinch_time = now; self.last_action_label = "Enter"
        elif main.stable_gesture == "OPEN_PALM" and main.swipe == "UP" and now - self.last_big_time > BIG_ACTION_COOLDOWN:
            self.actions.overview(); self.last_big_time = now; self.last_action_label = "Overview"

    def handle_actions(self, detected: List[DetectedHand], main: Optional[DetectedHand], second: Optional[DetectedHand], toggle_progress: float, now: float) -> str:
        cursor_info = ""

        if self.control_enabled and main:
            self.handle_two_hand_actions(detected, main, second, now)

            if self.mode == "NAVEGADOR":
                self.handle_browser_mode(main, toggle_progress, now)
            elif self.mode == "CURSOR":
                cursor_info = self.handle_cursor_mode(main, second, now)
            elif self.mode == "VENTANAS":
                self.handle_windows_mode(main, now)
            elif self.mode == "SISTEMA":
                self.handle_system_mode(main, now)
        else:
            if self.drag_active:
                self.actions.mouse_up_left()
            self.drag_active = False
            self.pinch_active = False
            self.two_hand_distance.reset()

        return cursor_info

    def draw_frame_ui(self, frame, detected, main, second, fps, toggle_progress, mode_progress, cursor_info):
        draw_zones(frame)
        status = "ON" if self.control_enabled else "OFF"
        color = (0, 255, 0) if self.control_enabled else (0, 0, 255)

        lines = [
            f"TLETL V4 MODULAR: {status} | MODO: {self.mode} | FPS: {fps:.1f} | Manos: {len(detected)}",
            f"Principal: {hand_summary(main)} | Swipe: {main.swipe if main else '-'}",
            f"Secundaria: {hand_summary(second)} | Accion: {self.last_action_label}",
            f"Baja luz: {self.enhancer.last_mode} | Luma: {self.enhancer.last_luma:.0f} | Perfil: {'OK' if self.base_profile else 'reglas'} | AI: {'ON' if self.args.ai else 'OFF'} {self.gesture_ai.counts()}",
            "Palma hold=ON/OFF lento | Tres dedos=modo | Puño=emergencia | Q=salir",
        ]

        if self.mode == "NAVEGADOR":
            lines.append("NAVEGADOR: indice=scroll | victoria swipe=tabs | palma swipe=atras/adelante | dos palmas=zoom")
        elif self.mode == "CURSOR":
            drag_text = "DRAG ACTIVO" if self.drag_active else "pinza corta=click, pinza sostenida=seleccionar"
            lines.append(f"CURSOR: indice/palma/pinza mueve mouse | {drag_text} | palma secundaria+pinza=click derecho")
            if cursor_info:
                lines.append(cursor_info)
        elif self.mode == "VENTANAS":
            lines.append("VENTANAS: victoria swipe=AltTab | dos victorias swipe=workspace | palma arriba=overview")
        else:
            lines.append("SISTEMA: indice arriba/abajo=volumen | pinza=Enter | palma arriba=overview")

        if toggle_progress > 0:
            lines.append(f"Mantén palma para toggle: {int(toggle_progress * 100)}%")
        if mode_progress > 0:
            lines.append(f"Mantén tres dedos para cambiar modo: {int(mode_progress * 100)}%")

        draw_text_box(frame, lines)
        cv2.circle(frame, (frame.shape[1] - 35, 35), 17, color, -1)

        if toggle_progress > 0:
            draw_progress_bar(frame, toggle_progress, y_offset=60, color=(0, 220, 120))
        if mode_progress > 0:
            draw_progress_bar(frame, mode_progress, y_offset=90, color=(255, 180, 0))

        self.notifier.update({
            "active": self.control_enabled,
            "mode": self.mode,
            "hands": len(detected),
            "fps": fps,
            "main_gesture": hand_summary(main),
            "second_gesture": hand_summary(second),
            "last_action": self.last_action_label,
            "luma": self.enhancer.last_luma,
            "light_mode": self.enhancer.last_mode,
            "adaptive": f"AI {self.gesture_ai.counts()} | MEM {self.adaptive_memory.short_counts()}",
        })

    def run(self):
        print(f"\n[{APP_NAME}] Ejecutando")
        print(f"Memoria adaptativa: {self.adaptive_memory.path if self.adaptive_memory.enabled else 'apagada'}")
        print(f"IA gestos: {'ON' if self.args.ai else 'OFF'} | Dataset: {self.gesture_ai.dataset_path} | {self.gesture_ai.counts()}")
        print("- Palma abierta sostenida: ON/OFF")
        print("- Tres dedos: cambiar modo")
        print("- Puño: emergencia")
        print("- Q: salir")
        if self.args.dry_run:
            print("- DRY RUN: no manda teclas reales")

        prev_time = time.time()

        with mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            model_complexity=self.args.model_complexity,
            min_detection_confidence=self.args.det_conf,
            min_tracking_confidence=self.args.track_conf,
        ) as hands_model:
            while True:
                ok, raw_frame = self.cap.read()
                if not ok:
                    print("[ERROR] No pude leer frame de cámara.")
                    break

                now = time.time()
                fps = 1.0 / max(now - prev_time, 0.0001)
                prev_time = now

                frame, detected = detect_hands(raw_frame, hands_model, self.states, self.enhancer, self.profile, self.args, gesture_ai=self.gesture_ai if self.args.ai else None)

                self.observe_learning(detected)
                self.rebuild_adaptive_profile_if_needed(now)

                if self.yolo_pose is not None:
                    self.yolo_pose.process_and_draw(frame)

                main, second = choose_main_hand(detected)

                self.handle_emergency(detected, now)
                toggle_progress = self.handle_toggle(detected, main, second, now)
                mode_progress = self.handle_mode(main, now)
                cursor_info = self.handle_actions(detected, main, second, toggle_progress, now)

                self.draw_frame_ui(frame, detected, main, second, fps, toggle_progress, mode_progress, cursor_info)

                cv2.imshow(APP_NAME, frame)
                key = cv2.waitKey(1) & 0xFF

                if key in KEY_TO_GESTURE and main is not None:
                    label = KEY_TO_GESTURE[key]
                    self.gesture_ai.add_correction(
                        label,
                        main.features,
                        meta={
                            "source": "v4.1-runtime-correction",
                            "raw": main.raw_gesture,
                            "stable": main.stable_gesture,
                            "confidence": main.confidence,
                            "mode": self.mode,
                        },
                    )
                    self.last_action_label = f"IA aprende: {label}"
                    print(f"[TLETL AI] Corrección guardada: {label}")

                if key == ord("q"):
                    if self.drag_active:
                        self.actions.mouse_up_left()
                    break


def run_control(args):
    runtime = TletlRuntime(args)
    try:
        runtime.run()
    finally:
        runtime.close()
