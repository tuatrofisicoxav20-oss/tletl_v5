
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


DANGEROUS_CONFUSIONS = {
    ("FIST", "PINCH"),
    ("PINCH", "FIST"),
    ("THREE", "PINCH"),
    ("PINCH", "THREE"),
    ("NEUTRAL", "PINCH"),
    ("PINCH", "NEUTRAL"),
    ("POINT", "PINCH"),
    ("PINCH", "POINT"),
    ("VICTORY", "THREE"),
    ("THREE", "VICTORY"),
}


@dataclass
class CriticDecision:
    should_ask: bool
    reason: str
    suggested_labels: List[str]
    priority: int
    meta: Dict[str, Any]


class GestureCritic:
    # Segunda IA / crítico.
    #
    # No decide el gesto final. Su trabajo es cuestionar:
    # - baja confianza
    # - voto dividido
    # - conflicto entre especialista/kNN/centroide
    # - confusiones peligrosas como FIST vs PINCH
    #
    # Cuando encuentra un caso difícil, se lo da al usuario para etiquetarlo.
    # Eso produce muestras mucho más útiles que juntar 900 ejemplos iguales.

    def __init__(
        self,
        min_conf: float = 0.78,
        low_margin: float = 0.18,
        dangerous_conf: float = 0.86,
        cooldown_frames: int = 6,
    ):
        self.min_conf = float(min_conf)
        self.low_margin = float(low_margin)
        self.dangerous_conf = float(dangerous_conf)
        self.cooldown_frames = int(cooldown_frames)
        self.frames_until_next = 0
        self.last_decision: Optional[CriticDecision] = None

    def tick(self):
        if self.frames_until_next > 0:
            self.frames_until_next -= 1

    def reset_cooldown(self):
        self.frames_until_next = self.cooldown_frames

    def evaluate(self, prediction: str, confidence: float, info: Dict[str, Any]) -> CriticDecision:
        self.tick()

        if self.frames_until_next > 0:
            return CriticDecision(False, "cooldown", [], 0, {})

        info = info or {}
        votes = info.get("votes", {}) if isinstance(info.get("votes", {}), dict) else {}
        specialist = info.get("specialist", "none")
        reason = info.get("reason", "")

        suggested = self._suggest_labels(prediction, votes, specialist, reason)
        priority = 0
        reasons = []

        if prediction in {"UNKNOWN", "NO_HAND", "WAITING"}:
            if votes:
                priority += 2
                reasons.append("unknown_with_votes")
            else:
                return CriticDecision(False, "not_useful_unknown", [], 0, {})

        if confidence < self.min_conf and prediction not in {"NO_HAND"}:
            priority += 2
            reasons.append("low_confidence")

        if votes:
            ordered = sorted(votes.items(), key=lambda x: x[1], reverse=True)
            if len(ordered) >= 2:
                top_label, top_votes = ordered[0]
                second_label, second_votes = ordered[1]
                total_votes = max(sum(votes.values()), 1)
                margin = (top_votes - second_votes) / total_votes
                if margin <= self.low_margin:
                    priority += 3
                    reasons.append(f"vote_margin_low:{top_label}_vs_{second_label}")
                    suggested = self._unique([top_label, second_label] + suggested)

                if (top_label, second_label) in DANGEROUS_CONFUSIONS:
                    priority += 4
                    reasons.append(f"dangerous_pair:{top_label}_vs_{second_label}")
                    suggested = self._unique([top_label, second_label, "NEUTRAL"] + suggested)

        # Si dice PINCH con conf media, el crítico debe ser desconfiado,
        # porque PINCH produce clicks/drag y los falsos positivos molestan.
        if prediction == "PINCH" and confidence < self.dangerous_conf:
            priority += 3
            reasons.append("pinch_requires_extra_proof")
            suggested = self._unique(["PINCH", "FIST", "NEUTRAL", "THREE", "POINT"] + suggested)

        # Especialista contradice o sugiere frontera.
        if specialist in {"compact_fist", "three_over_pinch", "victory_over_pinch", "neutral_like"}:
            priority += 2
            reasons.append(f"specialist_boundary:{specialist}")
            if specialist == "compact_fist":
                suggested = self._unique(["FIST", "PINCH", "NEUTRAL"] + suggested)
            elif specialist == "three_over_pinch":
                suggested = self._unique(["THREE", "PINCH", "NEUTRAL"] + suggested)
            elif specialist == "victory_over_pinch":
                suggested = self._unique(["VICTORY", "THREE", "PINCH"] + suggested)
            elif specialist == "neutral_like":
                suggested = self._unique(["NEUTRAL", prediction, "PINCH"] + suggested)

        if "pinch_not_confident" in str(reason):
            priority += 3
            reasons.append("pinch_rejected")
            suggested = self._unique(["PINCH", "FIST", "NEUTRAL", "THREE"] + suggested)

        should = priority >= 3 and bool(suggested)

        decision = CriticDecision(
            should_ask=should,
            reason="+".join(reasons) if reasons else "not_hard_enough",
            suggested_labels=suggested[:5],
            priority=priority,
            meta={
                "prediction": prediction,
                "confidence": confidence,
                "votes": votes,
                "specialist": specialist,
                "reason_raw": reason,
            },
        )

        if should:
            self.reset_cooldown()
            self.last_decision = decision

        return decision

    def _suggest_labels(self, prediction: str, votes: Dict[str, int], specialist: str, reason: str) -> List[str]:
        labels = []
        if prediction and prediction not in {"UNKNOWN", "NO_HAND", "WAITING"}:
            labels.append(prediction)
        if votes:
            labels.extend([k for k, _ in sorted(votes.items(), key=lambda x: x[1], reverse=True)])

        # Siempre meter NEUTRAL en casos ambiguos porque reduce acciones falsas.
        if prediction == "PINCH" or "pinch" in str(reason).lower():
            labels.extend(["FIST", "NEUTRAL", "THREE", "POINT"])
        else:
            labels.append("NEUTRAL")

        return self._unique(labels)

    def _unique(self, items: List[str]) -> List[str]:
        seen = set()
        out = []
        valid = {"OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"}
        for item in items:
            if item in valid and item not in seen:
                seen.add(item)
                out.append(item)
        return out
