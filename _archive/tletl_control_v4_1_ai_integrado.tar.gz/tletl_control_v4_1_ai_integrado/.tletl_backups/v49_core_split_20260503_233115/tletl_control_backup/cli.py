import argparse

from .app import run_control
from .gesture_bank_app import run_collect
from .constants import (
    APP_NAME, CAMERA_FPS, CAMERA_HEIGHT, CAMERA_WIDTH, CURSOR_DEADZONE, CURSOR_GAIN, CURSOR_MAX_STEP,
    DEFAULT_ADAPTIVE_MEMORY_PATH, DEFAULT_PROFILE_PATH, FAST_MOTION_THRESHOLD, GESTURE_HISTORY_SIZE,
    MIN_DETECTION_CONFIDENCE, MIN_TRACKING_CONFIDENCE, MODEL_COMPLEXITY, SMOOTHING_FAST_ALPHA,
    SMOOTHING_SLOW_ALPHA, STABLE_GESTURE_MIN_COUNT
)


def build_arg_parser():
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--profile", default=DEFAULT_PROFILE_PATH, help="Perfil JSON de V3.4. Si no existe, usa reglas.")
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--width", type=int, default=CAMERA_WIDTH)
    parser.add_argument("--height", type=int, default=CAMERA_HEIGHT)
    parser.add_argument("--fps", type=int, default=CAMERA_FPS)
    parser.add_argument("--det-conf", type=float, default=MIN_DETECTION_CONFIDENCE)
    parser.add_argument("--track-conf", type=float, default=MIN_TRACKING_CONFIDENCE)
    parser.add_argument("--model-complexity", type=int, default=MODEL_COMPLEXITY)
    parser.add_argument("--dry-run", action="store_true", help="No manda acciones reales, solo imprime comandos.")
    parser.add_argument("--no-low-light", action="store_true", help="Desactiva mejora de baja luz.")
    parser.add_argument("--no-status-window", action="store_true", help="Oculta la ventana extra de estado.")
    parser.add_argument("--status-backend", choices=["auto", "tk", "cv2", "off"], default="auto", help="Backend de ventana de estado/notificación.")
    parser.add_argument("--no-adaptive-learning", action="store_true", help="Desactiva auto-calibración continua.")
    parser.add_argument("--adaptive-memory", default=DEFAULT_ADAPTIVE_MEMORY_PATH, help="Archivo JSON de memoria adaptativa.")
    parser.add_argument("--adaptive-min-conf", type=float, default=0.78, help="Confianza mínima para aprender muestras nuevas.")
    parser.add_argument("--adaptive-max-samples", type=int, default=240, help="Muestras máximas por gesto en memoria adaptativa.")
    parser.add_argument("--adaptive-save-seconds", type=float, default=5.0, help="Cada cuántos segundos guardar memoria adaptativa.")
    parser.add_argument("--adaptive-rebuild-seconds", type=float, default=4.0, help="Cada cuántos segundos reconstruir perfil adaptativo.")
    parser.add_argument("--history", type=int, default=GESTURE_HISTORY_SIZE)
    parser.add_argument("--stable-count", type=int, default=STABLE_GESTURE_MIN_COUNT)
    parser.add_argument("--motion-history", type=int, default=9)
    parser.add_argument("--slow-alpha", type=float, default=SMOOTHING_SLOW_ALPHA)
    parser.add_argument("--fast-alpha", type=float, default=SMOOTHING_FAST_ALPHA)
    parser.add_argument("--fast-threshold", type=float, default=FAST_MOTION_THRESHOLD)
    parser.add_argument("--cursor-gain", type=int, default=CURSOR_GAIN)
    parser.add_argument("--cursor-max-step", type=int, default=CURSOR_MAX_STEP)
    parser.add_argument("--cursor-deadzone", type=float, default=CURSOR_DEADZONE)
    parser.add_argument("--ai", action="store_true", help="Activa IA k-NN entrenada con tu banco de gestos.")
    parser.add_argument("--ai-dataset", default="tletl_gesture_bank.jsonl", help="Banco de gestos JSONL.")
    parser.add_argument("--ai-k", type=int, default=7, help="Vecinos usados por la IA k-NN.")
    parser.add_argument("--ai-min-conf", type=float, default=0.62, help="Confianza mínima para aceptar predicción IA.")
    parser.add_argument("--ai-auto-learn", action="store_true", help="Permite que la IA guarde predicciones muy confiables.")
    parser.add_argument("--ai-auto-conf", type=float, default=0.86, help="Confianza mínima para autoaprender.")
    parser.add_argument("--collect-gestures", action="store_true", help="Abre el banco de gestos para entrenar la IA.")
    parser.add_argument("--autosave-interval", type=float, default=0.18, help="Intervalo de autosave en banco de gestos.")
    parser.add_argument("--yolo-pose", action="store_true", help="Activa capa opcional Ultralytics YOLO11 Pose.")
    parser.add_argument("--yolo-model", default="yolo11n-pose.pt", help="Modelo YOLO pose, por ejemplo yolo11n-pose.pt.")
    parser.add_argument("--yolo-every-n", type=int, default=3, help="Ejecutar YOLO cada N frames para no matar FPS.")
    parser.add_argument("--yolo-conf", type=float, default=0.35, help="Confianza mínima YOLO pose.")
    return parser


def main():
    args = build_arg_parser().parse_args()
    try:
        if args.collect_gestures:
            run_collect(args)
        else:
            run_control(args)
    except KeyboardInterrupt:
        print("\n[TLETL] Interrumpido.")
    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        print("Tips: prueba --camera 1, baja --width 640 --height 480, o ejecuta con --dry-run.")
