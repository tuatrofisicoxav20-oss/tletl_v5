"""Tletl Control V4 Modular.

Sistema de control por gestos para Fedora/navegador con OpenCV, MediaPipe y ydotool.
"""
__version__ = "4.0-modular"
