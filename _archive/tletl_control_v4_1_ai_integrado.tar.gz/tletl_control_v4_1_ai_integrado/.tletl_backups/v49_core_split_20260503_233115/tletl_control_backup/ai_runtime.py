\
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from .ai_bank import append_sample, load_samples, short_counts
from .ai_classifier import KNNGestureClassifier


class GestureAI:
    def __init__(self, dataset_path: Path, enabled: bool = True, k: int = 7,
                 min_conf: float = 0.62, auto_learn: bool = False,
                 auto_learn_conf: float = 0.86):
        self.dataset_path = Path(dataset_path).expanduser().resolve()
        self.enabled = enabled
        self.k = int(k)
        self.min_conf = float(min_conf)
        self.auto_learn = auto_learn
        self.auto_learn_conf = float(auto_learn_conf)
        self.rows = []
        self.classifier = KNNGestureClassifier(k=self.k)
        self.reload()

    def reload(self):
        self.rows = load_samples(self.dataset_path)
        self.classifier.fit(self.rows)

    def ready(self) -> bool:
        return self.enabled and self.classifier.ready()

    def counts(self) -> str:
        return short_counts(self.rows)

    def predict(self, features: Dict[str, float]) -> Tuple[str, float, Dict[str, Any]]:
        if not self.ready():
            return "UNKNOWN", 0.0, {"reason": "AI no lista"}
        label, conf, info = self.classifier.predict(features)
        if conf < self.min_conf:
            return "UNKNOWN", conf, info
        return label, conf, info

    def add_correction(self, label: str, features: Dict[str, float], meta: Optional[Dict[str, Any]] = None):
        append_sample(self.dataset_path, label, features, meta=meta or {"source": "runtime-correction"})
        self.reload()

    def maybe_auto_learn(self, label: str, confidence: float, features: Dict[str, float]):
        if not self.enabled or not self.auto_learn:
            return
        if label == "UNKNOWN" or confidence < self.auto_learn_conf:
            return
        append_sample(self.dataset_path, label, features, meta={"source": "runtime-auto", "conf": confidence})
        self.reload()
