import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .constants import APP_NAME, CONFIDENCE_THRESHOLD, MARGIN_THRESHOLD, MIN_STD


ADAPTIVE_EXCLUDED_FEATURES = {"palm_center_x", "palm_center_y"}
ADAPTIVE_ALLOWED_GESTURES = {"OPEN_PALM", "FIST", "POINT", "VICTORY", "THREE", "PINCH", "NEUTRAL"}


def load_profile_optional(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        print(f"[AVISO] No encontré perfil {path}. Usaré reglas geométricas solamente.")
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[AVISO] No pude leer perfil {path}: {exc}. Usaré reglas geométricas.")
        return None


def adaptive_feature_keys_from_sample(sample: Dict[str, float]) -> List[str]:
    return sorted(k for k in sample.keys() if k not in ADAPTIVE_EXCLUDED_FEATURES)


def compute_profile_stats_from_samples(samples: List[Dict[str, float]], keys: List[str]) -> Dict[str, Dict[str, float]]:
    mean: Dict[str, float] = {}
    std: Dict[str, float] = {}
    for key in keys:
        vals = [float(s[key]) for s in samples if key in s and isinstance(s.get(key), (int, float))]
        if not vals:
            continue
        m = sum(vals) / len(vals)
        var = sum((v - m) ** 2 for v in vals) / max(len(vals) - 1, 1)
        mean[key] = m
        std[key] = max(math.sqrt(var), MIN_STD)
    return {"mean": mean, "std": std}


class AdaptiveGestureMemory:
    def __init__(self, path: Path, enabled: bool = True, max_samples: int = 240,
                 min_conf: float = 0.78, save_seconds: float = 5.0):
        self.path = path
        self.enabled = enabled
        self.max_samples = max(40, int(max_samples))
        self.min_conf = float(min_conf)
        self.save_seconds = float(save_seconds)
        self.data: Dict[str, Any] = {
            "app": APP_NAME,
            "version": "4-adaptive-memory",
            "feature_keys": [],
            "gestures": {},
            "updated_at": time.time(),
        }
        self.last_sample_time: Dict[str, float] = {}
        self.last_save_time = 0.0
        self.dirty = False
        self.load()

    def load(self):
        if not self.path.exists():
            return
        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict) and isinstance(loaded.get("gestures", {}), dict):
                self.data = loaded
        except Exception as exc:
            print(f"[AVISO] No pude cargar memoria adaptativa {self.path}: {exc}")

    def counts(self) -> Dict[str, int]:
        return {g: len(v) for g, v in self.data.get("gestures", {}).items() if isinstance(v, list)}

    def short_counts(self) -> str:
        counts = self.counts()
        if not counts:
            return "0"
        order = ["PINCH", "POINT", "OPEN_PALM", "FIST", "VICTORY", "THREE", "NEUTRAL"]
        parts = [f"{g}:{counts[g]}" for g in order if counts.get(g)]
        return " ".join(parts[:5]) if parts else "0"

    def _clean_sample(self, features: Dict[str, float]) -> Dict[str, float]:
        sample: Dict[str, float] = {}
        for key, value in features.items():
            if key in ADAPTIVE_EXCLUDED_FEATURES:
                continue
            if isinstance(value, (int, float)) and math.isfinite(float(value)):
                sample[key] = round(float(value), 6)
        return sample

    def observe(self, hand: Any):
        if not self.enabled or hand is None:
            return
        gesture = getattr(hand, "raw_gesture", "UNKNOWN")
        stable = getattr(hand, "stable_gesture", "UNKNOWN")
        confidence = float(getattr(hand, "confidence", 0.0))
        source = str(getattr(hand, "source", ""))

        if gesture not in ADAPTIVE_ALLOWED_GESTURES or gesture in {"UNKNOWN", "WAITING", "UNSTABLE", "NO_HAND"}:
            return
        if confidence < self.min_conf:
            return

        if gesture == "PINCH":
            safe = confidence >= max(self.min_conf, 0.80)
        else:
            safe = (stable == gesture and source in {"perfil+regla", "regla", "regla-rapida"}) or confidence >= 0.86
        if not safe:
            return

        now = time.time()
        if now - self.last_sample_time.get(gesture, 0.0) < 0.20:
            return
        self.last_sample_time[gesture] = now

        sample = self._clean_sample(getattr(hand, "features", {}))
        if len(sample) < 8:
            return

        keys = self.data.get("feature_keys") or adaptive_feature_keys_from_sample(sample)
        self.data["feature_keys"] = keys

        gestures = self.data.setdefault("gestures", {})
        bucket = gestures.setdefault(gesture, [])
        bucket.append(sample)
        if len(bucket) > self.max_samples:
            del bucket[:len(bucket) - self.max_samples]

        self.data["updated_at"] = time.time()
        self.dirty = True

    def to_profile(self) -> Optional[Dict[str, Any]]:
        gestures = self.data.get("gestures", {})
        keys = self.data.get("feature_keys", [])
        if not gestures or not keys:
            return None
        profile_gestures: Dict[str, Any] = {}
        for gesture, samples in gestures.items():
            if not isinstance(samples, list) or len(samples) < 18:
                continue
            stats = compute_profile_stats_from_samples(samples, keys)
            if stats["mean"] and stats["std"]:
                profile_gestures[gesture] = {
                    "samples": len(samples),
                    "mean": stats["mean"],
                    "std": stats["std"],
                }
        if not profile_gestures:
            return None
        return {
            "app": APP_NAME,
            "version": "4-adaptive-profile",
            "feature_keys": keys,
            "gestures": profile_gestures,
        }

    def save_if_needed(self, force: bool = False):
        if not self.enabled:
            return
        now = time.time()
        if not force and (not self.dirty or now - self.last_save_time < self.save_seconds):
            return
        try:
            self.path.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
            self.last_save_time = now
            self.dirty = False
        except Exception as exc:
            print(f"[AVISO] No pude guardar memoria adaptativa: {exc}")


def build_profile_ensemble(base_profile: Optional[Dict[str, Any]], adaptive_profile: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    profiles = [p for p in [base_profile, adaptive_profile] if p]
    if not profiles:
        return None
    if len(profiles) == 1:
        return profiles[0]
    return {"ensemble": profiles}


def classify_with_single_profile(features: Dict[str, float], profile: Dict[str, Any]) -> Tuple[str, float]:
    keys = profile.get("feature_keys", [])
    gestures = profile.get("gestures", {})
    if not keys or not gestures:
        return "UNKNOWN", 0.0

    scores: Dict[str, float] = {}
    for gesture_id, data in gestures.items():
        mean = data.get("mean", {})
        std = data.get("std", {})
        total = 0.0
        used = 0
        for key in keys:
            if key not in features:
                continue
            s = max(float(std.get(key, MIN_STD)), MIN_STD)
            m = float(mean.get(key, 0.0))
            z = (features[key] - m) / s
            total += z * z
            used += 1
        scores[gesture_id] = math.sqrt(total / used) if used else 999.0

    ordered = sorted(scores.items(), key=lambda item: item[1])
    if not ordered:
        return "UNKNOWN", 0.0

    best, best_score = ordered[0]
    second_score = ordered[1][1] if len(ordered) > 1 else 999.0
    confidence = 1.0 / (1.0 + best_score)
    margin = second_score - best_score

    if confidence < CONFIDENCE_THRESHOLD or margin < MARGIN_THRESHOLD:
        return "UNKNOWN", confidence
    return best, confidence


def classify_with_profile(features: Dict[str, float], profile: Dict[str, Any]) -> Tuple[str, float]:
    if not profile:
        return "UNKNOWN", 0.0
    if isinstance(profile, dict) and "ensemble" in profile:
        best_gesture = "UNKNOWN"
        best_conf = 0.0
        for one_profile in profile.get("ensemble", []):
            gesture, conf = classify_with_single_profile(features, one_profile)
            if gesture != "UNKNOWN" and conf > best_conf:
                best_gesture, best_conf = gesture, conf
        return best_gesture, best_conf
    return classify_with_single_profile(features, profile)
