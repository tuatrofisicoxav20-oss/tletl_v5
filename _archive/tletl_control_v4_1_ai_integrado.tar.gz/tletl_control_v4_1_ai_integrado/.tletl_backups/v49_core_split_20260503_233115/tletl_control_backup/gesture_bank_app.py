\
import argparse
from pathlib import Path

import cv2
import mediapipe as mp

from .ai_bank import KEY_TO_GESTURE, append_sample, count_by_label, load_samples, short_counts
from .features import extract_features
from .geometry import points_from_landmarks
from .ui import draw_text_box
from .vision import open_camera


mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


GESTURE_HELP = {
    "OPEN_PALM": "Palma abierta natural, dedos separados.",
    "FIST": "Puño cerrado normal.",
    "POINT": "Solo índice extendido.",
    "VICTORY": "Índice y medio extendidos.",
    "PINCH": "Pulgar e índice juntos, sin cerrar toda la mano.",
    "THREE": "Tres dedos extendidos.",
    "NEUTRAL": "Mano relajada que NO debe hacer acciones.",
}


def run_collect(args):
    dataset_path = Path(args.ai_dataset).expanduser().resolve()
    cap = open_camera(args.camera, args.width, args.height, args.fps)

    selected = "OPEN_PALM"
    autosave = False
    last_saved = 0.0
    saved_flash = ""

    print("[TLETL AI] Banco de gestos")
    print("1 palma | 2 puño | 3 índice | 4 victoria | 5 pinza | 6 tres | 7 neutral")
    print("SPACE guarda | A autosave | Q salir")

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=args.model_complexity,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("[ERROR] No pude leer cámara.")
                break

            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = hands.process(rgb)

            features = None
            if result.multi_hand_landmarks:
                hand_landmarks = result.multi_hand_landmarks[0]
                points = points_from_landmarks(hand_landmarks)
                features = extract_features(points)
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            rows = load_samples(dataset_path)
            counts = count_by_label(rows)

            lines = [
                "TLETL V4.1 - BANCO DE GESTOS IA",
                f"Gesto seleccionado: {selected}",
                f"Cómo hacerlo: {GESTURE_HELP.get(selected, '')}",
                f"Autosave: {'ON' if autosave else 'OFF'} | Dataset: {dataset_path.name}",
                short_counts(rows),
                "1 palma | 2 puño | 3 índice | 4 victoria | 5 pinza | 6 tres | 7 neutral",
                "SPACE=guardar muestra | A=autosave | Q=salir",
            ]
            if features is None:
                lines.append("No veo mano completa. Luz de frente, mano dentro del cuadro.")
            else:
                lines.append("Mano detectada. Guarda variaciones, no clones tiesos.")
            if saved_flash:
                lines.append(saved_flash)

            draw_text_box(frame, lines, font_scale=0.48)
            cv2.imshow("Tletl Banco de Gestos IA", frame)

            key = cv2.waitKey(1) & 0xFF
            now = cv2.getTickCount() / cv2.getTickFrequency()

            if key == ord("q"):
                break
            if key in KEY_TO_GESTURE:
                selected = KEY_TO_GESTURE[key]
                saved_flash = ""
            if key == ord("a"):
                autosave = not autosave
                saved_flash = f"Autosave {'ON' if autosave else 'OFF'}"

            should_save = key == 32
            if autosave and features is not None and now - last_saved > args.autosave_interval:
                should_save = True

            if should_save and features is not None:
                append_sample(dataset_path, selected, features, meta={"source": "gesture-bank"})
                last_saved = now
                saved_flash = f"[OK] guardada muestra {selected}"
                print(saved_flash)

    cap.release()
    cv2.destroyAllWindows()
