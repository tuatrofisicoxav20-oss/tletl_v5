import subprocess
from typing import List


class ActionRunner:
    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run

    def _run(self, cmd: List[str], label: str):
        if self.dry_run:
            print(f"[DRY-RUN] {label}: {' '.join(cmd)}")
            return
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        except Exception as exc:
            print(f"[ERROR ydotool] {exc}")

    def key(self, sequence: str, label: str):
        self._run(["ydotool", "key"] + sequence.split(), label)

    def mousemove_relative(self, dx: int, dy: int):
        if dx or dy:
            self._run(["ydotool", "mousemove", "-x", str(dx), "-y", str(dy)], f"MouseMove {dx},{dy}")

    def click_left(self): self._run(["ydotool", "click", "0xC0"], "Left Click")
    def click_right(self): self._run(["ydotool", "click", "0xC1"], "Right Click")
    def mouse_down_left(self): self._run(["ydotool", "click", "0x40"], "Left Down")
    def mouse_up_left(self): self._run(["ydotool", "click", "0x80"], "Left Up")

    def page_down(self): self.key("109:1 109:0", "PageDown")
    def page_up(self): self.key("104:1 104:0", "PageUp")
    def scroll_down_small(self): self.key("108:1 108:0", "ArrowDown")
    def scroll_up_small(self): self.key("103:1 103:0", "ArrowUp")
    def next_tab(self): self.key("29:1 15:1 15:0 29:0", "Ctrl+Tab")
    def previous_tab(self): self.key("29:1 42:1 15:1 15:0 42:0 29:0", "Ctrl+Shift+Tab")
    def browser_back(self): self.key("56:1 105:1 105:0 56:0", "Alt+Left")
    def browser_forward(self): self.key("56:1 106:1 106:0 56:0", "Alt+Right")
    def alt_tab(self): self.key("56:1 15:1 15:0 56:0", "Alt+Tab")
    def alt_shift_tab(self): self.key("56:1 42:1 15:1 15:0 42:0 56:0", "Alt+Shift+Tab")
    def overview(self): self.key("125:1 125:0", "Super / Overview")
    def enter(self): self.key("28:1 28:0", "Enter")
    def escape(self): self.key("1:1 1:0", "Escape")
    def volume_up(self): self.key("115:1 115:0", "Volume Up")
    def volume_down(self): self.key("114:1 114:0", "Volume Down")
    def volume_mute(self): self.key("113:1 113:0", "Mute")
    def workspace_next(self): self.key("125:1 109:1 109:0 125:0", "Workspace Next / Super+PageDown")
    def workspace_prev(self): self.key("125:1 104:1 104:0 125:0", "Workspace Prev / Super+PageUp")
    def zoom_in(self): self.key("29:1 13:1 13:0 29:0", "Zoom In / Ctrl+=")
    def zoom_out(self): self.key("29:1 12:1 12:0 29:0", "Zoom Out / Ctrl+-")
