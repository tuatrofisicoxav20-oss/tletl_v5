
import time
from typing import Any, Dict
import cv2


class YOLOPoseContext:
    # Capa opcional de YOLO11 Pose.
    # YOLO11 pose normal detecta keypoints corporales humanos, no dedos.
    # Sirve como contexto de cuerpo/brazo/muñeca y debugging visual.

    def __init__(self, model_path: str = "yolo11n-pose.pt", every_n: int = 3, conf: float = 0.35):
        self.model_path = model_path
        self.every_n = max(1, int(every_n))
        self.conf = float(conf)
        self.frame_i = 0
        self.last_result = None
        self.last_info: Dict[str, Any] = {
            "enabled": True,
            "ok": False,
            "people": 0,
            "wrists": [],
            "elbows": [],
            "shoulders": [],
            "last_ms": 0.0,
            "error": "",
        }

        try:
            from ultralytics import YOLO
            self.model = YOLO(model_path)
            self.last_info["ok"] = True
        except Exception as exc:
            self.model = None
            self.last_info["ok"] = False
            self.last_info["error"] = str(exc)
            print(f"[YOLO] No pude cargar {model_path}: {exc}")

    def ready(self) -> bool:
        return self.model is not None

    def process(self, frame):
        if self.model is None:
            return self.last_info

        self.frame_i += 1
        if self.frame_i % self.every_n != 0:
            return self.last_info

        start = time.time()
        try:
            results = self.model.predict(frame, conf=self.conf, verbose=False)
            self.last_result = results[0] if results else None
            self.last_info = self._extract_info(self.last_result)
            self.last_info["last_ms"] = (time.time() - start) * 1000.0
            self.last_info["ok"] = True
            self.last_info["error"] = ""
        except Exception as exc:
            self.last_info["ok"] = False
            self.last_info["error"] = str(exc)

        return self.last_info

    def _extract_info(self, result):
        info = {
            "enabled": True,
            "ok": True,
            "people": 0,
            "wrists": [],
            "elbows": [],
            "shoulders": [],
            "last_ms": 0.0,
            "error": "",
        }

        if result is None or getattr(result, "keypoints", None) is None:
            return info

        keypoints = result.keypoints
        xy = getattr(keypoints, "xy", None)
        conf = getattr(keypoints, "conf", None)
        if xy is None:
            return info

        try:
            xy_list = xy.cpu().numpy()
            conf_list = conf.cpu().numpy() if conf is not None else None
        except Exception:
            return info

        info["people"] = len(xy_list)

        for person_i, pts in enumerate(xy_list):
            for name, idx in [
                ("left_wrist", 9),
                ("right_wrist", 10),
                ("left_elbow", 7),
                ("right_elbow", 8),
                ("left_shoulder", 5),
                ("right_shoulder", 6),
            ]:
                if idx >= len(pts):
                    continue
                x, y = float(pts[idx][0]), float(pts[idx][1])
                c = float(conf_list[person_i][idx]) if conf_list is not None else 1.0
                item = {"name": name, "x": x, "y": y, "conf": c, "person": person_i}
                if "wrist" in name:
                    info["wrists"].append(item)
                elif "elbow" in name:
                    info["elbows"].append(item)
                elif "shoulder" in name:
                    info["shoulders"].append(item)

        return info

    def draw(self, frame):
        if self.last_result is None:
            if not self.last_info.get("ok", False):
                cv2.putText(frame, "YOLO pose OFF/error", (20, frame.shape[0] - 52),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 255), 2, cv2.LINE_AA)
            return frame

        info = self.last_info

        for item in info.get("wrists", []):
            x, y = int(item["x"]), int(item["y"])
            cv2.circle(frame, (x, y), 7, (255, 120, 0), -1)
            cv2.putText(frame, item["name"], (x + 8, y), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 120, 0), 1)

        for item in info.get("elbows", []):
            x, y = int(item["x"]), int(item["y"])
            cv2.circle(frame, (x, y), 5, (180, 180, 0), -1)

        for item in info.get("shoulders", []):
            x, y = int(item["x"]), int(item["y"])
            cv2.circle(frame, (x, y), 5, (120, 180, 255), -1)

        text = f"YOLO11 pose: people={info.get('people', 0)} {info.get('last_ms', 0):.0f}ms"
        cv2.putText(frame, text, (20, frame.shape[0] - 52),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 120, 0), 2, cv2.LINE_AA)
        return frame

    def process_and_draw(self, frame):
        self.process(frame)
        return self.draw(frame)
