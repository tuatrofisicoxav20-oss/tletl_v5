import time
from typing import Any, Dict, List, Optional, Tuple

import cv2
import mediapipe as mp
import numpy as np

from .features import extract_features
from .geometry import palm_center_x, palm_center_y, palm_scale, points_from_landmarks
from .gestures import classify_hybrid
from .low_light import LowLightEnhancer
from .state import DetectedHand, HandState


mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


def open_camera(index: int, width: int, height: int, fps: int):
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"No pude abrir la cámara index={index}. Prueba --camera 1 o --camera 2.")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def get_hand_state(states: Dict[str, HandState], label: str, args) -> HandState:
    if label not in states:
        states[label] = HandState(args)
    return states[label]


def detect_hands(
    frame: np.ndarray,
    hands_model: Any,
    states: Dict[str, HandState],
    enhancer: LowLightEnhancer,
    profile: Optional[Dict[str, Any]],
    args,
    gesture_ai: Optional[Any] = None,
) -> Tuple[np.ndarray, List[DetectedHand]]:
    frame = cv2.flip(frame, 1)
    enhanced = enhancer.enhance(frame)
    rgb = cv2.cvtColor(enhanced, cv2.COLOR_BGR2RGB)
    result = hands_model.process(rgb)

    detected: List[DetectedHand] = []
    now = time.time()

    if not result.multi_hand_landmarks:
        for st in states.values():
            st.stable.clear()
            st.motion.reset()
            st.cursor.reset()
        return frame, detected

    handedness_list = result.multi_handedness or []

    for i, raw_landmarks in enumerate(result.multi_hand_landmarks):
        label = f"Hand{i}"
        if i < len(handedness_list):
            classification = handedness_list[i].classification[0]
            label = classification.label
            if label in [h.label for h in detected]:
                label = f"{label}_{i}"

        state = get_hand_state(states, label, args)
        state.last_seen = now

        raw_points = points_from_landmarks(raw_landmarks)
        points = state.smoother.update(raw_points)
        features = extract_features(points)
        center_x = features["palm_center_x"]
        center_y = features["palm_center_y"]

        state.motion.update(center_x, center_y)
        swipe = state.motion.swipe()

        rule_gesture, rule_confidence, rule_source, fingers = classify_hybrid(points, features, profile)

        ai_gesture = "UNKNOWN"
        ai_confidence = 0.0
        if gesture_ai is not None and gesture_ai.ready():
            ai_gesture, ai_confidence, _ai_info = gesture_ai.predict(features)

        # Fusión híbrida:
        # 1. Si IA y reglas coinciden, subimos confianza.
        # 2. Si la IA está muy segura y las reglas dudan, usamos IA.
        # 3. Si el gesto crítico es PINCH/FIST por regla rápida, respetamos regla para baja latencia.
        raw_gesture = rule_gesture
        confidence = rule_confidence
        source = rule_source

        if ai_gesture != "UNKNOWN":
            if ai_gesture == rule_gesture:
                raw_gesture = ai_gesture
                confidence = min(1.0, max(ai_confidence, rule_confidence) + 0.12)
                source = "ai+regla"
            elif rule_gesture in {"UNKNOWN", "NEUTRAL"} and ai_confidence >= 0.66:
                raw_gesture = ai_gesture
                confidence = ai_confidence
                source = "ai"
            elif ai_confidence >= 0.82 and rule_confidence < 0.70:
                raw_gesture = ai_gesture
                confidence = ai_confidence
                source = "ai-fuerte"

        stable_gesture = state.stable.update(raw_gesture)

        action_gesture = stable_gesture
        if raw_gesture == "PINCH" and confidence >= 0.58:
            action_gesture = "PINCH"
        elif raw_gesture == "FIST" and confidence >= 0.72:
            action_gesture = "FIST"

        detected.append(DetectedHand(
            label=label,
            raw_landmarks=raw_landmarks,
            points=points,
            features=features,
            raw_gesture=raw_gesture,
            stable_gesture=stable_gesture,
            action_gesture=action_gesture,
            confidence=confidence,
            source=source,
            fingers=fingers,
            center_x=center_x,
            center_y=center_y,
            scale=palm_scale(points),
            speed=state.motion.last_velocity,
            alpha=state.smoother.last_alpha,
            swipe=swipe,
        ))

        mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)
        cv2.putText(frame, f"{label} {raw_gesture} {confidence:.2f} {source}",
                    (int(center_x * frame.shape[1]) - 60, int(center_y * frame.shape[0]) - 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 255, 255), 2, cv2.LINE_AA)

    for label in list(states.keys()):
        if now - states[label].last_seen > 1.0:
            states[label].reset()

    detected.sort(key=lambda h: h.scale, reverse=True)
    return frame, detected
