from typing import Any, Dict, List
import cv2
import numpy as np

from .geometry import clamp
from .constants import UP_ZONE, DOWN_ZONE


def draw_text_box(frame: np.ndarray, lines: List[str], origin=(14, 14), font_scale=0.50):
    x, y = origin
    line_h = 25
    width = min(frame.shape[1] - 25, 1040)
    height = 20 + line_h * len(lines)
    cv2.rectangle(frame, (x - 7, y - 8), (x + width, y + height), (0, 0, 0), -1)
    for i, line in enumerate(lines):
        cv2.putText(frame, line, (x, y + 20 + i * line_h), cv2.FONT_HERSHEY_SIMPLEX,
                    font_scale, (255, 255, 255), 2, cv2.LINE_AA)


def draw_progress_bar(frame: np.ndarray, progress: float, y_offset: int = 42, color=(0, 220, 120)):
    h, w = frame.shape[:2]
    x1, x2 = 24, w - 24
    y = h - y_offset
    cv2.rectangle(frame, (x1, y - 10), (x2, y + 10), (40, 40, 40), -1)
    filled = int((x2 - x1) * clamp(progress, 0.0, 1.0))
    cv2.rectangle(frame, (x1, y - 10), (x1 + filled, y + 10), color, -1)
    cv2.rectangle(frame, (x1, y - 10), (x2, y + 10), (255, 255, 255), 2)


def draw_zones(frame: np.ndarray):
    h, w = frame.shape[:2]
    cv2.line(frame, (0, int(h * UP_ZONE)), (w, int(h * UP_ZONE)), (255, 255, 0), 1)
    cv2.line(frame, (0, int(h * DOWN_ZONE)), (w, int(h * DOWN_ZONE)), (255, 255, 0), 1)


def draw_status_window(info: Dict[str, Any], enabled: bool = True):
    if not enabled:
        return
    img = np.zeros((286, 560, 3), dtype=np.uint8)
    active = info.get("active", False)
    color = (0, 210, 80) if active else (0, 0, 230)
    cv2.rectangle(img, (0, 0), (560, 286), (18, 18, 18), -1)
    cv2.circle(img, (34, 38), 18, color, -1)
    title = "TLETL ACTIVO" if active else "TLETL APAGADO"
    cv2.putText(img, title, (65, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.78, (255, 255, 255), 2, cv2.LINE_AA)

    lines = [
        f"Modo: {info.get('mode', '-')}",
        f"Manos: {info.get('hands', 0)} | FPS: {info.get('fps', 0):.1f}",
        f"Principal: {info.get('main_gesture', '-')}",
        f"Secundaria: {info.get('second_gesture', '-')}",
        f"Accion: {info.get('last_action', '-')}",
        f"Luz: {info.get('luma', 0):.0f} | Mejora: {info.get('light_mode', '-')}",
        f"Aprendizaje: {info.get('adaptive', '0')}",
    ]
    y = 84
    for line in lines:
        cv2.putText(img, line, (24, y), cv2.FONT_HERSHEY_SIMPLEX, 0.53, (230, 230, 230), 2, cv2.LINE_AA)
        y += 27

    cv2.putText(img, "Puño = emergencia | Q = salir", (24, 263), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (180, 180, 180), 1, cv2.LINE_AA)
    cv2.imshow("Tletl Estado", img)


class StatusNotifier:
    def __init__(self, enabled: bool = True, backend: str = "auto"):
        self.enabled = enabled and backend != "off"
        self.backend = "off"
        self.root = None
        self.labels: Dict[str, Any] = {}
        if not self.enabled:
            return

        if backend in {"auto", "tk"}:
            try:
                import tkinter as tk
                self.root = tk.Tk()
                self.root.title("Tletl Estado")
                self.root.geometry("360x235+40+80")
                self.root.attributes("-topmost", True)
                self.root.configure(bg="#111111")
                self.root.resizable(False, False)
                title = tk.Label(self.root, text="TLETL", bg="#111111", fg="white", font=("Sans", 17, "bold"))
                title.pack(anchor="w", padx=16, pady=(12, 3))
                for key in ["active", "mode", "hands", "main", "second", "action", "light", "adaptive"]:
                    lbl = tk.Label(self.root, text="-", bg="#111111", fg="#dddddd", font=("Sans", 10))
                    lbl.pack(anchor="w", padx=16, pady=1)
                    self.labels[key] = lbl
                self.backend = "tk"
                return
            except Exception as exc:
                print(f"[AVISO] Tk status falló, usaré OpenCV: {exc}")

        self.backend = "cv2"
        cv2.namedWindow("Tletl Estado", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("Tletl Estado", 560, 286)

    def update(self, info: Dict[str, Any]):
        if not self.enabled:
            return

        if self.backend == "tk" and self.root is not None:
            active = bool(info.get("active", False))
            self.labels["active"].configure(
                text="Estado: ACTIVO" if active else "Estado: APAGADO",
                fg="#4dff88" if active else "#ff5555",
            )
            self.labels["mode"].configure(text=f"Modo: {info.get('mode', '-')}")
            self.labels["hands"].configure(text=f"Manos: {info.get('hands', 0)} | FPS: {info.get('fps', 0):.1f}")
            self.labels["main"].configure(text=f"Principal: {info.get('main_gesture', '-')}")
            self.labels["second"].configure(text=f"Secundaria: {info.get('second_gesture', '-')}")
            self.labels["action"].configure(text=f"Acción: {info.get('last_action', '-')}")
            self.labels["light"].configure(text=f"Luz: {info.get('luma', 0):.0f} | Mejora: {info.get('light_mode', '-')}")
            self.labels["adaptive"].configure(text=f"Aprendizaje: {info.get('adaptive', '0')}")
            try:
                self.root.update_idletasks()
                self.root.update()
            except Exception:
                self.enabled = False

        elif self.backend == "cv2":
            draw_status_window(info, enabled=True)

    def close(self):
        if self.root is not None:
            try:
                self.root.destroy()
            except Exception:
                pass
