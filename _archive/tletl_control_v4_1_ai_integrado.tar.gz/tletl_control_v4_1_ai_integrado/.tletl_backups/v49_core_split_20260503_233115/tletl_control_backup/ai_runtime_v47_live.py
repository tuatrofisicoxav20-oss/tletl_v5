"""
Tletl V4.7.3 - runtime AI estabilizado para interfaz.

Cambio clave sobre V4.7.2:
- Ya no usa un centroide único por gesto. Eso era demasiado tosco para un banco
  multimodal con palma/frente/dorso/lateral.
- Usa KNN/prototipos por clase, robust scaling y pesos de features.
- Excluye posición absoluta de la mano, porque entrenar POINT por estar más a la derecha
  es una forma elegante de sabotearse.
- Mantiene crítico estricto y fallback seguro.
"""

from __future__ import annotations

import json
import math
import os
import time
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

import numpy as np

from .hand_orientation import ORIENTATION_FEATURE_KEYS, extract_orientation_features, orientation_label, orientation_summary

try:
    from .ai_critic_v47 import strict_critic_v47
except Exception:  # pragma: no cover
    strict_critic_v47 = None


VALID_GESTURES = {"OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"}
GESTURE_ORDER = ["OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"]

LABEL_KEYS = (
    "label", "gesture", "target", "class", "class_name", "y", "name", "expected", "manual_label",
)

META_NUMERIC_KEYS = {
    "timestamp", "time", "created_at", "updated_at", "frame", "frame_id", "sample", "sample_id",
    "camera", "camera_id", "width", "height", "fps", "score", "confidence", "accepted",
    "orientation_complete", "bad_line", "line", "idx", "index", "count",
}

# Features que NO deben entrar al clasificador de gesto.
# La posición absoluta cambia por dónde pusiste la mano, no por el gesto.
POSITION_FEATURE_KEYS = {
    "palm_center_x", "palm_center_y", "center_x", "center_y", "hand_center_x", "hand_center_y",
    "screen_x", "screen_y", "x", "y", "px", "py",
}

AI_TO_LEGACY = {
    "OPEN_PALM": "OPEN_HAND",
    "FIST": "FIST",
    "POINT": "POINT",
    "VICTORY": "TWO_FINGERS",
    "PINCH": "PINCH",
    "THREE": "THREE_FINGERS",
    "NEUTRAL": "UNKNOWN",
}

RULE_TO_AI = {
    "OPEN_HAND": "OPEN_PALM",
    "OPEN_PALM": "OPEN_PALM",
    "FIST": "FIST",
    "POINT": "POINT",
    "TWO_FINGERS": "VICTORY",
    "VICTORY": "VICTORY",
    "THREE_FINGERS": "THREE",
    "THREE": "THREE",
    "PINCH": "PINCH",
    "UNKNOWN": "NEUTRAL",
    "NO_HAND": "NEUTRAL",
    "CALIBRANDO": "NEUTRAL",
    "NEUTRAL": "NEUTRAL",
}

DANGEROUS_GESTURES = {"PINCH", "POINT", "VICTORY", "THREE", "FIST"}


def ai_to_legacy_raw(gesture: str, fallback: str = "UNKNOWN") -> str:
    neutral_raw = os.environ.get("TLETL_AI_V47_NEUTRAL_RAW", "UNKNOWN").strip() or "UNKNOWN"
    mapping = dict(AI_TO_LEGACY)
    mapping["NEUTRAL"] = neutral_raw
    return mapping.get(str(gesture or ""), fallback or "UNKNOWN")


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        v = float(value)
        if math.isfinite(v):
            return v
    except Exception:
        pass
    return default


def _env_float(name: str, default: float) -> float:
    return _safe_float(os.environ.get(name), default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except Exception:
        return default


def _as_xyz(point: Any) -> Tuple[float, float, float]:
    if hasattr(point, "x") and hasattr(point, "y"):
        return float(point.x), float(point.y), float(getattr(point, "z", 0.0))
    if isinstance(point, Mapping):
        return float(point.get("x", 0.0)), float(point.get("y", 0.0)), float(point.get("z", 0.0))
    if isinstance(point, (list, tuple)):
        return (
            float(point[0]) if len(point) > 0 else 0.0,
            float(point[1]) if len(point) > 1 else 0.0,
            float(point[2]) if len(point) > 2 else 0.0,
        )
    return 0.0, 0.0, 0.0


def _landmarks_array(landmarks: Any) -> np.ndarray:
    if hasattr(landmarks, "landmark"):
        landmarks = landmarks.landmark
    arr = np.asarray([_as_xyz(p) for p in landmarks], dtype=float)
    if arr.shape[0] < 21:
        raise ValueError(f"landmarks insuficientes: {arr.shape}")
    return arr[:21, :3]


def _dist(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b))


def _palm_scale(lm: np.ndarray) -> float:
    return max((_dist(lm[0], lm[9]) + _dist(lm[5], lm[17])) / 2.0, 1e-6)


def _fallback_geometric_features(landmarks: Any) -> Dict[str, float]:
    lm = _landmarks_array(landmarks)
    scale = _palm_scale(lm)
    wrist = lm[0]
    features: Dict[str, float] = {}

    fingers = {
        "index": (8, 6, 5),
        "middle": (12, 10, 9),
        "ring": (16, 14, 13),
        "pinky": (20, 18, 17),
    }
    for name, (tip, pip, mcp) in fingers.items():
        features[f"{name}_tip_wrist"] = _dist(lm[tip], wrist) / scale
        features[f"{name}_pip_wrist"] = _dist(lm[pip], wrist) / scale
        features[f"{name}_mcp_wrist"] = _dist(lm[mcp], wrist) / scale
        features[f"{name}_tip_mcp"] = _dist(lm[tip], lm[mcp]) / scale
        features[f"{name}_tip_pip"] = _dist(lm[tip], lm[pip]) / scale
        features[f"{name}_vertical"] = (lm[pip, 1] - lm[tip, 1]) / scale
        features[f"{name}_curl"] = (_dist(lm[tip], wrist) - _dist(lm[pip], wrist)) / scale

    features["thumb_tip_wrist"] = _dist(lm[4], wrist) / scale
    features["thumb_ip_wrist"] = _dist(lm[3], wrist) / scale
    features["thumb_tip_index_mcp"] = _dist(lm[4], lm[5]) / scale
    features["thumb_tip_index_tip"] = _dist(lm[4], lm[8]) / scale
    features["thumb_tip_middle_tip"] = _dist(lm[4], lm[12]) / scale
    features["thumb_horizontal"] = abs(lm[4, 0] - lm[3, 0]) / scale
    features["thumb_vertical"] = abs(lm[4, 1] - lm[3, 1]) / scale

    features["index_middle_spread"] = _dist(lm[8], lm[12]) / scale
    features["middle_ring_spread"] = _dist(lm[12], lm[16]) / scale
    features["ring_pinky_spread"] = _dist(lm[16], lm[20]) / scale
    features["index_pinky_spread"] = _dist(lm[8], lm[20]) / scale
    features["palm_width"] = _dist(lm[5], lm[17]) / scale
    features["wrist_middle_mcp"] = _dist(lm[0], lm[9]) / scale
    features["palm_center_x"] = float(np.mean([lm[i, 0] for i in [0, 5, 9, 13, 17]]))
    features["palm_center_y"] = float(np.mean([lm[i, 1] for i in [0, 5, 9, 13, 17]]))
    return {k: round(float(v), 6) for k, v in features.items() if math.isfinite(float(v))}


def _discover_project_extractor():
    try:
        from . import features as feature_module
    except Exception:
        return None

    preferred = [
        "extract_features", "extract_hand_features", "build_features", "make_features",
        "features_from_landmarks", "get_features",
    ]
    for name in preferred:
        fn = getattr(feature_module, name, None)
        if callable(fn):
            return fn

    for name in dir(feature_module):
        low = name.lower()
        if "feature" not in low:
            continue
        fn = getattr(feature_module, name, None)
        if callable(fn):
            return fn
    return None


def _call_extractor(fn, landmarks: Any, handedness: Optional[str]) -> Optional[Dict[str, float]]:
    if fn is None:
        return None
    attempts = [
        ((landmarks,), {"handedness": handedness}),
        ((landmarks, handedness), {}),
        ((landmarks,), {}),
    ]
    for args, kwargs in attempts:
        try:
            value = fn(*args, **kwargs)
            if isinstance(value, tuple):
                for item in value:
                    if isinstance(item, dict):
                        value = item
                        break
            if isinstance(value, dict):
                clean = {}
                for k, v in value.items():
                    if isinstance(v, (int, float)) and math.isfinite(float(v)):
                        clean[str(k)] = round(float(v), 6)
                if clean:
                    return clean
        except TypeError:
            continue
        except Exception:
            continue
    return None


def _extract_label(sample: Mapping[str, Any]) -> Optional[str]:
    for key in LABEL_KEYS:
        value = sample.get(key)
        if isinstance(value, str):
            label = value.strip().upper()
            if label in VALID_GESTURES:
                return label
            mapped = RULE_TO_AI.get(label)
            if mapped in VALID_GESTURES:
                return mapped
    meta = sample.get("meta")
    if isinstance(meta, Mapping):
        return _extract_label(meta)
    return None


def _should_ignore_feature(key: str) -> bool:
    k = str(key)
    low = k.lower()
    if k in POSITION_FEATURE_KEYS:
        return True
    if low in POSITION_FEATURE_KEYS:
        return True
    if low.endswith("_center_x") or low.endswith("_center_y"):
        return True
    if low in META_NUMERIC_KEYS:
        return True
    if low.startswith("bbox") or low.startswith("image_") or low.startswith("frame_"):
        return True
    return False


def _flatten_features(sample: Mapping[str, Any]) -> Dict[str, float]:
    out: Dict[str, float] = {}

    nested = sample.get("features")
    if isinstance(nested, Mapping):
        for k, v in nested.items():
            if not _should_ignore_feature(str(k)) and isinstance(v, (int, float)) and math.isfinite(float(v)):
                out[str(k)] = float(v)

    for k, v in sample.items():
        key = str(k)
        if key in LABEL_KEYS or key in META_NUMERIC_KEYS:
            continue
        if key in {"features", "landmarks", "hand_landmarks", "meta", "orientation", "scores", "votes"}:
            continue
        if _should_ignore_feature(key):
            continue
        if isinstance(v, (int, float)) and math.isfinite(float(v)):
            out[key] = float(v)

    return out


def _feature_weight(key: str) -> float:
    k = key.lower()
    orientation_weight = _env_float("TLETL_AI_V47_ORIENTATION_WEIGHT", 0.55)

    if key in ORIENTATION_FEATURE_KEYS or k.startswith("palm_") or k.endswith("_score") or "depth" in k:
        # Orientación ayuda, pero si pesa demasiado gana contra la geometría del gesto.
        return orientation_weight
    if "thumb_tip_index_tip" in k:
        return 2.25
    if "pinch" in k:
        return 2.0
    if "tip_mcp" in k or "tip_pip" in k or "curl" in k or "vertical" in k:
        return 1.45
    if "spread" in k:
        return 1.25
    if "thumb" in k:
        return 1.30
    return 1.0


def _softmax_from_distances(distances: Mapping[str, float], temperature: float) -> Dict[str, float]:
    if not distances:
        return {}
    vals = {g: math.exp(-max(0.0, d) * temperature) for g, d in distances.items()}
    total = sum(vals.values()) or 1.0
    return {g: v / total for g, v in vals.items()}


class RobustKNNBankClassifier:
    def __init__(self, bank_path: Path):
        self.bank_path = Path(bank_path)
        self.samples_by_label: Dict[str, List[Dict[str, float]]] = defaultdict(list)
        self.feature_keys: List[str] = []
        self.total_samples = 0
        self.loaded_at = 0.0

        self.labels: List[str] = []
        self.label_array: np.ndarray = np.asarray([], dtype=object)
        self.matrix: np.ndarray = np.zeros((0, 0), dtype=float)
        self.center: np.ndarray = np.zeros((0,), dtype=float)
        self.scale: np.ndarray = np.ones((0,), dtype=float)
        self.weights: np.ndarray = np.ones((0,), dtype=float)
        self.label_indices: Dict[str, np.ndarray] = {}
        self.load()

    def load(self) -> None:
        self.samples_by_label.clear()
        self.feature_keys = []
        self.total_samples = 0

        if not self.bank_path.exists():
            raise FileNotFoundError(f"No existe banco V4.7: {self.bank_path}")

        feature_counts = Counter()
        bad = 0
        for line_no, line in enumerate(self.bank_path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            line = line.strip()
            if not line:
                continue
            try:
                sample = json.loads(line)
            except Exception:
                bad += 1
                continue
            if not isinstance(sample, Mapping):
                bad += 1
                continue
            label = _extract_label(sample)
            feats = _flatten_features(sample)
            if label not in VALID_GESTURES or len(feats) < 8:
                bad += 1
                continue
            clean = {k: float(v) for k, v in feats.items() if not _should_ignore_feature(k) and math.isfinite(float(v))}
            if len(clean) < 8:
                bad += 1
                continue
            self.samples_by_label[label].append(clean)
            feature_counts.update(clean.keys())
            self.total_samples += 1

        if self.total_samples <= 0:
            raise RuntimeError(f"Banco sin muestras válidas para runtime: {self.bank_path}")

        # Feature debe existir en muchas muestras para evitar llaves accidentales.
        min_presence = max(12, int(self.total_samples * _env_float("TLETL_AI_V47_MIN_FEATURE_PRESENCE", 0.45)))
        self.feature_keys = sorted(k for k, c in feature_counts.items() if c >= min_presence and not _should_ignore_feature(k))
        if len(self.feature_keys) < 8:
            raise RuntimeError(f"Muy pocas features comunes útiles: {len(self.feature_keys)}")

        rows: List[List[float]] = []
        labels: List[str] = []
        all_values: Dict[str, List[float]] = defaultdict(list)
        for samples in self.samples_by_label.values():
            for s in samples:
                for k in self.feature_keys:
                    if k in s and math.isfinite(float(s[k])):
                        all_values[k].append(float(s[k]))

        medians: Dict[str, float] = {}
        scales: Dict[str, float] = {}
        for k in self.feature_keys:
            vals = np.asarray(all_values.get(k, [0.0]), dtype=float)
            med = float(np.median(vals))
            q25, q75 = np.percentile(vals, [25, 75])
            iqr_scale = float((q75 - q25) / 1.349) if q75 > q25 else 0.0
            std_scale = float(np.std(vals))
            scales[k] = max(iqr_scale, std_scale * 0.40, 0.025)
            medians[k] = med

        for label in GESTURE_ORDER:
            for s in self.samples_by_label.get(label, []):
                rows.append([float(s.get(k, medians[k])) for k in self.feature_keys])
                labels.append(label)

        self.matrix = np.asarray(rows, dtype=float)
        self.labels = labels
        self.label_array = np.asarray(labels, dtype=object)
        self.center = np.asarray([medians[k] for k in self.feature_keys], dtype=float)
        self.scale = np.asarray([scales[k] for k in self.feature_keys], dtype=float)
        self.weights = np.asarray([_feature_weight(k) for k in self.feature_keys], dtype=float)
        self.matrix = (self.matrix - self.center) / self.scale

        self.label_indices = {g: np.where(self.label_array == g)[0] for g in GESTURE_ORDER if np.any(self.label_array == g)}
        self.loaded_at = time.time()

        print(
            f"[TLETL V4.7.3 Runtime] Banco cargado: {self.total_samples} muestras, "
            f"{len(self.feature_keys)} features útiles, labels={{{', '.join(f'{g}:{len(v)}' for g, v in self.samples_by_label.items())}}}"
        )
        if bad:
            print(f"[TLETL V4.7.3 Runtime] Líneas ignoradas: {bad}")

    def _vectorize(self, features: Mapping[str, float]) -> Tuple[np.ndarray, int]:
        usable = 0
        vals = []
        for i, k in enumerate(self.feature_keys):
            if k in features and isinstance(features.get(k), (int, float)) and math.isfinite(float(features[k])):
                vals.append(float(features[k]))
                usable += 1
            else:
                vals.append(float(self.center[i]))
        x = (np.asarray(vals, dtype=float) - self.center) / self.scale
        return x, usable

    def predict(self, features: Dict[str, float]) -> Dict[str, Any]:
        x, usable = self._vectorize(features)
        if usable < max(8, int(len(self.feature_keys) * 0.50)):
            return {
                "gesture": "NEUTRAL",
                "confidence": 0.0,
                "scores": {},
                "distances": {},
                "margin": 0.0,
                "used_features": usable,
                "reason": "pocas features compatibles",
                "top": [],
            }

        dif = self.matrix - x.reshape(1, -1)
        d_all = np.sqrt(np.mean((dif * dif) * self.weights.reshape(1, -1), axis=1))
        k_class = max(3, _env_int("TLETL_AI_V47_K", 11))

        class_dist: Dict[str, float] = {}
        class_nearest: Dict[str, float] = {}
        for label, idxs in self.label_indices.items():
            if len(idxs) == 0:
                continue
            d = d_all[idxs]
            kk = min(k_class, len(d))
            nearest = np.partition(d, kk - 1)[:kk]
            # Mezcla promedio y mejor vecino: promedio da estabilidad, mejor vecino respeta multimodalidad.
            class_dist[label] = float(np.mean(nearest) * 0.78 + np.min(nearest) * 0.22)
            class_nearest[label] = float(np.min(nearest))

        temp = _env_float("TLETL_AI_V47_SOFTMAX_TEMP", 3.0)
        scores = _softmax_from_distances(class_dist, temp)
        ordered = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        best, best_score = ordered[0]
        second, second_score = ordered[1] if len(ordered) > 1 else ("-", 0.0)
        margin = float(best_score - second_score)
        top = [(g, float(scores[g]), float(class_dist[g]), float(class_nearest.get(g, 999.0))) for g, _ in ordered[:5]]

        return {
            "gesture": best,
            "confidence": float(best_score),
            "scores": scores,
            "distances": class_dist,
            "nearest": class_nearest,
            "margin": margin,
            "second": second,
            "used_features": usable,
            "reason": "robust-knn-bank",
            "top": top,
        }

    def info(self) -> Dict[str, Any]:
        return {
            "bank": str(self.bank_path),
            "samples": self.total_samples,
            "gestures": {g: len(v) for g, v in self.samples_by_label.items()},
            "feature_keys": len(self.feature_keys),
            "ignored_position_features": sorted(POSITION_FEATURE_KEYS),
            "orientation_features": [k for k in self.feature_keys if k in ORIENTATION_FEATURE_KEYS],
        }


class TemporalGestureGate:
    def __init__(self, size: int = 5, min_count: int = 3):
        self.size = max(3, int(size))
        self.min_count = max(2, int(min_count))
        self.history: Dict[str, deque[str]] = defaultdict(lambda: deque(maxlen=self.size))

    def update(self, key: str, gesture: str, accepted: bool, confidence: float) -> Tuple[str, str]:
        # Para evitar que una predicción suelta dispare acciones.
        if not accepted:
            self.history[key].append("NEUTRAL")
            return "NEUTRAL", "temporal:blocked"
        self.history[key].append(gesture)
        common, count = Counter(self.history[key]).most_common(1)[0]
        if count >= self.min_count:
            return common, f"temporal:{common}:{count}/{len(self.history[key])}"
        if confidence >= _env_float("TLETL_AI_V47_IMMEDIATE_CONF", 0.82) and gesture in {"OPEN_PALM", "FIST"}:
            return gesture, "temporal:immediate-safe"
        return "NEUTRAL", f"temporal:waiting:{count}/{len(self.history[key])}"


class LiveRuntimeV47:
    def __init__(self, bank_path: Optional[Path] = None):
        if bank_path is None:
            bank_path = Path(
                os.environ.get("TLETL_AI_V47_BANK")
                or os.environ.get("TLETL_GESTURE_BANK")
                or os.environ.get("TLETL_BANK_PATH")
                or "datasets/tletl_gesture_bank_v2_features.jsonl"
            )
        self.bank_path = Path(bank_path).expanduser().resolve()
        self.project_extractor = _discover_project_extractor()
        self.classifier = RobustKNNBankClassifier(self.bank_path)
        self.temporal = TemporalGestureGate(
            size=_env_int("TLETL_AI_V47_TEMPORAL_SIZE", 5),
            min_count=_env_int("TLETL_AI_V47_TEMPORAL_MIN", 3),
        )
        self.last_error = ""

    def reload_if_needed(self) -> None:
        try:
            mtime = self.bank_path.stat().st_mtime
            if mtime > self.classifier.loaded_at and time.time() - self.classifier.loaded_at > 2.0:
                self.classifier.load()
        except Exception:
            pass

    def extract_features(self, landmarks: Any, handedness: Optional[str] = None) -> Dict[str, float]:
        features = _call_extractor(self.project_extractor, landmarks, handedness) or _fallback_geometric_features(landmarks)
        orient = extract_orientation_features(landmarks, handedness=handedness)
        features.update(orient)
        return {
            k: float(v)
            for k, v in features.items()
            if isinstance(v, (int, float)) and math.isfinite(float(v)) and not _should_ignore_feature(k)
        }

    def _apply_rule_guard(self, pred: Dict[str, Any], rule_raw: str) -> Tuple[str, str]:
        gesture = str(pred.get("gesture", "NEUTRAL"))
        rule_ai = RULE_TO_AI.get(str(rule_raw), None)
        conf = float(pred.get("confidence", 0.0))
        margin = float(pred.get("margin", 0.0))

        if os.environ.get("TLETL_AI_V47_RULE_GUARD", "1") == "0" or not rule_ai:
            return gesture, "rule_guard:off"

        if rule_ai == "NEUTRAL":
            # Si las reglas no ven gesto claro y la IA tampoco tiene margen, no ejecutar.
            if gesture in DANGEROUS_GESTURES and (conf < 0.58 or margin < 0.12):
                return "NEUTRAL", f"rule_guard:block dangerous {gesture} vs rule NEUTRAL"
            return gesture, "rule_guard:neutral-ok"

        if gesture == rule_ai:
            return gesture, "rule_guard:agree"

        # Si IA y reglas se contradicen en gestos de acción y la IA no está muy segura, bloquea.
        if gesture in DANGEROUS_GESTURES or rule_ai in DANGEROUS_GESTURES:
            if conf < _env_float("TLETL_AI_V47_RULE_OVERRIDE_CONF", 0.70) or margin < _env_float("TLETL_AI_V47_RULE_OVERRIDE_MARGIN", 0.18):
                return "NEUTRAL", f"rule_guard:conflict ai={gesture} rule={rule_ai}"

        return gesture, f"rule_guard:ai-override rule={rule_ai}"

    def classify_landmarks(self, landmarks: Any, handedness: Optional[str] = None, rule_raw: str = "UNKNOWN") -> Dict[str, Any]:
        self.reload_if_needed()
        features = self.extract_features(landmarks, handedness=handedness)
        pred = self.classifier.predict(features)
        raw_pred = str(pred.get("gesture", "NEUTRAL"))
        guarded_gesture, guard_reason = self._apply_rule_guard(pred, rule_raw)
        confidence = float(pred.get("confidence", 0.0))
        scores = pred.get("scores", {})

        if guarded_gesture != raw_pred:
            scores = dict(scores)
            scores[guarded_gesture] = max(float(scores.get(guarded_gesture, 0.0)), 0.01)

        if strict_critic_v47 and os.environ.get("TLETL_AI_V47_STRICT", "1") != "0":
            critic = strict_critic_v47(
                gesture=guarded_gesture,
                confidence=confidence,
                features=features,
                scores=scores,
                votes=None,
                source="v47-3-live-robust-knn",
                allow_fallback_without_orientation=False,
            )
        else:
            critic = {
                "accepted": True,
                "final_gesture": guarded_gesture,
                "severity": "OK",
                "reason": "strict critic desactivado",
                "orientation": orientation_summary(features),
                "confidence": confidence,
                "margin": float(pred.get("margin", 0.0)),
                "fallback": False,
            }

        final_gesture = str(critic.get("final_gesture") or guarded_gesture)
        accepted = bool(critic.get("accepted"))

        if os.environ.get("TLETL_AI_V47_TEMPORAL", "1") != "0":
            hand_key = str(handedness or "Hand")
            temporal_gesture, temporal_reason = self.temporal.update(hand_key, final_gesture, accepted, confidence)
            if temporal_gesture != final_gesture:
                final_gesture = temporal_gesture
                accepted = final_gesture != "NEUTRAL"
            critic_reason = f"{guard_reason}; {critic.get('reason', '')}; {temporal_reason}"
        else:
            critic_reason = f"{guard_reason}; {critic.get('reason', '')}"

        if not accepted:
            final_gesture = "NEUTRAL"

        legacy_raw = ai_to_legacy_raw(final_gesture, fallback=rule_raw)
        return {
            "enabled": True,
            "bank": str(self.bank_path),
            "gesture": final_gesture,
            "raw_prediction": raw_pred,
            "guarded_prediction": guarded_gesture,
            "legacy_raw": legacy_raw,
            "rule_raw": rule_raw,
            "accepted": accepted,
            "confidence": float(critic.get("confidence", confidence)),
            "margin": float(critic.get("margin", pred.get("margin", 0.0))),
            "orientation": str(critic.get("orientation") or orientation_summary(features)),
            "orientation_label": orientation_label(features),
            "critic_reason": critic_reason,
            "critic_severity": str(critic.get("severity", "OK")),
            "features_used": int(pred.get("used_features", 0)),
            "scores": scores,
            "top": pred.get("top", []),
            "distances": pred.get("distances", {}),
            "runtime": "v4.7.3-robust-knn",
        }

    def info(self) -> Dict[str, Any]:
        info = self.classifier.info()
        info.update({
            "project_extractor": getattr(self.project_extractor, "__name__", None),
            "runtime": "v4.7.3-robust-knn",
            "env": {
                "K": _env_int("TLETL_AI_V47_K", 11),
                "SOFTMAX_TEMP": _env_float("TLETL_AI_V47_SOFTMAX_TEMP", 3.0),
                "ORIENTATION_WEIGHT": _env_float("TLETL_AI_V47_ORIENTATION_WEIGHT", 0.55),
                "RULE_GUARD": os.environ.get("TLETL_AI_V47_RULE_GUARD", "1"),
                "TEMPORAL": os.environ.get("TLETL_AI_V47_TEMPORAL", "1"),
            }
        })
        return info


_RUNTIME: Optional[LiveRuntimeV47] = None
_RUNTIME_ERROR = ""


def get_live_runtime_v47() -> LiveRuntimeV47:
    global _RUNTIME, _RUNTIME_ERROR
    if _RUNTIME is None:
        _RUNTIME = LiveRuntimeV47()
        _RUNTIME_ERROR = ""
    return _RUNTIME


def classify_landmarks_v47(landmarks: Any, handedness: Optional[str] = None, rule_raw: str = "UNKNOWN") -> Dict[str, Any]:
    try:
        return get_live_runtime_v47().classify_landmarks(landmarks, handedness=handedness, rule_raw=rule_raw)
    except Exception as exc:
        global _RUNTIME_ERROR
        _RUNTIME_ERROR = str(exc)
        return {
            "enabled": False,
            "gesture": RULE_TO_AI.get(rule_raw, "NEUTRAL"),
            "raw_prediction": "ERROR",
            "guarded_prediction": "ERROR",
            "legacy_raw": rule_raw,
            "rule_raw": rule_raw,
            "accepted": False,
            "confidence": 0.0,
            "margin": 0.0,
            "orientation": "ORIENTATION:error",
            "orientation_label": "ERROR",
            "critic_reason": f"runtime error: {exc}",
            "critic_severity": "ERROR",
            "features_used": 0,
            "scores": {},
            "top": [],
            "runtime": "v4.7.3-error",
        }
