"""
Tletl V4.7 - crítico estricto.

Este módulo no clasifica desde cero. Revisa lo que dijo la IA/clasificador y decide si
conviene aceptarlo, bajarlo a fallback o bloquearlo por ambiguo.

Idea central:
- El clasificador predice.
- El crítico desconfía.
- La UI muestra el motivo.
Porque claramente hacía falta una IA con problemas de confianza, pero esta vez útil.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, asdict
from typing import Any, Dict, Mapping, Optional

from .hand_orientation import has_orientation_features, orientation_summary


VALID_GESTURES = {"OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"}

MIN_CONF = {
    "OPEN_PALM": 0.70,
    "FIST": 0.68,
    "POINT": 0.69,
    "VICTORY": 0.72,
    "PINCH": 0.72,
    "THREE": 0.72,
    "NEUTRAL": 0.55,
}

# Gestos peligrosos porque disparan acciones. Más estrictos.
ACTION_GESTURES = {"PINCH", "POINT", "VICTORY", "THREE", "FIST"}


@dataclass
class CriticResult:
    accepted: bool
    final_gesture: str
    severity: str
    reason: str
    orientation: str
    confidence: float
    margin: float
    fallback: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _top_two_from_scores(scores: Any) -> tuple[Optional[str], float, Optional[str], float]:
    """
    Acepta:
    - dict label->score/proba
    - lista de tuplas [(label, score), ...]
    - None
    """
    if not scores:
        return None, 0.0, None, 0.0
    if isinstance(scores, Mapping):
        items = list(scores.items())
    else:
        items = list(scores)
    clean = []
    for item in items:
        if not isinstance(item, (list, tuple)) or len(item) < 2:
            continue
        clean.append((str(item[0]), _safe_float(item[1])))
    clean.sort(key=lambda x: x[1], reverse=True)
    if not clean:
        return None, 0.0, None, 0.0
    first = clean[0]
    second = clean[1] if len(clean) > 1 else (None, 0.0)
    return first[0], first[1], second[0], second[1]


def _vote_split(votes: Any) -> tuple[bool, str]:
    """
    Detecta votos divididos entre modelos/reglas.
    votes puede ser lista ["PINCH", "POINT", ...] o dict {"PINCH": 2, "POINT": 1}
    """
    if not votes:
        return False, ""
    if isinstance(votes, Mapping):
        counts = Counter({str(k): int(v) for k, v in votes.items()})
    else:
        counts = Counter(str(v) for v in votes if v)
    if not counts:
        return False, ""
    total = sum(counts.values())
    top_label, top_count = counts.most_common(1)[0]
    second = counts.most_common(2)[1] if len(counts) > 1 else (None, 0)
    if total >= 3 and top_count / max(total, 1) < 0.60:
        return True, f"votos divididos: {dict(counts)}"
    if second[1] > 0 and top_count == second[1]:
        return True, f"empate de votos: {dict(counts)}"
    return False, ""


def strict_critic_v47(
    gesture: str,
    confidence: float,
    features: Optional[Dict[str, Any]] = None,
    scores: Any = None,
    votes: Any = None,
    source: str = "",
    allow_fallback_without_orientation: bool = True,
) -> Dict[str, Any]:
    """
    Devuelve dict para meter directo a UI/runtime.

    Uso esperado:
        critic = strict_critic_v47(label, conf, features, scores=probas, votes=votes)
        final = critic["final_gesture"]
        reason = critic["reason"]
    """
    features = features or {}
    gesture = str(gesture or "UNKNOWN")
    conf = _safe_float(confidence)

    top, top_score, second, second_score = _top_two_from_scores(scores)
    margin = max(0.0, top_score - second_score) if top else 1.0

    orientation_ok = has_orientation_features(features, strict=True)
    orientation = orientation_summary(features)

    if gesture not in VALID_GESTURES:
        return CriticResult(
            accepted=False,
            final_gesture="NEUTRAL",
            severity="BLOCK",
            reason=f"gesto inválido o desconocido: {gesture}",
            orientation=orientation,
            confidence=conf,
            margin=margin,
            fallback=True,
        ).to_dict()

    split, split_reason = _vote_split(votes)
    if split:
        return CriticResult(
            accepted=False,
            final_gesture="NEUTRAL",
            severity="BLOCK",
            reason=split_reason,
            orientation=orientation,
            confidence=conf,
            margin=margin,
            fallback=True,
        ).to_dict()

    min_conf = MIN_CONF.get(gesture, 0.72)
    if conf < min_conf:
        return CriticResult(
            accepted=False,
            final_gesture="NEUTRAL" if gesture in ACTION_GESTURES else gesture,
            severity="BLOCK" if gesture in ACTION_GESTURES else "WARN",
            reason=f"confianza baja para {gesture}: {conf:.2f} < {min_conf:.2f}",
            orientation=orientation,
            confidence=conf,
            margin=margin,
            fallback=gesture in ACTION_GESTURES,
        ).to_dict()

    if top and second and margin < 0.075 and gesture in ACTION_GESTURES:
        return CriticResult(
            accepted=False,
            final_gesture="NEUTRAL",
            severity="BLOCK",
            reason=f"margen bajo entre {top} y {second}: {margin:.3f}",
            orientation=orientation,
            confidence=conf,
            margin=margin,
            fallback=True,
        ).to_dict()

    if not orientation_ok:
        if allow_fallback_without_orientation and conf >= max(0.82, min_conf + 0.08):
            return CriticResult(
                accepted=True,
                final_gesture=gesture,
                severity="WARN",
                reason="sin features de orientación; aceptado solo por confianza alta",
                orientation=orientation,
                confidence=conf,
                margin=margin,
                fallback=True,
            ).to_dict()
        return CriticResult(
            accepted=False,
            final_gesture="NEUTRAL",
            severity="BLOCK",
            reason="faltan features nuevas de orientación",
            orientation=orientation,
            confidence=conf,
            margin=margin,
            fallback=True,
        ).to_dict()

    palm_flat = _safe_float(features.get("palm_flatness_score"))
    side = _safe_float(features.get("side_hand_score"))
    depth_spread = _safe_float(features.get("finger_depth_spread"))

    # Reglas blandas de orientación. No conviertas esto en religión:
    # si bloquea demasiado, se ajusta después con métricas del banco.
    if gesture == "OPEN_PALM":
        if palm_flat < 0.34 and conf < 0.86:
            return CriticResult(
                accepted=False,
                final_gesture="NEUTRAL",
                severity="BLOCK",
                reason=f"OPEN_PALM poco plana: flat={palm_flat:.2f}",
                orientation=orientation,
                confidence=conf,
                margin=margin,
                fallback=True,
            ).to_dict()
        if side > 0.82 and conf < 0.88:
            return CriticResult(
                accepted=False,
                final_gesture="NEUTRAL",
                severity="WARN",
                reason=f"OPEN_PALM muy lateral: side={side:.2f}",
                orientation=orientation,
                confidence=conf,
                margin=margin,
                fallback=True,
            ).to_dict()

    if gesture in {"VICTORY", "THREE", "POINT"}:
        if depth_spread > 0.78 and conf < 0.84:
            return CriticResult(
                accepted=False,
                final_gesture="NEUTRAL",
                severity="WARN",
                reason=f"{gesture} con demasiada diferencia de profundidad en dedos: {depth_spread:.2f}",
                orientation=orientation,
                confidence=conf,
                margin=margin,
                fallback=True,
            ).to_dict()

    if gesture == "PINCH":
        # Pinch sí puede verse de lado, así que no castigues side_hand como cavernícola.
        if palm_flat < 0.12 and conf < 0.84:
            return CriticResult(
                accepted=False,
                final_gesture="NEUTRAL",
                severity="BLOCK",
                reason=f"PINCH inestable por palma casi no plana: flat={palm_flat:.2f}",
                orientation=orientation,
                confidence=conf,
                margin=margin,
                fallback=True,
            ).to_dict()

    return CriticResult(
        accepted=True,
        final_gesture=gesture,
        severity="OK",
        reason=f"aceptado: {gesture} conf={conf:.2f}",
        orientation=orientation,
        confidence=conf,
        margin=margin,
        fallback=False,
    ).to_dict()


# Alias cómodo por si tu ai_critic.py viejo ya usaba nombre genérico.
critic_decision_v47 = strict_critic_v47
