from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .filters import AdaptiveLandmarkSmoother, CursorController, MotionTracker, StableGestureFilter
from .geometry import Point


@dataclass
class DetectedHand:
    label: str
    raw_landmarks: Any
    points: List[Point]
    features: Dict[str, float]
    raw_gesture: str
    stable_gesture: str
    action_gesture: str
    confidence: float
    source: str
    fingers: Dict[str, bool]
    center_x: float
    center_y: float
    scale: float
    speed: float
    alpha: float
    swipe: Optional[str]


class HandState:
    def __init__(self, args):
        self.smoother = AdaptiveLandmarkSmoother(args.slow_alpha, args.fast_alpha, args.fast_threshold)
        self.stable = StableGestureFilter(args.history, args.stable_count)
        self.motion = MotionTracker(maxlen=args.motion_history)
        self.cursor = CursorController(args.cursor_gain, args.cursor_max_step, args.cursor_deadzone)
        self.last_seen = 0.0

    def reset(self):
        self.smoother.reset()
        self.stable.clear()
        self.motion.reset()
        self.cursor.reset()
