import math
import time
from collections import Counter, deque
from typing import List, Optional, Tuple

from .constants import SWIPE_COOLDOWN, TWO_HAND_DISTANCE_DELTA, TWO_HAND_DISTANCE_MIN_DT, BIG_ACTION_COOLDOWN
from .geometry import Point, clamp, palm_center


class AdaptiveLandmarkSmoother:
    def __init__(self, slow_alpha: float, fast_alpha: float, threshold: float):
        self.slow_alpha = slow_alpha
        self.fast_alpha = fast_alpha
        self.threshold = threshold
        self.values: Optional[List[List[float]]] = None
        self.prev_center: Optional[Tuple[float, float, float]] = None
        self.last_speed = 0.0
        self.last_alpha = slow_alpha

    def reset(self):
        self.values = None
        self.prev_center = None
        self.last_speed = 0.0
        self.last_alpha = self.slow_alpha

    def update(self, raw_points: List[Point]) -> List[Point]:
        now = time.time()
        cx, cy = palm_center(raw_points)

        if self.prev_center is None:
            speed = 0.0
        else:
            px, py, pt = self.prev_center
            dt = max(now - pt, 0.001)
            speed = math.sqrt((cx - px) ** 2 + (cy - py) ** 2) / dt

        self.prev_center = (cx, cy, now)
        self.last_speed = speed

        t = clamp((speed - self.threshold) / max(self.threshold * 3.0, 0.001), 0.0, 1.0)
        alpha = self.slow_alpha * (1.0 - t) + self.fast_alpha * t
        self.last_alpha = alpha

        if self.values is None:
            self.values = [[p.x, p.y, p.z] for p in raw_points]
        else:
            for i, p in enumerate(raw_points):
                self.values[i][0] = alpha * p.x + (1.0 - alpha) * self.values[i][0]
                self.values[i][1] = alpha * p.y + (1.0 - alpha) * self.values[i][1]
                self.values[i][2] = alpha * p.z + (1.0 - alpha) * self.values[i][2]

        return [Point(x, y, z) for x, y, z in self.values]


class StableGestureFilter:
    def __init__(self, size: int, min_count: int):
        self.history = deque(maxlen=size)
        self.min_count = min_count

    def clear(self):
        self.history.clear()

    def update(self, gesture: str) -> str:
        self.history.append(gesture)
        if len(self.history) < self.history.maxlen:
            return "WAITING"
        gesture, amount = Counter(self.history).most_common(1)[0]
        if gesture == "UNKNOWN":
            return "UNKNOWN"
        return gesture if amount >= self.min_count else "UNSTABLE"


class MotionTracker:
    def __init__(self, maxlen: int = 9):
        self.points = deque(maxlen=maxlen)
        self.last_swipe_time = 0.0
        self.last_velocity = 0.0

    def reset(self):
        self.points.clear()
        self.last_velocity = 0.0

    def update(self, x: float, y: float):
        now = time.time()
        if self.points:
            t0, x0, y0 = self.points[-1]
            dt = max(now - t0, 0.001)
            self.last_velocity = math.sqrt((x - x0) ** 2 + (y - y0) ** 2) / dt
        self.points.append((now, x, y))

    def swipe(self) -> Optional[str]:
        if len(self.points) < 4:
            return None
        now = time.time()
        if now - self.last_swipe_time < SWIPE_COOLDOWN:
            return None
        t0, x0, y0 = self.points[0]
        t1, x1, y1 = self.points[-1]
        dt = max(t1 - t0, 0.001)
        dx = x1 - x0
        dy = y1 - y0
        fast = dt <= 0.55
        horiz_threshold = 0.115 if fast else 0.155
        vert_threshold = 0.115 if fast else 0.155

        if dt <= 0.90 and abs(dx) > horiz_threshold and abs(dx) > abs(dy) * 1.45:
            self.last_swipe_time = now
            self.points.clear()
            return "RIGHT" if dx > 0 else "LEFT"

        if dt <= 0.90 and abs(dy) > vert_threshold and abs(dy) > abs(dx) * 1.45:
            self.last_swipe_time = now
            self.points.clear()
            return "DOWN" if dy > 0 else "UP"
        return None


class CursorController:
    def __init__(self, gain: int, max_step: int, deadzone: float):
        self.prev: Optional[Tuple[float, float]] = None
        self.gain = gain
        self.max_step = max_step
        self.deadzone = deadzone

    def reset(self):
        self.prev = None

    def update(self, x: float, y: float, velocity: float = 0.0) -> Tuple[int, int]:
        if self.prev is None:
            self.prev = (x, y)
            return 0, 0
        px, py = self.prev
        self.prev = (x, y)

        dx_norm = x - px
        dy_norm = y - py
        if abs(dx_norm) < self.deadzone:
            dx_norm = 0.0
        if abs(dy_norm) < self.deadzone:
            dy_norm = 0.0

        accel = clamp(1.0 + velocity * 2.1, 1.0, 2.15)
        dx = int(clamp(dx_norm * self.gain * accel, -self.max_step, self.max_step))
        dy = int(clamp(dy_norm * self.gain * accel, -self.max_step, self.max_step))
        return dx, dy


class HoldTimer:
    def __init__(self):
        self.gesture: Optional[str] = None
        self.started_at = 0.0

    def reset(self):
        self.gesture = None
        self.started_at = 0.0

    def progress(self, gesture: str, seconds: float) -> float:
        now = time.time()
        if self.gesture != gesture:
            self.gesture = gesture
            self.started_at = now
        return clamp((now - self.started_at) / max(seconds, 0.001), 0.0, 1.0)


class TwoHandDistanceTracker:
    def __init__(self):
        self.history = deque(maxlen=10)
        self.last_action_time = 0.0

    def reset(self):
        self.history.clear()

    def update(self, left_center: Tuple[float, float], right_center: Tuple[float, float]):
        x1, y1 = left_center
        x2, y2 = right_center
        d = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        self.history.append((time.time(), d))

    def spread_or_pinch(self) -> Optional[str]:
        if len(self.history) < 5:
            return None
        now = time.time()
        if now - self.last_action_time < BIG_ACTION_COOLDOWN:
            return None
        t0, d0 = self.history[0]
        t1, d1 = self.history[-1]
        dt = max(t1 - t0, 0.001)
        if dt < TWO_HAND_DISTANCE_MIN_DT or dt > 1.15:
            return None
        delta = d1 - d0
        if abs(delta) < TWO_HAND_DISTANCE_DELTA:
            return None
        self.last_action_time = now
        self.history.clear()
        return "SPREAD" if delta > 0 else "PINCH_IN"
