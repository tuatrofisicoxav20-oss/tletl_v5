import cv2
import numpy as np


class LowLightEnhancer:
    """Preprocesado suave para baja luz.

    No hace milagros, solo mejora contraste/brillo antes de pasar el frame a MediaPipe.
    """

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        self.last_luma = 0.0
        self.last_mode = "normal"

    def enhance(self, frame: np.ndarray) -> np.ndarray:
        if not self.enabled:
            self.last_mode = "off"
            return frame

        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        y, cr, cb = cv2.split(ycrcb)
        mean_luma = float(np.mean(y))
        self.last_luma = mean_luma

        if mean_luma >= 112:
            self.last_mode = "normal"
            return frame

        y2 = self.clahe.apply(y)

        if mean_luma < 62:
            gamma = 0.62
            self.last_mode = "fuerte"
        elif mean_luma < 88:
            gamma = 0.76
            self.last_mode = "media"
        else:
            gamma = 0.88
            self.last_mode = "suave"

        inv_gamma = 1.0 / gamma
        table = np.array([(i / 255.0) ** inv_gamma * 255 for i in range(256)]).astype("uint8")
        y3 = cv2.LUT(y2, table)
        merged = cv2.merge([y3, cr, cb])
        return cv2.cvtColor(merged, cv2.COLOR_YCrCb2BGR)
