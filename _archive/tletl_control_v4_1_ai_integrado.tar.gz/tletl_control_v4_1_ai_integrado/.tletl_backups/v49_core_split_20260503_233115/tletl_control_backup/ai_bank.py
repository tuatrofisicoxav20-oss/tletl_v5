\
import json
import time
from pathlib import Path
from typing import Any, Dict, List


GESTURES = ["OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"]

KEY_TO_GESTURE = {
    ord("1"): "OPEN_PALM",
    ord("2"): "FIST",
    ord("3"): "POINT",
    ord("4"): "VICTORY",
    ord("5"): "PINCH",
    ord("6"): "THREE",
    ord("7"): "NEUTRAL",
}


def append_sample(path: Path, label: str, features: Dict[str, float], meta: Dict[str, Any] | None = None):
    path = Path(path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    row = {
        "label": label,
        "features": features,
        "meta": meta or {},
        "timestamp": time.time(),
    }
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_samples(path: Path) -> List[Dict[str, Any]]:
    path = Path(path).expanduser().resolve()
    if not path.exists():
        return []

    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
                if row.get("label") in GESTURES and isinstance(row.get("features"), dict):
                    rows.append(row)
            except json.JSONDecodeError:
                continue
    return rows


def count_by_label(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    counts = {g: 0 for g in GESTURES}
    for row in rows:
        label = row.get("label")
        if label in counts:
            counts[label] += 1
    return counts


def short_counts(rows: List[Dict[str, Any]]) -> str:
    counts = count_by_label(rows)
    parts = [f"{g}:{counts[g]}" for g in GESTURES if counts[g]]
    return " ".join(parts) if parts else "0"


def dataset_ready(rows: List[Dict[str, Any]], min_per_core: int = 12) -> bool:
    counts = count_by_label(rows)
    core = ["OPEN_PALM", "FIST", "POINT", "PINCH", "NEUTRAL"]
    return all(counts.get(g, 0) >= min_per_core for g in core)
