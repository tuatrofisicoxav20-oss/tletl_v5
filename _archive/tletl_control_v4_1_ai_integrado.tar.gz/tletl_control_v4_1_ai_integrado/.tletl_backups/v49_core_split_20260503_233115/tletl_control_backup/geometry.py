import math
from typing import Any, List, Tuple


class Point:
    __slots__ = ("x", "y", "z")

    def __init__(self, x: float, y: float, z: float):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def dist(a: Point, b: Point) -> float:
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)


def points_from_landmarks(hand_landmarks: Any) -> List[Point]:
    return [Point(p.x, p.y, p.z) for p in hand_landmarks.landmark]


def palm_scale(lm: List[Point]) -> float:
    wrist_to_middle = dist(lm[0], lm[9])
    palm_width = dist(lm[5], lm[17])
    return max((wrist_to_middle + palm_width) / 2.0, 0.0001)


def palm_center_x(lm: List[Point]) -> float:
    ids = [0, 5, 9, 13, 17]
    return sum(lm[i].x for i in ids) / len(ids)


def palm_center_y(lm: List[Point]) -> float:
    ids = [0, 5, 9, 13, 17]
    return sum(lm[i].y for i in ids) / len(ids)


def palm_center(lm: List[Point]) -> Tuple[float, float]:
    return palm_center_x(lm), palm_center_y(lm)
