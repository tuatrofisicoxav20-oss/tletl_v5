\
import math
from collections import Counter, defaultdict, deque
from typing import Any, Dict, List, Tuple

from .features import classifier_keys


class OnlineNormalizer:
    def __init__(self):
        self.keys: List[str] = []
        self.mean: Dict[str, float] = {}
        self.std: Dict[str, float] = {}

    def fit(self, rows: List[Dict[str, Any]]):
        if not rows:
            self.keys = []
            return

        self.keys = classifier_keys(rows[0]["features"])
        values = {k: [] for k in self.keys}

        for row in rows:
            features = row.get("features", {})
            for key in self.keys:
                value = features.get(key)
                if isinstance(value, (int, float)) and math.isfinite(float(value)):
                    values[key].append(float(value))

        for key, vals in values.items():
            if not vals:
                self.mean[key] = 0.0
                self.std[key] = 1.0
                continue
            m = sum(vals) / len(vals)
            var = sum((v - m) ** 2 for v in vals) / max(len(vals) - 1, 1)
            self.mean[key] = m
            self.std[key] = max(math.sqrt(var), 0.045)

    def transform(self, features: Dict[str, float]) -> List[float]:
        vec: List[float] = []
        for key in self.keys:
            value = float(features.get(key, self.mean.get(key, 0.0)))
            vec.append((value - self.mean.get(key, 0.0)) / self.std.get(key, 1.0))
        return vec


def euclidean(a: List[float], b: List[float]) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)) / max(len(a), 1))


class KNNGestureClassifier:
    """IA ligera basada en ejemplos.

    No necesita GPU. Aprende agregando filas al banco de gestos.
    """

    def __init__(self, k: int = 7, max_rows_per_label: int = 420):
        self.k = int(k)
        self.max_rows_per_label = int(max_rows_per_label)
        self.normalizer = OnlineNormalizer()
        self.rows: List[Dict[str, Any]] = []
        self.vectors: List[Tuple[str, List[float]]] = []

    def fit(self, rows: List[Dict[str, Any]]):
        buckets: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for row in rows:
            buckets[row["label"]].append(row)

        balanced: List[Dict[str, Any]] = []
        for label, items in buckets.items():
            balanced.extend(items[-self.max_rows_per_label:])

        self.rows = balanced
        self.normalizer.fit(self.rows)
        self.vectors = [(row["label"], self.normalizer.transform(row["features"])) for row in self.rows]

    def ready(self) -> bool:
        labels = {label for label, _ in self.vectors}
        return len(self.vectors) >= 20 and len(labels) >= 2

    def predict(self, features: Dict[str, float]) -> Tuple[str, float, Dict[str, Any]]:
        if not self.ready():
            return "UNKNOWN", 0.0, {"reason": "dataset insuficiente"}

        x = self.normalizer.transform(features)
        distances = [(label, euclidean(x, vec)) for label, vec in self.vectors]
        distances.sort(key=lambda item: item[1])

        nearest = distances[:max(self.k, 1)]
        votes = Counter(label for label, _ in nearest)

        best_label, best_votes = votes.most_common(1)[0]
        second_votes = votes.most_common(2)[1][1] if len(votes) > 1 else 0

        avg_best_distance = sum(d for label, d in nearest if label == best_label) / max(best_votes, 1)

        vote_conf = best_votes / max(len(nearest), 1)
        margin_conf = (best_votes - second_votes) / max(len(nearest), 1)
        distance_conf = 1.0 / (1.0 + avg_best_distance)

        confidence = max(0.0, min(1.0, 0.56 * vote_conf + 0.24 * margin_conf + 0.20 * distance_conf))

        if confidence < 0.45:
            return "UNKNOWN", confidence, {
                "votes": dict(votes),
                "avg_distance": avg_best_distance,
                "nearest": nearest,
            }

        return best_label, confidence, {
            "votes": dict(votes),
            "avg_distance": avg_best_distance,
            "nearest": nearest,
        }


class PredictionSmoother:
    def __init__(self, size: int = 6, min_count: int = 3):
        self.buffer = deque(maxlen=size)
        self.min_count = min_count
        self.last = "UNKNOWN"

    def clear(self):
        self.buffer.clear()
        self.last = "UNKNOWN"

    def update(self, label: str) -> str:
        self.buffer.append(label)
        if len(self.buffer) < self.buffer.maxlen:
            return "WAITING"
        label, count = Counter(self.buffer).most_common(1)[0]
        if count >= self.min_count and label != "UNKNOWN":
            self.last = label
            return label
        return self.last
