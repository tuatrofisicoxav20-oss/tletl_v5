from typing import Dict, List, Optional, Tuple, Any

from .geometry import Point, dist, palm_scale, clamp
from .profile import classify_with_profile


def finger_extended_rule(lm: List[Point], tip: int, pip: int, mcp: int) -> bool:
    scale = palm_scale(lm)
    wrist = lm[0]
    vertical = (lm[pip].y - lm[tip].y) > 0.010
    length = (dist(lm[tip], wrist) - dist(lm[pip], wrist)) > (0.036 * scale)
    tip_far = dist(lm[tip], lm[mcp]) > (0.385 * scale)
    return (vertical and length) or (vertical and tip_far)


def thumb_open_rule(lm: List[Point]) -> bool:
    scale = palm_scale(lm)
    return dist(lm[4], lm[5]) > 0.42 * scale and dist(lm[4], lm[8]) > 0.27 * scale


def pinch_rule(lm: List[Point]) -> Tuple[bool, float]:
    scale = palm_scale(lm)

    thumb_index = dist(lm[4], lm[8]) / scale
    thumb_middle = dist(lm[4], lm[12]) / scale
    thumb_ring = dist(lm[4], lm[16]) / scale

    # Distancias para diferenciar pinza real vs puño.
    index_tip_mcp = dist(lm[8], lm[5]) / scale
    index_tip_palm = dist(lm[8], lm[9]) / scale
    middle_tip_palm = dist(lm[12], lm[9]) / scale
    ring_tip_palm = dist(lm[16], lm[9]) / scale
    pinky_tip_palm = dist(lm[20], lm[9]) / scale

    close = thumb_index < 0.46
    tight = thumb_index < 0.34

    # En pinza real, el índice debe ser el dedo más cercano al pulgar.
    index_closest = thumb_index < min(thumb_middle * 0.86, thumb_ring * 0.82)

    # En puño, las puntas de los dedos están todas cerca de la palma.
    fist_like = (
        index_tip_palm < 0.48 and
        middle_tip_palm < 0.48 and
        ring_tip_palm < 0.50 and
        pinky_tip_palm < 0.54
    )

    # En pinza real el índice no debería estar completamente metido hacia la palma.
    index_has_shape = index_tip_mcp > 0.34 and index_tip_palm > 0.38

    ok = (tight or (close and index_closest)) and index_has_shape and not fist_like
    conf = clamp(1.10 - thumb_index, 0.0, 0.96)

    if fist_like:
        conf *= 0.45

    return ok, conf



def rule_fingers(lm: List[Point]) -> Dict[str, bool]:
    return {
        "thumb": thumb_open_rule(lm),
        "index": finger_extended_rule(lm, 8, 6, 5),
        "middle": finger_extended_rule(lm, 12, 10, 9),
        "ring": finger_extended_rule(lm, 16, 14, 13),
        "pinky": finger_extended_rule(lm, 20, 18, 17),
    }


def classify_by_rules(lm: List[Point]) -> Tuple[str, float, Dict[str, bool]]:
    f = rule_fingers(lm)
    long_count = sum([f["index"], f["middle"], f["ring"], f["pinky"]])
    total = long_count + int(f["thumb"])

    scale = palm_scale(lm)

    index_tip_palm = dist(lm[8], lm[9]) / scale
    middle_tip_palm = dist(lm[12], lm[9]) / scale
    ring_tip_palm = dist(lm[16], lm[9]) / scale
    pinky_tip_palm = dist(lm[20], lm[9]) / scale

    thumb_index = dist(lm[4], lm[8]) / scale
    thumb_middle = dist(lm[4], lm[12]) / scale

    # FIST FUERTE:
    # Si los dedos largos están cerrados y las puntas están cerca de la palma,
    # debe ganar FIST antes que PINCH.
    fist_like = (
        not f["index"] and
        not f["middle"] and
        not f["ring"] and
        not f["pinky"] and
        index_tip_palm < 0.58 and
        middle_tip_palm < 0.58 and
        ring_tip_palm < 0.60 and
        pinky_tip_palm < 0.64
    )

    if fist_like:
        return "FIST", 0.92, f

    # THREE debe ganar antes que PINCH accidental.
    if f["index"] and f["middle"] and f["ring"] and not f["pinky"]:
        return "THREE", 0.86, f

    # VICTORY también se protege.
    if f["index"] and f["middle"] and not f["ring"] and not f["pinky"]:
        return "VICTORY", 0.80, f

    pinch_ok, pinch_conf = pinch_rule(lm)

    # Pinza real: pulgar e índice cerca, pero NO con todos los dedos cerrados.
    pinch_blocked_by_closed_hand = (
        middle_tip_palm < 0.62 and
        ring_tip_palm < 0.64 and
        pinky_tip_palm < 0.68
    )

    # Si el pulgar también está cerca del medio, puede ser puño, no pinza limpia.
    pinch_not_clean = thumb_middle < 0.55 and thumb_index > 0.28

    if (
        pinch_ok
        and pinch_conf >= 0.66
        and not pinch_blocked_by_closed_hand
        and not pinch_not_clean
    ):
        return "PINCH", max(0.68, pinch_conf), f

    if long_count >= 4:
        return "OPEN_PALM", 0.80, f

    if long_count == 0:
        return "FIST", 0.84, f

    if f["index"] and not f["middle"] and not f["ring"] and not f["pinky"]:
        return "POINT", 0.78, f

    if total <= 2:
        return "NEUTRAL", 0.58, f

    return "UNKNOWN", 0.0, f



def classify_hybrid(points: List[Point], features: Dict[str, float], profile: Optional[Dict[str, Any]]) -> Tuple[str, float, str, Dict[str, bool]]:
    rule_gesture, rule_conf, fingers = classify_by_rules(points)
    if profile is None:
        return rule_gesture, rule_conf, "regla", fingers

    profile_gesture, profile_conf = classify_with_profile(features, profile)

    if rule_gesture in {"PINCH", "FIST"} and rule_conf >= 0.62:
        return rule_gesture, rule_conf, "regla-rapida", fingers

    if profile_gesture == rule_gesture and profile_gesture != "UNKNOWN":
        return profile_gesture, min(1.0, max(profile_conf, rule_conf) + 0.13), "perfil+regla", fingers

    if rule_gesture in {"OPEN_PALM", "POINT", "VICTORY", "THREE"} and rule_conf >= 0.72:
        return rule_gesture, rule_conf, "regla", fingers

    if profile_gesture != "UNKNOWN" and profile_conf >= 0.31:
        return profile_gesture, profile_conf, "perfil", fingers

    return rule_gesture, rule_conf, "regla", fingers
