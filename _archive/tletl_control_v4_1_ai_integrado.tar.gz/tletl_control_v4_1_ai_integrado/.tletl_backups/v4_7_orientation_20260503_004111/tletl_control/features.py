from typing import Dict, List

from .geometry import Point, dist, palm_scale, palm_center_x, palm_center_y


FINGERS = {
    "index": (8, 6, 5),
    "middle": (12, 10, 9),
    "ring": (16, 14, 13),
    "pinky": (20, 18, 17),
}


def extract_features(lm: List[Point]) -> Dict[str, float]:
    scale = palm_scale(lm)
    wrist = lm[0]
    features: Dict[str, float] = {}

    for name, (tip, pip, mcp) in FINGERS.items():
        features[f"{name}_tip_wrist"] = dist(lm[tip], wrist) / scale
        features[f"{name}_pip_wrist"] = dist(lm[pip], wrist) / scale
        features[f"{name}_mcp_wrist"] = dist(lm[mcp], wrist) / scale
        features[f"{name}_tip_mcp"] = dist(lm[tip], lm[mcp]) / scale
        features[f"{name}_tip_pip"] = dist(lm[tip], lm[pip]) / scale
        features[f"{name}_vertical"] = (lm[pip].y - lm[tip].y) / scale
        features[f"{name}_curl"] = (dist(lm[tip], wrist) - dist(lm[pip], wrist)) / scale

    features["thumb_tip_wrist"] = dist(lm[4], wrist) / scale
    features["thumb_ip_wrist"] = dist(lm[3], wrist) / scale
    features["thumb_tip_index_mcp"] = dist(lm[4], lm[5]) / scale
    features["thumb_tip_index_tip"] = dist(lm[4], lm[8]) / scale
    features["thumb_tip_middle_tip"] = dist(lm[4], lm[12]) / scale
    features["thumb_horizontal"] = abs(lm[4].x - lm[3].x) / scale
    features["thumb_vertical"] = abs(lm[4].y - lm[3].y) / scale

    features["index_middle_spread"] = dist(lm[8], lm[12]) / scale
    features["middle_ring_spread"] = dist(lm[12], lm[16]) / scale
    features["ring_pinky_spread"] = dist(lm[16], lm[20]) / scale
    features["index_pinky_spread"] = dist(lm[8], lm[20]) / scale
    features["palm_width"] = dist(lm[5], lm[17]) / scale
    features["wrist_middle_mcp"] = dist(lm[0], lm[9]) / scale
    features["palm_center_x"] = palm_center_x(lm)
    features["palm_center_y"] = palm_center_y(lm)

    # V4.3.2: features extra para diferenciar gestos difíciles.
    if len(lm) >= 21:
        features["index_tip_palm"] = dist(lm[8], lm[9]) / scale
        features["middle_tip_palm"] = dist(lm[12], lm[9]) / scale
        features["ring_tip_palm"] = dist(lm[16], lm[9]) / scale
        features["pinky_tip_palm"] = dist(lm[20], lm[9]) / scale

        features["pinch_thumb_index"] = dist(lm[4], lm[8]) / scale
        features["pinch_thumb_middle"] = dist(lm[4], lm[12]) / scale
        features["pinch_thumb_ring"] = dist(lm[4], lm[16]) / scale
        features["pinch_index_to_mcp"] = dist(lm[8], lm[5]) / scale

        features["closed_fingers_mean"] = (
            features["index_tip_palm"] +
            features["middle_tip_palm"] +
            features["ring_tip_palm"] +
            features["pinky_tip_palm"]
        ) / 4.0

        features["pinch_cleanliness"] = features["pinch_thumb_index"] / max(min(
            features["pinch_thumb_middle"],
            features["pinch_thumb_ring"]
        ), 0.001)

        features["index_middle_length_gap"] = features.get("index_tip_mcp", 0.0) - features.get("middle_tip_mcp", 0.0)
        features["ring_pinky_length_gap"] = features.get("ring_tip_mcp", 0.0) - features.get("pinky_tip_mcp", 0.0)
        features["fist_compact_score"] = 1.0 / max(features["closed_fingers_mean"], 0.001)

    return features


def classifier_keys(sample: Dict[str, float]) -> List[str]:
    """
    Devuelve las features que sí debe usar la IA.
    Excluye posición absoluta para que el gesto funcione arriba, abajo,
    izquierda o derecha sin confundirse.
    """
    excluded = {"palm_center_x", "palm_center_y"}
    return sorted(k for k in sample.keys() if k not in excluded)
