"""
Tletl V4.7.2 - runtime AI vivo para interfaz.

Carga el banco JSONL con features V4.7, clasifica landmarks en vivo, pasa por crítico
estricto y devuelve un gesto seguro para acciones. No necesita scikit-learn, no instala
nada, no toca Blender. Porque pedirle a Fedora que coopere ya es suficiente deporte.
"""

from __future__ import annotations

import inspect
import json
import math
import os
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

import numpy as np

from .hand_orientation import ORIENTATION_FEATURE_KEYS, extract_orientation_features, orientation_label, orientation_summary

try:
    from .ai_critic_v47 import strict_critic_v47
except Exception:  # pragma: no cover
    strict_critic_v47 = None


VALID_GESTURES = {"OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"}

LABEL_KEYS = (
    "label", "gesture", "target", "class", "class_name", "y", "name", "expected", "manual_label",
)

META_NUMERIC_KEYS = {
    "timestamp", "time", "created_at", "updated_at", "frame", "frame_id", "sample", "sample_id",
    "camera", "camera_id", "width", "height", "fps", "score", "confidence", "accepted",
    "orientation_complete", "bad_line", "line", "idx", "index", "count",
}

AI_TO_LEGACY = {
    "OPEN_PALM": "OPEN_HAND",
    "FIST": "FIST",
    "POINT": "POINT",
    "VICTORY": "TWO_FINGERS",
    "PINCH": "PINCH",
    "THREE": "THREE_FINGERS",
    "NEUTRAL": "UNKNOWN",
}

RULE_TO_AI = {
    "OPEN_HAND": "OPEN_PALM",
    "FIST": "FIST",
    "POINT": "POINT",
    "TWO_FINGERS": "VICTORY",
    "THREE_FINGERS": "THREE",
    "PINCH": "PINCH",
    "UNKNOWN": "NEUTRAL",
    "NO_HAND": "NEUTRAL",
    "CALIBRANDO": "NEUTRAL",
}


def ai_to_legacy_raw(gesture: str, fallback: str = "UNKNOWN") -> str:
    neutral_raw = os.environ.get("TLETL_AI_V47_NEUTRAL_RAW", "UNKNOWN").strip() or "UNKNOWN"
    mapping = dict(AI_TO_LEGACY)
    mapping["NEUTRAL"] = neutral_raw
    return mapping.get(str(gesture or ""), fallback or "UNKNOWN")


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        v = float(value)
        if math.isfinite(v):
            return v
    except Exception:
        pass
    return default


def _as_xyz(point: Any) -> Tuple[float, float, float]:
    if hasattr(point, "x") and hasattr(point, "y"):
        return float(point.x), float(point.y), float(getattr(point, "z", 0.0))
    if isinstance(point, Mapping):
        return float(point.get("x", 0.0)), float(point.get("y", 0.0)), float(point.get("z", 0.0))
    if isinstance(point, (list, tuple)):
        return (
            float(point[0]) if len(point) > 0 else 0.0,
            float(point[1]) if len(point) > 1 else 0.0,
            float(point[2]) if len(point) > 2 else 0.0,
        )
    return 0.0, 0.0, 0.0


def _landmarks_array(landmarks: Any) -> np.ndarray:
    if hasattr(landmarks, "landmark"):
        landmarks = landmarks.landmark
    arr = np.asarray([_as_xyz(p) for p in landmarks], dtype=float)
    if arr.shape[0] < 21:
        raise ValueError(f"landmarks insuficientes: {arr.shape}")
    return arr[:21, :3]


def _dist(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b))


def _palm_scale(lm: np.ndarray) -> float:
    return max((_dist(lm[0], lm[9]) + _dist(lm[5], lm[17])) / 2.0, 1e-6)


def _fallback_geometric_features(landmarks: Any) -> Dict[str, float]:
    """Extractor local compatible con los nombres que suele usar Tletl."""
    lm = _landmarks_array(landmarks)
    scale = _palm_scale(lm)
    wrist = lm[0]
    features: Dict[str, float] = {}

    fingers = {
        "index": (8, 6, 5),
        "middle": (12, 10, 9),
        "ring": (16, 14, 13),
        "pinky": (20, 18, 17),
    }
    for name, (tip, pip, mcp) in fingers.items():
        features[f"{name}_tip_wrist"] = _dist(lm[tip], wrist) / scale
        features[f"{name}_pip_wrist"] = _dist(lm[pip], wrist) / scale
        features[f"{name}_mcp_wrist"] = _dist(lm[mcp], wrist) / scale
        features[f"{name}_tip_mcp"] = _dist(lm[tip], lm[mcp]) / scale
        features[f"{name}_tip_pip"] = _dist(lm[tip], lm[pip]) / scale
        features[f"{name}_vertical"] = (lm[pip, 1] - lm[tip, 1]) / scale
        features[f"{name}_curl"] = (_dist(lm[tip], wrist) - _dist(lm[pip], wrist)) / scale

    features["thumb_tip_wrist"] = _dist(lm[4], wrist) / scale
    features["thumb_ip_wrist"] = _dist(lm[3], wrist) / scale
    features["thumb_tip_index_mcp"] = _dist(lm[4], lm[5]) / scale
    features["thumb_tip_index_tip"] = _dist(lm[4], lm[8]) / scale
    features["thumb_tip_middle_tip"] = _dist(lm[4], lm[12]) / scale
    features["thumb_horizontal"] = abs(lm[4, 0] - lm[3, 0]) / scale
    features["thumb_vertical"] = abs(lm[4, 1] - lm[3, 1]) / scale

    features["index_middle_spread"] = _dist(lm[8], lm[12]) / scale
    features["middle_ring_spread"] = _dist(lm[12], lm[16]) / scale
    features["ring_pinky_spread"] = _dist(lm[16], lm[20]) / scale
    features["index_pinky_spread"] = _dist(lm[8], lm[20]) / scale
    features["palm_width"] = _dist(lm[5], lm[17]) / scale
    features["wrist_middle_mcp"] = _dist(lm[0], lm[9]) / scale
    features["palm_center_x"] = float(np.mean([lm[i, 0] for i in [0, 5, 9, 13, 17]]))
    features["palm_center_y"] = float(np.mean([lm[i, 1] for i in [0, 5, 9, 13, 17]]))
    return {k: round(float(v), 6) for k, v in features.items() if math.isfinite(float(v))}


def _discover_project_extractor():
    try:
        from . import features as feature_module
    except Exception:
        return None

    preferred = [
        "extract_features", "extract_hand_features", "build_features", "make_features",
        "features_from_landmarks", "get_features",
    ]
    for name in preferred:
        fn = getattr(feature_module, name, None)
        if callable(fn):
            return fn

    for name in dir(feature_module):
        low = name.lower()
        if "feature" not in low:
            continue
        fn = getattr(feature_module, name, None)
        if callable(fn):
            return fn
    return None


def _call_extractor(fn, landmarks: Any, handedness: Optional[str]) -> Optional[Dict[str, float]]:
    if fn is None:
        return None
    attempts = [
        ((landmarks,), {"handedness": handedness}),
        ((landmarks, handedness), {}),
        ((landmarks,), {}),
    ]
    for args, kwargs in attempts:
        try:
            value = fn(*args, **kwargs)
            if isinstance(value, tuple):
                for item in value:
                    if isinstance(item, dict):
                        value = item
                        break
            if isinstance(value, dict):
                clean = {}
                for k, v in value.items():
                    if isinstance(v, (int, float)) and math.isfinite(float(v)):
                        clean[str(k)] = round(float(v), 6)
                if clean:
                    return clean
        except TypeError:
            continue
        except Exception:
            continue
    return None


def _extract_label(sample: Mapping[str, Any]) -> Optional[str]:
    for key in LABEL_KEYS:
        value = sample.get(key)
        if isinstance(value, str):
            label = value.strip().upper()
            if label in VALID_GESTURES:
                return label
            mapped = RULE_TO_AI.get(label)
            if mapped in VALID_GESTURES:
                return mapped
    meta = sample.get("meta")
    if isinstance(meta, Mapping):
        return _extract_label(meta)
    return None


def _flatten_features(sample: Mapping[str, Any]) -> Dict[str, float]:
    out: Dict[str, float] = {}

    nested = sample.get("features")
    if isinstance(nested, Mapping):
        for k, v in nested.items():
            if isinstance(v, (int, float)) and math.isfinite(float(v)):
                out[str(k)] = float(v)

    for k, v in sample.items():
        key = str(k)
        if key in LABEL_KEYS or key in META_NUMERIC_KEYS:
            continue
        if key in {"features", "landmarks", "hand_landmarks", "meta", "orientation", "scores", "votes"}:
            continue
        if isinstance(v, (int, float)) and math.isfinite(float(v)):
            out[key] = float(v)

    return out


def _softmax_scores(distances: Mapping[str, float], temperature: float) -> Dict[str, float]:
    if not distances:
        return {}
    vals = {g: math.exp(-max(0.0, d) * temperature) for g, d in distances.items()}
    total = sum(vals.values()) or 1.0
    return {g: v / total for g, v in vals.items()}


class CentroidBankClassifier:
    def __init__(self, bank_path: Path):
        self.bank_path = bank_path
        self.samples_by_label: Dict[str, List[Dict[str, float]]] = defaultdict(list)
        self.feature_keys: List[str] = []
        self.stats: Dict[str, Dict[str, Dict[str, float]]] = {}
        self.global_std: Dict[str, float] = {}
        self.loaded_at = 0.0
        self.total_samples = 0
        self.load()

    def load(self) -> None:
        self.samples_by_label.clear()
        self.feature_keys = []
        self.stats = {}
        self.global_std = {}
        self.total_samples = 0

        if not self.bank_path.exists():
            raise FileNotFoundError(f"No existe banco V4.7: {self.bank_path}")

        feature_counts = defaultdict(int)
        line_no = 0
        bad = 0
        for line in self.bank_path.read_text(encoding="utf-8", errors="replace").splitlines():
            line_no += 1
            line = line.strip()
            if not line:
                continue
            try:
                sample = json.loads(line)
            except Exception:
                bad += 1
                continue
            if not isinstance(sample, Mapping):
                bad += 1
                continue
            label = _extract_label(sample)
            feats = _flatten_features(sample)
            if label not in VALID_GESTURES or len(feats) < 8:
                bad += 1
                continue
            clean = {k: float(v) for k, v in feats.items() if k not in META_NUMERIC_KEYS and math.isfinite(float(v))}
            self.samples_by_label[label].append(clean)
            for k in clean:
                feature_counts[k] += 1
            self.total_samples += 1

        if self.total_samples <= 0:
            raise RuntimeError(f"Banco sin muestras válidas para runtime: {self.bank_path}")

        min_presence = max(6, int(self.total_samples * 0.08))
        self.feature_keys = sorted(k for k, c in feature_counts.items() if c >= min_presence)

        all_values: Dict[str, List[float]] = defaultdict(list)
        for samples in self.samples_by_label.values():
            for s in samples:
                for k in self.feature_keys:
                    if k in s:
                        all_values[k].append(s[k])
        for k, vals in all_values.items():
            arr = np.asarray(vals, dtype=float)
            self.global_std[k] = max(float(np.std(arr)), 0.035)

        for label, samples in self.samples_by_label.items():
            means: Dict[str, float] = {}
            stds: Dict[str, float] = {}
            for k in self.feature_keys:
                vals = [s[k] for s in samples if k in s]
                if not vals:
                    continue
                arr = np.asarray(vals, dtype=float)
                means[k] = float(np.mean(arr))
                # Mezcla std de clase con std global para no castigar de más clases compactas.
                stds[k] = max(float(np.std(arr)), self.global_std.get(k, 0.035) * 0.55, 0.035)
            self.stats[label] = {"mean": means, "std": stds}

        self.loaded_at = time.time()
        if bad:
            # No imprimas cada frame; esto solo sale al cargar.
            print(f"[TLETL V4.7 Runtime] Banco cargado con {self.total_samples} muestras válidas; ignoradas {bad} líneas.")

    def predict(self, features: Dict[str, float]) -> Dict[str, Any]:
        usable_keys = [k for k in self.feature_keys if k in features and isinstance(features.get(k), (int, float))]
        if len(usable_keys) < 8:
            return {
                "gesture": "NEUTRAL",
                "confidence": 0.0,
                "scores": {},
                "distances": {},
                "margin": 0.0,
                "used_features": len(usable_keys),
                "reason": "muy pocas features compatibles",
            }

        distances: Dict[str, float] = {}
        for label, st in self.stats.items():
            mean = st.get("mean", {})
            std = st.get("std", {})
            total = 0.0
            used = 0
            for k in usable_keys:
                if k not in mean:
                    continue
                z = (float(features[k]) - mean[k]) / max(std.get(k, 0.05), 0.035)
                # Recorta outliers para que un punto loco de MediaPipe no convierta todo en teatro.
                z = max(-5.0, min(5.0, z))
                total += z * z
                used += 1
            if used:
                distances[label] = math.sqrt(total / used)

        if not distances:
            return {
                "gesture": "NEUTRAL",
                "confidence": 0.0,
                "scores": {},
                "distances": {},
                "margin": 0.0,
                "used_features": len(usable_keys),
                "reason": "sin distancias útiles",
            }

        temp = _safe_float(os.environ.get("TLETL_AI_V47_SOFTMAX_TEMP", 4.0), 4.0)
        scores = _softmax_scores(distances, temp)
        ordered = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        best, best_score = ordered[0]
        second_score = ordered[1][1] if len(ordered) > 1 else 0.0
        margin = best_score - second_score
        return {
            "gesture": best,
            "confidence": float(best_score),
            "scores": scores,
            "distances": distances,
            "margin": float(margin),
            "used_features": len(usable_keys),
            "reason": "centroid-bank",
        }


class LiveRuntimeV47:
    def __init__(self, bank_path: Optional[Path] = None):
        if bank_path is None:
            bank_path = Path(os.environ.get("TLETL_AI_V47_BANK") or os.environ.get("TLETL_GESTURE_BANK") or os.environ.get("TLETL_BANK_PATH") or "datasets/tletl_gesture_bank_v2_features.jsonl")
        self.bank_path = Path(bank_path).expanduser().resolve()
        self.project_extractor = _discover_project_extractor()
        self.classifier = CentroidBankClassifier(self.bank_path)
        self.last_error = ""

    def reload_if_needed(self) -> None:
        try:
            mtime = self.bank_path.stat().st_mtime
            if mtime > self.classifier.loaded_at:
                # Evita recargar cada frame si el timestamp da raro.
                if time.time() - self.classifier.loaded_at > 2.0:
                    self.classifier.load()
        except Exception:
            pass

    def extract_features(self, landmarks: Any, handedness: Optional[str] = None) -> Dict[str, float]:
        features = _call_extractor(self.project_extractor, landmarks, handedness) or _fallback_geometric_features(landmarks)
        # Asegura orientación aunque features.py todavía sea tímido.
        orient = extract_orientation_features(landmarks, handedness=handedness)
        features.update(orient)
        return {k: float(v) for k, v in features.items() if isinstance(v, (int, float)) and math.isfinite(float(v))}

    def classify_landmarks(self, landmarks: Any, handedness: Optional[str] = None, rule_raw: str = "UNKNOWN") -> Dict[str, Any]:
        self.reload_if_needed()
        features = self.extract_features(landmarks, handedness=handedness)
        pred = self.classifier.predict(features)
        gesture = pred.get("gesture", "NEUTRAL")
        confidence = float(pred.get("confidence", 0.0))
        scores = pred.get("scores", {})

        votes = [gesture]
        rule_ai = RULE_TO_AI.get(str(rule_raw), None)
        if rule_ai:
            votes.append(rule_ai)
        # No agregamos tercer voto falso si no hay otro modelo. La democracia artificial también se puede corromper.

        if strict_critic_v47 and os.environ.get("TLETL_AI_V47_STRICT", "1") != "0":
            critic = strict_critic_v47(
                gesture=gesture,
                confidence=confidence,
                features=features,
                scores=scores,
                votes=None if os.environ.get("TLETL_AI_V47_USE_RULE_VOTE", "0") != "1" else votes,
                source="v47-live-centroid",
                allow_fallback_without_orientation=False,
            )
        else:
            critic = {
                "accepted": True,
                "final_gesture": gesture,
                "severity": "OK",
                "reason": "strict critic desactivado",
                "orientation": orientation_summary(features),
                "confidence": confidence,
                "margin": float(pred.get("margin", 0.0)),
                "fallback": False,
            }

        final_gesture = str(critic.get("final_gesture") or gesture)
        accepted = bool(critic.get("accepted"))
        if not accepted:
            final_gesture = "NEUTRAL"

        legacy_raw = ai_to_legacy_raw(final_gesture, fallback=rule_raw)
        return {
            "enabled": True,
            "bank": str(self.bank_path),
            "gesture": final_gesture,
            "raw_prediction": gesture,
            "legacy_raw": legacy_raw,
            "rule_raw": rule_raw,
            "accepted": accepted,
            "confidence": float(critic.get("confidence", confidence)),
            "margin": float(critic.get("margin", pred.get("margin", 0.0))),
            "orientation": str(critic.get("orientation") or orientation_summary(features)),
            "orientation_label": orientation_label(features),
            "critic_reason": str(critic.get("reason", "")),
            "critic_severity": str(critic.get("severity", "OK")),
            "features_used": int(pred.get("used_features", 0)),
            "scores": scores,
        }

    def info(self) -> Dict[str, Any]:
        return {
            "bank": str(self.bank_path),
            "samples": self.classifier.total_samples,
            "gestures": {g: len(v) for g, v in self.classifier.samples_by_label.items()},
            "feature_keys": len(self.classifier.feature_keys),
            "project_extractor": getattr(self.project_extractor, "__name__", None),
        }


_RUNTIME: Optional[LiveRuntimeV47] = None
_RUNTIME_ERROR = ""


def get_live_runtime_v47() -> LiveRuntimeV47:
    global _RUNTIME, _RUNTIME_ERROR
    if _RUNTIME is None:
        _RUNTIME = LiveRuntimeV47()
        _RUNTIME_ERROR = ""
    return _RUNTIME


def classify_landmarks_v47(landmarks: Any, handedness: Optional[str] = None, rule_raw: str = "UNKNOWN") -> Dict[str, Any]:
    try:
        return get_live_runtime_v47().classify_landmarks(landmarks, handedness=handedness, rule_raw=rule_raw)
    except Exception as exc:
        global _RUNTIME_ERROR
        _RUNTIME_ERROR = str(exc)
        return {
            "enabled": False,
            "gesture": RULE_TO_AI.get(rule_raw, "NEUTRAL"),
            "raw_prediction": "ERROR",
            "legacy_raw": rule_raw,
            "rule_raw": rule_raw,
            "accepted": False,
            "confidence": 0.0,
            "margin": 0.0,
            "orientation": "ORIENTATION:error",
            "orientation_label": "ERROR",
            "critic_reason": f"runtime error: {exc}",
            "critic_severity": "ERROR",
            "features_used": 0,
            "scores": {},
        }
