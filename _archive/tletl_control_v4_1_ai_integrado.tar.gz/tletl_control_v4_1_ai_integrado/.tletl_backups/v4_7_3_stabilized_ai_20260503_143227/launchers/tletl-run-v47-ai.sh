#!/usr/bin/env bash
set -euo pipefail

PROJECT="/home/exitili/Documentos/tletl_control_v4_1_ai_integrado"
VENV="/home/exitili/Documentos/tletl_control_v4_modular/.venv"
BANK="$PROJECT/datasets/tletl_gesture_bank_v2_features.jsonl"

cd "$PROJECT"
source "$VENV/bin/activate"

export YDOTOOL_SOCKET=/tmp/.ydotool_socket
export TLETL_AI_V47=1
export TLETL_AI_V47_STRICT=1
export TLETL_AI_V47_BANK="$BANK"
export TLETL_GESTURE_BANK="$BANK"
export TLETL_BANK_PATH="$BANK"
export TLETL_DATASET_PATH="$BANK"

# UNKNOWN es más seguro para NEUTRAL: evita acciones fantasma.
# Si necesitas que NEUTRAL suelte como palma abierta, cambia a OPEN_HAND bajo tu propio riesgo evolutivo.
export TLETL_AI_V47_NEUTRAL_RAW="UNKNOWN"

# Temperatura de softmax: más alto = más decisivo; más bajo = más humilde.
export TLETL_AI_V47_SOFTMAX_TEMP="4.0"

echo
echo "TLETL V4.7.2 LIVE AI"
echo "======================"
echo "Proyecto: $PROJECT"
echo "Python:   $(python --version)"
echo "Banco:    $BANK"
echo

python tools/tletl_v47_runtime_check.py --bank "$BANK" || true

echo
echo "Arrancando interfaz con IA V4.7.2 integrada..."
echo

python main.py
