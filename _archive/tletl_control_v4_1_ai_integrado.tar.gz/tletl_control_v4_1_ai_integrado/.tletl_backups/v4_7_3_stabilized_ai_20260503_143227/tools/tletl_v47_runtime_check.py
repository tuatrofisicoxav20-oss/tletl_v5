#!/usr/bin/env python3
from __future__ import annotations
# --- TLETL PROJECT ROOT IMPORT FIX ---
from pathlib import Path as _TletlPath
import sys as _tletl_sys

_TLETL_PROJECT_ROOT = _TletlPath(__file__).resolve().parents[1]
if str(_TLETL_PROJECT_ROOT) not in _tletl_sys.path:
    _tletl_sys.path.insert(0, str(_TLETL_PROJECT_ROOT))
# --- END TLETL PROJECT ROOT IMPORT FIX ---


import argparse
import json
import os
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Check rápido del runtime AI vivo Tletl V4.7.2")
    parser.add_argument("--bank", default="datasets/tletl_gesture_bank_v2_features.jsonl")
    args = parser.parse_args()

    bank = Path(args.bank).expanduser().resolve()
    os.environ["TLETL_AI_V47_BANK"] = str(bank)

    print("TLETL V4.7.2 LIVE AI RUNTIME CHECK")
    print("=" * 42)
    print(f"Python: {sys.version.split()[0]}")
    print(f"Banco:  {bank}")

    if not bank.exists():
        print("ERROR: no existe el banco.")
        return 2

    try:
        from tletl_control.ai_runtime_v47_live import get_live_runtime_v47
        rt = get_live_runtime_v47()
        info = rt.info()
    except Exception as exc:
        print(f"ERROR cargando runtime: {exc}")
        return 3

    print(f"Muestras:      {info.get('samples')}")
    print(f"Features keys: {info.get('feature_keys')}")
    print(f"Extractor:     {info.get('project_extractor') or 'fallback local'}")
    print("Gestos:")
    for k, v in sorted(info.get("gestures", {}).items()):
        print(f"  {k:<10} {v:>5}")

    missing = {"OPEN_PALM", "FIST", "POINT", "VICTORY", "PINCH", "THREE", "NEUTRAL"} - set(info.get("gestures", {}))
    if missing:
        print(f"WARN: faltan gestos en banco: {sorted(missing)}")
        return 1

    if int(info.get("feature_keys") or 0) < 12:
        print("WARN: muy pocas features útiles; el clasificador puede quedar menso con diploma.")
        return 1

    print("OK: runtime listo para interfaz.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
