#!/usr/bin/env bash
set -euo pipefail
exec "$(dirname "$0")/tletl-run-current.sh" "$@"
