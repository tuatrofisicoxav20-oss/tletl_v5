#!/usr/bin/env bash
set -euo pipefail
export TLETL_DRY_RUN=1
exec "$(dirname "$0")/tletl-run-current.sh" "$@"
