#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/Documentos/tletl_control_v4_1_ai_integrado"
VENV="$HOME/Documentos/tletl_control_v4_modular/.venv"

cd "$PROJECT"
source "$VENV/bin/activate"
export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"

python apps/blender_control/blender_state_reader.py
