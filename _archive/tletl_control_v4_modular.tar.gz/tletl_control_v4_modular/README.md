# Tletl Control V4 Modular

Esta versión separa Tletl Control en capas para que sea más estable y mantenible.

## Capas

```text
main.py
└── tletl_control/
    ├── cli.py          # argumentos
    ├── app.py          # orquestador principal
    ├── vision.py       # cámara + MediaPipe
    ├── gestures.py     # reglas de gestos
    ├── profile.py      # perfil calibrado + aprendizaje adaptativo
    ├── filters.py      # suavizado, swipes, timers, cursor
    ├── low_light.py    # mejora de baja luz
    ├── actions.py      # ydotool
    ├── ui.py           # ventanas y texto
    ├── features.py     # extracción de features
    ├── geometry.py     # puntos/distancias
    └── constants.py    # configuración base
```

## Instalar

```bash
cd ~/Documentos/tletl_control_v3
source .venv/bin/activate
pip install opencv-python mediapipe numpy
```

Copia o descomprime esta carpeta ahí.

## Probar seguro

```bash
export YDOTOOL_SOCKET=/tmp/.ydotool_socket
python main.py --profile tletl_profile_v3_4.json --dry-run --width 640 --height 480 --det-conf 0.50 --track-conf 0.50
```

## Ejecutar normal

```bash
export YDOTOOL_SOCKET=/tmp/.ydotool_socket
python main.py --profile tletl_profile_v3_4.json --width 640 --height 480 --det-conf 0.50 --track-conf 0.50
```

## Si falla la ventana extra

```bash
python main.py --profile tletl_profile_v3_4.json --status-backend cv2
```

o:

```bash
python main.py --profile tletl_profile_v3_4.json --no-status-window
```

## Limpiar aprendizaje adaptativo

```bash
rm tletl_adaptive_memory_v4.json
```

## Modos

- NAVEGADOR
- CURSOR
- VENTANAS
- SISTEMA

Cambias de modo con tres dedos sostenidos. Puño apaga por emergencia.
