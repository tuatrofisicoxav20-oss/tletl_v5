#!/usr/bin/env python3
"""
Tletl Control V3.6 Pro
Control por gestos para Fedora / navegador usando OpenCV + MediaPipe + ydotool.

Esta versión se enfoca en:
- Mejor detección en baja luz.
- Suavizado adaptativo para movimientos rápidos.
- Soporte real para dos manos.
- Ventana extra de estado tipo notificación.
- Toggle con palma más seguro y lento.
- Uso opcional del perfil calibrado de V3.4, con fallback por reglas geométricas.

Requisitos:
  pip install opencv-python mediapipe numpy
  sudo dnf install -y ydotool
  export YDOTOOL_SOCKET=/tmp/.ydotool_socket
"""

import argparse
import json
import math
import os
import subprocess
import sys
import time
from collections import Counter, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import mediapipe as mp
import numpy as np


# ============================================================
# CONFIGURACIÓN GENERAL
# ============================================================

APP_NAME = "Tletl Control V3.6 Pro"
DEFAULT_PROFILE_PATH = "tletl_profile_v3_4.json"
DEFAULT_ADAPTIVE_MEMORY_PATH = "tletl_adaptive_memory_v3_6.json"

CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480
CAMERA_FPS = 30

MIN_DETECTION_CONFIDENCE = 0.55
MIN_TRACKING_CONFIDENCE = 0.55
MODEL_COMPLEXITY = 1

# Suavizado adaptativo.
SMOOTHING_SLOW_ALPHA = 0.26
SMOOTHING_FAST_ALPHA = 0.68
FAST_MOTION_THRESHOLD = 0.018

# Estabilidad.
GESTURE_HISTORY_SIZE = 6
STABLE_GESTURE_MIN_COUNT = 3
PINCH_HISTORY_SIZE = 3

# Toggle más seguro.
TOGGLE_HOLD_ON_SECONDS = 1.45
TOGGLE_HOLD_OFF_SECONDS = 2.20
TOGGLE_COOLDOWN = 1.15
FIST_COOLDOWN = 0.50
MODE_HOLD_SECONDS = 0.85

# Acciones.
ACTION_COOLDOWN = 0.13
TAB_ACTION_COOLDOWN = 0.65
SWIPE_COOLDOWN = 0.55
BIG_ACTION_COOLDOWN = 0.85
CLICK_MAX_SECONDS = 0.22
DRAG_START_SECONDS = 0.32

# Cursor.
CURSOR_GAIN = 1750
CURSOR_MAX_STEP = 78
CURSOR_DEADZONE = 0.0048

# Zonas de navegación vertical.
UP_ZONE = 0.39
DOWN_ZONE = 0.61
EXTREME_UP_ZONE = 0.22
EXTREME_DOWN_ZONE = 0.78

# Perfil calibrado.
MIN_STD = 0.055
CONFIDENCE_THRESHOLD = 0.20
MARGIN_THRESHOLD = 0.030

# Zoom dos manos.
TWO_HAND_DISTANCE_DELTA = 0.105
TWO_HAND_DISTANCE_MIN_DT = 0.16

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


# ============================================================
# PUNTOS Y GEOMETRÍA
# ============================================================

class Point:
    __slots__ = ("x", "y", "z")

    def __init__(self, x: float, y: float, z: float):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)


def dist(a: Point, b: Point) -> float:
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)


def points_from_landmarks(hand_landmarks) -> List[Point]:
    return [Point(p.x, p.y, p.z) for p in hand_landmarks.landmark]


def palm_scale(lm: List[Point]) -> float:
    wrist_to_middle = dist(lm[0], lm[9])
    palm_width = dist(lm[5], lm[17])
    return max((wrist_to_middle + palm_width) / 2.0, 0.0001)


def palm_center_x(lm: List[Point]) -> float:
    ids = [0, 5, 9, 13, 17]
    return sum(lm[i].x for i in ids) / len(ids)


def palm_center_y(lm: List[Point]) -> float:
    ids = [0, 5, 9, 13, 17]
    return sum(lm[i].y for i in ids) / len(ids)


def palm_center(lm: List[Point]) -> Tuple[float, float]:
    return palm_center_x(lm), palm_center_y(lm)


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


# ============================================================
# BAJA LUZ / PREPROCESADO
# ============================================================

class LowLightEnhancer:
    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        self.last_luma = 0.0
        self.last_mode = "normal"

    def enhance(self, frame: np.ndarray) -> np.ndarray:
        if not self.enabled:
            self.last_mode = "off"
            return frame

        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        y, cr, cb = cv2.split(ycrcb)
        mean_luma = float(np.mean(y))
        self.last_luma = mean_luma

        # Si hay buena luz, no tocamos mucho la imagen. Tocar de más también arruina.
        if mean_luma >= 112:
            self.last_mode = "normal"
            return frame

        # CLAHE mejora contraste local. Es útil cuando la mano se ve plana/oscura.
        y2 = self.clahe.apply(y)

        # Gamma para levantar sombras. Menor gamma = más brillo.
        if mean_luma < 62:
            gamma = 0.62
            self.last_mode = "fuerte"
        elif mean_luma < 88:
            gamma = 0.76
            self.last_mode = "media"
        else:
            gamma = 0.88
            self.last_mode = "suave"

        inv_gamma = 1.0 / gamma
        table = np.array([(i / 255.0) ** inv_gamma * 255 for i in range(256)]).astype("uint8")
        y3 = cv2.LUT(y2, table)
        merged = cv2.merge([y3, cr, cb])
        return cv2.cvtColor(merged, cv2.COLOR_YCrCb2BGR)


# ============================================================
# SUAVIZADO ADAPTATIVO
# ============================================================

class AdaptiveLandmarkSmoother:
    def __init__(self, slow_alpha: float, fast_alpha: float, threshold: float):
        self.slow_alpha = slow_alpha
        self.fast_alpha = fast_alpha
        self.threshold = threshold
        self.values: Optional[List[List[float]]] = None
        self.prev_center: Optional[Tuple[float, float, float]] = None
        self.last_speed = 0.0
        self.last_alpha = slow_alpha

    def reset(self):
        self.values = None
        self.prev_center = None
        self.last_speed = 0.0
        self.last_alpha = self.slow_alpha

    def update(self, raw_points: List[Point]) -> List[Point]:
        now = time.time()
        cx, cy = palm_center(raw_points)

        if self.prev_center is None:
            speed = 0.0
        else:
            px, py, pt = self.prev_center
            dt = max(now - pt, 0.001)
            speed = math.sqrt((cx - px) ** 2 + (cy - py) ** 2) / dt

        self.prev_center = (cx, cy, now)
        self.last_speed = speed

        # Mientras más rápido se mueve la mano, menos suavizado aplicamos.
        # Así no se siente con retraso cuando haces swipes rápidos.
        t = clamp((speed - self.threshold) / max(self.threshold * 3.0, 0.001), 0.0, 1.0)
        alpha = self.slow_alpha * (1.0 - t) + self.fast_alpha * t
        self.last_alpha = alpha

        if self.values is None:
            self.values = [[p.x, p.y, p.z] for p in raw_points]
        else:
            for i, p in enumerate(raw_points):
                self.values[i][0] = alpha * p.x + (1.0 - alpha) * self.values[i][0]
                self.values[i][1] = alpha * p.y + (1.0 - alpha) * self.values[i][1]
                self.values[i][2] = alpha * p.z + (1.0 - alpha) * self.values[i][2]

        return [Point(x, y, z) for x, y, z in self.values]


# ============================================================
# FEATURES Y PERFIL OPCIONAL
# ============================================================

FINGERS = {
    "index": (8, 6, 5),
    "middle": (12, 10, 9),
    "ring": (16, 14, 13),
    "pinky": (20, 18, 17),
}


def extract_features(lm: List[Point]) -> Dict[str, float]:
    scale = palm_scale(lm)
    wrist = lm[0]
    features: Dict[str, float] = {}

    for name, (tip, pip, mcp) in FINGERS.items():
        features[f"{name}_tip_wrist"] = dist(lm[tip], wrist) / scale
        features[f"{name}_pip_wrist"] = dist(lm[pip], wrist) / scale
        features[f"{name}_mcp_wrist"] = dist(lm[mcp], wrist) / scale
        features[f"{name}_tip_mcp"] = dist(lm[tip], lm[mcp]) / scale
        features[f"{name}_tip_pip"] = dist(lm[tip], lm[pip]) / scale
        features[f"{name}_vertical"] = (lm[pip].y - lm[tip].y) / scale
        features[f"{name}_curl"] = (dist(lm[tip], wrist) - dist(lm[pip], wrist)) / scale

    features["thumb_tip_wrist"] = dist(lm[4], wrist) / scale
    features["thumb_ip_wrist"] = dist(lm[3], wrist) / scale
    features["thumb_tip_index_mcp"] = dist(lm[4], lm[5]) / scale
    features["thumb_tip_index_tip"] = dist(lm[4], lm[8]) / scale
    features["thumb_tip_middle_tip"] = dist(lm[4], lm[12]) / scale
    features["thumb_horizontal"] = abs(lm[4].x - lm[3].x) / scale
    features["thumb_vertical"] = abs(lm[4].y - lm[3].y) / scale

    features["index_middle_spread"] = dist(lm[8], lm[12]) / scale
    features["middle_ring_spread"] = dist(lm[12], lm[16]) / scale
    features["ring_pinky_spread"] = dist(lm[16], lm[20]) / scale
    features["index_pinky_spread"] = dist(lm[8], lm[20]) / scale
    features["palm_width"] = dist(lm[5], lm[17]) / scale
    features["wrist_middle_mcp"] = dist(lm[0], lm[9]) / scale
    features["palm_center_x"] = palm_center_x(lm)
    features["palm_center_y"] = palm_center_y(lm)
    return features


def load_profile_optional(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        print(f"[AVISO] No encontré perfil {path}. Usaré reglas geométricas solamente.")
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[AVISO] No pude leer perfil {path}: {exc}. Usaré reglas geométricas.")
        return None


ADAPTIVE_EXCLUDED_FEATURES = {"palm_center_x", "palm_center_y"}
ADAPTIVE_ALLOWED_GESTURES = {"OPEN_PALM", "FIST", "POINT", "VICTORY", "THREE", "PINCH", "NEUTRAL"}


def adaptive_feature_keys_from_sample(sample: Dict[str, float]) -> List[str]:
    return sorted(k for k in sample.keys() if k not in ADAPTIVE_EXCLUDED_FEATURES)


def compute_profile_stats_from_samples(samples: List[Dict[str, float]], keys: List[str]) -> Dict[str, Dict[str, float]]:
    mean: Dict[str, float] = {}
    std: Dict[str, float] = {}
    for key in keys:
        vals = [float(s[key]) for s in samples if key in s and isinstance(s.get(key), (int, float))]
        if not vals:
            continue
        m = sum(vals) / len(vals)
        var = sum((v - m) ** 2 for v in vals) / max(len(vals) - 1, 1)
        mean[key] = m
        std[key] = max(math.sqrt(var), MIN_STD)
    return {"mean": mean, "std": std}


class AdaptiveGestureMemory:
    """
    Memoria de auto-calibración segura.

    No aprende cualquier cosa como perico con internet. Solo guarda muestras cuando:
    - el gesto tiene confianza alta,
    - la regla y/o el perfil están de acuerdo,
    - el gesto no es UNKNOWN/WAITING/UNSTABLE,
    - hay separación temporal entre muestras.

    La memoria se convierte en un perfil adicional y se usa junto al perfil calibrado.
    Así mejora con tu forma real de mover la mano sin arruinar el perfil base.
    """
    def __init__(self, path: Path, enabled: bool = True, max_samples: int = 240,
                 min_conf: float = 0.78, save_seconds: float = 5.0):
        self.path = path
        self.enabled = enabled
        self.max_samples = max(40, int(max_samples))
        self.min_conf = float(min_conf)
        self.save_seconds = float(save_seconds)
        self.data: Dict[str, Any] = {
            "app": APP_NAME,
            "version": "3.6-adaptive-memory",
            "feature_keys": [],
            "gestures": {},
            "updated_at": time.time(),
        }
        self.last_sample_time: Dict[str, float] = {}
        self.last_save_time = 0.0
        self.dirty = False
        self.load()

    def load(self):
        if not self.path.exists():
            return
        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict) and isinstance(loaded.get("gestures", {}), dict):
                self.data = loaded
        except Exception as exc:
            print(f"[AVISO] No pude cargar memoria adaptativa {self.path}: {exc}")

    def counts(self) -> Dict[str, int]:
        return {g: len(v) for g, v in self.data.get("gestures", {}).items() if isinstance(v, list)}

    def total_samples(self) -> int:
        return sum(self.counts().values())

    def short_counts(self) -> str:
        counts = self.counts()
        if not counts:
            return "0"
        order = ["PINCH", "POINT", "OPEN_PALM", "FIST", "VICTORY", "THREE", "NEUTRAL"]
        parts = [f"{g}:{counts[g]}" for g in order if counts.get(g)]
        return " ".join(parts[:5]) if parts else "0"

    def _clean_sample(self, features: Dict[str, float]) -> Dict[str, float]:
        sample: Dict[str, float] = {}
        for key, value in features.items():
            if key in ADAPTIVE_EXCLUDED_FEATURES:
                continue
            if isinstance(value, (int, float)) and math.isfinite(float(value)):
                sample[key] = round(float(value), 6)
        return sample

    def observe(self, hand: Any):
        if not self.enabled or hand is None:
            return
        gesture = getattr(hand, "raw_gesture", "UNKNOWN")
        stable = getattr(hand, "stable_gesture", "UNKNOWN")
        confidence = float(getattr(hand, "confidence", 0.0))
        source = str(getattr(hand, "source", ""))

        if gesture not in ADAPTIVE_ALLOWED_GESTURES:
            return
        if gesture in {"UNKNOWN", "WAITING", "UNSTABLE", "NO_HAND"}:
            return
        if confidence < self.min_conf:
            return

        # Pinza necesita aprender rápido, pero sin guardar basura.
        if gesture == "PINCH":
            safe = confidence >= max(self.min_conf, 0.80)
        else:
            safe = (stable == gesture and source in {"perfil+regla", "regla", "regla-rapida"}) or confidence >= 0.86
        if not safe:
            return

        now = time.time()
        if now - self.last_sample_time.get(gesture, 0.0) < 0.20:
            return
        self.last_sample_time[gesture] = now

        sample = self._clean_sample(getattr(hand, "features", {}))
        if len(sample) < 8:
            return

        keys = self.data.get("feature_keys") or adaptive_feature_keys_from_sample(sample)
        self.data["feature_keys"] = keys

        gestures = self.data.setdefault("gestures", {})
        bucket = gestures.setdefault(gesture, [])
        bucket.append(sample)
        if len(bucket) > self.max_samples:
            del bucket[:len(bucket) - self.max_samples]
        self.data["updated_at"] = time.time()
        self.dirty = True

    def to_profile(self) -> Optional[Dict[str, Any]]:
        gestures = self.data.get("gestures", {})
        keys = self.data.get("feature_keys", [])
        if not gestures or not keys:
            return None
        profile_gestures: Dict[str, Any] = {}
        for gesture, samples in gestures.items():
            if not isinstance(samples, list) or len(samples) < 18:
                # Menos de 18 ejemplos suele ser ruido disfrazado de ciencia.
                continue
            stats = compute_profile_stats_from_samples(samples, keys)
            if stats["mean"] and stats["std"]:
                profile_gestures[gesture] = {
                    "samples": len(samples),
                    "mean": stats["mean"],
                    "std": stats["std"],
                }
        if not profile_gestures:
            return None
        return {
            "app": APP_NAME,
            "version": "3.6-adaptive-profile",
            "feature_keys": keys,
            "gestures": profile_gestures,
        }

    def save_if_needed(self, force: bool = False):
        if not self.enabled:
            return
        now = time.time()
        if not force and (not self.dirty or now - self.last_save_time < self.save_seconds):
            return
        try:
            self.path.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
            self.last_save_time = now
            self.dirty = False
        except Exception as exc:
            print(f"[AVISO] No pude guardar memoria adaptativa: {exc}")


def build_profile_ensemble(base_profile: Optional[Dict[str, Any]], adaptive_profile: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    profiles = [p for p in [base_profile, adaptive_profile] if p]
    if not profiles:
        return None
    if len(profiles) == 1:
        return profiles[0]
    return {"ensemble": profiles}


def classify_with_single_profile(features: Dict[str, float], profile: Dict[str, Any]) -> Tuple[str, float]:
    keys = profile.get("feature_keys", [])
    gestures = profile.get("gestures", {})
    if not keys or not gestures:
        return "UNKNOWN", 0.0

    scores: Dict[str, float] = {}
    for gesture_id, data in gestures.items():
        mean = data.get("mean", {})
        std = data.get("std", {})
        total = 0.0
        used = 0
        for key in keys:
            if key not in features:
                continue
            s = max(float(std.get(key, MIN_STD)), MIN_STD)
            m = float(mean.get(key, 0.0))
            z = (features[key] - m) / s
            total += z * z
            used += 1
        scores[gesture_id] = math.sqrt(total / used) if used else 999.0

    ordered = sorted(scores.items(), key=lambda item: item[1])
    if not ordered:
        return "UNKNOWN", 0.0

    best, best_score = ordered[0]
    second_score = ordered[1][1] if len(ordered) > 1 else 999.0
    confidence = 1.0 / (1.0 + best_score)
    margin = second_score - best_score

    if confidence < CONFIDENCE_THRESHOLD or margin < MARGIN_THRESHOLD:
        return "UNKNOWN", confidence
    return best, confidence


def classify_with_profile(features: Dict[str, float], profile: Dict[str, Any]) -> Tuple[str, float]:
    if not profile:
        return "UNKNOWN", 0.0
    if isinstance(profile, dict) and "ensemble" in profile:
        best_gesture = "UNKNOWN"
        best_conf = 0.0
        for one_profile in profile.get("ensemble", []):
            gesture, conf = classify_with_single_profile(features, one_profile)
            if gesture != "UNKNOWN" and conf > best_conf:
                best_gesture, best_conf = gesture, conf
        return best_gesture, best_conf
    return classify_with_single_profile(features, profile)


# ============================================================
# CLASIFICADOR GEOMÉTRICO MÁS TOLERANTE
# ============================================================

def finger_extended_rule(lm: List[Point], tip: int, pip: int, mcp: int) -> bool:
    scale = palm_scale(lm)
    wrist = lm[0]
    vertical = (lm[pip].y - lm[tip].y) > 0.010
    length = (dist(lm[tip], wrist) - dist(lm[pip], wrist)) > (0.036 * scale)
    tip_far = dist(lm[tip], lm[mcp]) > (0.385 * scale)
    return (vertical and length) or (vertical and tip_far)


def thumb_open_rule(lm: List[Point]) -> bool:
    scale = palm_scale(lm)
    return dist(lm[4], lm[5]) > 0.42 * scale and dist(lm[4], lm[8]) > 0.27 * scale


def pinch_ratio(lm: List[Point]) -> float:
    return dist(lm[4], lm[8]) / palm_scale(lm)


def pinch_rule(lm: List[Point]) -> Tuple[bool, float]:
    scale = palm_scale(lm)
    thumb_index = dist(lm[4], lm[8]) / scale
    thumb_middle = dist(lm[4], lm[12]) / scale
    thumb_ring = dist(lm[4], lm[16]) / scale

    close = thumb_index < 0.50
    tight = thumb_index < 0.36
    index_closest = thumb_index < min(thumb_middle * 0.94, thumb_ring * 0.91)

    index_tip_mcp = dist(lm[8], lm[5]) / scale
    thumb_tip_to_palm = dist(lm[4], lm[9]) / scale
    not_fist = index_tip_mcp > 0.25 or thumb_tip_to_palm > 0.39

    ok = (tight or (close and index_closest)) and not_fist
    conf = clamp(1.08 - thumb_index, 0.0, 0.96)
    return ok, conf


def rule_fingers(lm: List[Point]) -> Dict[str, bool]:
    return {
        "thumb": thumb_open_rule(lm),
        "index": finger_extended_rule(lm, 8, 6, 5),
        "middle": finger_extended_rule(lm, 12, 10, 9),
        "ring": finger_extended_rule(lm, 16, 14, 13),
        "pinky": finger_extended_rule(lm, 20, 18, 17),
    }


def classify_by_rules(lm: List[Point]) -> Tuple[str, float, Dict[str, bool]]:
    f = rule_fingers(lm)
    long_count = sum([f["index"], f["middle"], f["ring"], f["pinky"]])
    total = long_count + int(f["thumb"])

    pinch_ok, pinch_conf = pinch_rule(lm)
    if pinch_ok and pinch_conf >= 0.58:
        return "PINCH", max(0.64, pinch_conf), f

    if long_count >= 4:
        return "OPEN_PALM", 0.80, f
    if long_count == 0 and not f["thumb"]:
        return "FIST", 0.82, f
    if f["index"] and not f["middle"] and not f["ring"] and not f["pinky"]:
        return "POINT", 0.78, f
    if f["index"] and f["middle"] and f["ring"] and not f["pinky"]:
        return "THREE", 0.74, f
    if f["index"] and f["middle"] and not f["ring"] and not f["pinky"]:
        return "VICTORY", 0.77, f
    if total <= 2:
        return "NEUTRAL", 0.58, f
    return "UNKNOWN", 0.0, f


def classify_hybrid(points: List[Point], features: Dict[str, float], profile: Optional[Dict[str, Any]]) -> Tuple[str, float, str, Dict[str, bool]]:
    rule_gesture, rule_conf, fingers = classify_by_rules(points)
    if profile is None:
        return rule_gesture, rule_conf, "regla", fingers

    profile_gesture, profile_conf = classify_with_profile(features, profile)

    # Pinza y puño deben ser rápidos y seguros.
    if rule_gesture in {"PINCH", "FIST"} and rule_conf >= 0.62:
        return rule_gesture, rule_conf, "regla-rapida", fingers

    if profile_gesture == rule_gesture and profile_gesture != "UNKNOWN":
        return profile_gesture, min(1.0, max(profile_conf, rule_conf) + 0.13), "perfil+regla", fingers

    if rule_gesture in {"OPEN_PALM", "POINT", "VICTORY", "THREE"} and rule_conf >= 0.72:
        return rule_gesture, rule_conf, "regla", fingers

    if profile_gesture != "UNKNOWN" and profile_conf >= 0.31:
        return profile_gesture, profile_conf, "perfil", fingers

    return rule_gesture, rule_conf, "regla", fingers


# ============================================================
# FILTROS Y MOVIMIENTO
# ============================================================

class StableGestureFilter:
    def __init__(self, size: int, min_count: int):
        self.history = deque(maxlen=size)
        self.min_count = min_count

    def clear(self):
        self.history.clear()

    def update(self, gesture: str) -> str:
        self.history.append(gesture)
        if len(self.history) < self.history.maxlen:
            return "WAITING"
        gesture, amount = Counter(self.history).most_common(1)[0]
        if gesture == "UNKNOWN":
            return "UNKNOWN"
        return gesture if amount >= self.min_count else "UNSTABLE"


class MotionTracker:
    def __init__(self, maxlen: int = 9):
        self.points = deque(maxlen=maxlen)
        self.last_swipe_time = 0.0
        self.last_velocity = 0.0

    def reset(self):
        self.points.clear()
        self.last_velocity = 0.0

    def update(self, x: float, y: float):
        now = time.time()
        if self.points:
            t0, x0, y0 = self.points[-1]
            dt = max(now - t0, 0.001)
            self.last_velocity = math.sqrt((x - x0) ** 2 + (y - y0) ** 2) / dt
        self.points.append((now, x, y))

    def swipe(self) -> Optional[str]:
        if len(self.points) < 4:
            return None
        now = time.time()
        if now - self.last_swipe_time < SWIPE_COOLDOWN:
            return None
        t0, x0, y0 = self.points[0]
        t1, x1, y1 = self.points[-1]
        dt = max(t1 - t0, 0.001)
        dx = x1 - x0
        dy = y1 - y0

        # Más sensible a movimientos rápidos, menos a movimientos lentos accidentales.
        fast = dt <= 0.55
        horiz_threshold = 0.115 if fast else 0.155
        vert_threshold = 0.115 if fast else 0.155

        if dt <= 0.90 and abs(dx) > horiz_threshold and abs(dx) > abs(dy) * 1.45:
            self.last_swipe_time = now
            self.points.clear()
            return "RIGHT" if dx > 0 else "LEFT"

        if dt <= 0.90 and abs(dy) > vert_threshold and abs(dy) > abs(dx) * 1.45:
            self.last_swipe_time = now
            self.points.clear()
            return "DOWN" if dy > 0 else "UP"
        return None


class CursorController:
    def __init__(self, gain: int, max_step: int, deadzone: float):
        self.prev: Optional[Tuple[float, float]] = None
        self.gain = gain
        self.max_step = max_step
        self.deadzone = deadzone

    def reset(self):
        self.prev = None

    def update(self, x: float, y: float, velocity: float = 0.0) -> Tuple[int, int]:
        if self.prev is None:
            self.prev = (x, y)
            return 0, 0
        px, py = self.prev
        self.prev = (x, y)
        dx_norm = x - px
        dy_norm = y - py

        if abs(dx_norm) < self.deadzone:
            dx_norm = 0.0
        if abs(dy_norm) < self.deadzone:
            dy_norm = 0.0

        # Aceleración ligera cuando te mueves rápido.
        accel = clamp(1.0 + velocity * 2.1, 1.0, 2.15)
        dx = int(clamp(dx_norm * self.gain * accel, -self.max_step, self.max_step))
        dy = int(clamp(dy_norm * self.gain * accel, -self.max_step, self.max_step))
        return dx, dy


class HoldTimer:
    def __init__(self):
        self.gesture: Optional[str] = None
        self.started_at = 0.0

    def reset(self):
        self.gesture = None
        self.started_at = 0.0

    def progress(self, gesture: str, seconds: float) -> float:
        now = time.time()
        if self.gesture != gesture:
            self.gesture = gesture
            self.started_at = now
        return clamp((now - self.started_at) / max(seconds, 0.001), 0.0, 1.0)


class TwoHandDistanceTracker:
    def __init__(self):
        self.history = deque(maxlen=10)
        self.last_action_time = 0.0

    def reset(self):
        self.history.clear()

    def update(self, left_center: Tuple[float, float], right_center: Tuple[float, float]):
        x1, y1 = left_center
        x2, y2 = right_center
        d = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        self.history.append((time.time(), d))

    def spread_or_pinch(self) -> Optional[str]:
        if len(self.history) < 5:
            return None
        now = time.time()
        if now - self.last_action_time < BIG_ACTION_COOLDOWN:
            return None
        t0, d0 = self.history[0]
        t1, d1 = self.history[-1]
        dt = max(t1 - t0, 0.001)
        if dt < TWO_HAND_DISTANCE_MIN_DT or dt > 1.15:
            return None
        delta = d1 - d0
        if abs(delta) < TWO_HAND_DISTANCE_DELTA:
            return None
        self.last_action_time = now
        self.history.clear()
        return "SPREAD" if delta > 0 else "PINCH_IN"


# ============================================================
# ESTADO DE MANO
# ============================================================

@dataclass
class DetectedHand:
    label: str
    raw_landmarks: Any
    points: List[Point]
    features: Dict[str, float]
    raw_gesture: str
    stable_gesture: str
    action_gesture: str
    confidence: float
    source: str
    fingers: Dict[str, bool]
    center_x: float
    center_y: float
    scale: float
    speed: float
    alpha: float
    swipe: Optional[str]


class HandState:
    def __init__(self, args):
        self.smoother = AdaptiveLandmarkSmoother(args.slow_alpha, args.fast_alpha, args.fast_threshold)
        self.stable = StableGestureFilter(args.history, args.stable_count)
        self.motion = MotionTracker(maxlen=args.motion_history)
        self.cursor = CursorController(args.cursor_gain, args.cursor_max_step, args.cursor_deadzone)
        self.last_seen = 0.0

    def reset(self):
        self.smoother.reset()
        self.stable.clear()
        self.motion.reset()
        self.cursor.reset()


# ============================================================
# ACCIONES CON YDOTOOL
# ============================================================

class ActionRunner:
    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run

    def _run(self, cmd: List[str], label: str):
        if self.dry_run:
            print(f"[DRY-RUN] {label}: {' '.join(cmd)}")
            return
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        except Exception as exc:
            print(f"[ERROR ydotool] {exc}")

    def key(self, sequence: str, label: str):
        self._run(["ydotool", "key"] + sequence.split(), label)

    def mousemove_relative(self, dx: int, dy: int):
        if dx or dy:
            self._run(["ydotool", "mousemove", "-x", str(dx), "-y", str(dy)], f"MouseMove {dx},{dy}")

    def click_left(self): self._run(["ydotool", "click", "0xC0"], "Left Click")
    def click_right(self): self._run(["ydotool", "click", "0xC1"], "Right Click")
    def mouse_down_left(self): self._run(["ydotool", "click", "0x40"], "Left Down")
    def mouse_up_left(self): self._run(["ydotool", "click", "0x80"], "Left Up")

    def page_down(self): self.key("109:1 109:0", "PageDown")
    def page_up(self): self.key("104:1 104:0", "PageUp")
    def scroll_down_small(self): self.key("108:1 108:0", "ArrowDown")
    def scroll_up_small(self): self.key("103:1 103:0", "ArrowUp")
    def next_tab(self): self.key("29:1 15:1 15:0 29:0", "Ctrl+Tab")
    def previous_tab(self): self.key("29:1 42:1 15:1 15:0 42:0 29:0", "Ctrl+Shift+Tab")
    def browser_back(self): self.key("56:1 105:1 105:0 56:0", "Alt+Left")
    def browser_forward(self): self.key("56:1 106:1 106:0 56:0", "Alt+Right")
    def alt_tab(self): self.key("56:1 15:1 15:0 56:0", "Alt+Tab")
    def alt_shift_tab(self): self.key("56:1 42:1 15:1 15:0 42:0 56:0", "Alt+Shift+Tab")
    def overview(self): self.key("125:1 125:0", "Super / Overview")
    def enter(self): self.key("28:1 28:0", "Enter")
    def escape(self): self.key("1:1 1:0", "Escape")
    def volume_up(self): self.key("115:1 115:0", "Volume Up")
    def volume_down(self): self.key("114:1 114:0", "Volume Down")
    def volume_mute(self): self.key("113:1 113:0", "Mute")
    def workspace_next(self): self.key("125:1 109:1 109:0 125:0", "Workspace Next / Super+PageDown")
    def workspace_prev(self): self.key("125:1 104:1 104:0 125:0", "Workspace Prev / Super+PageUp")
    def zoom_in(self): self.key("29:1 13:1 13:0 29:0", "Zoom In / Ctrl+=")
    def zoom_out(self): self.key("29:1 12:1 12:0 29:0", "Zoom Out / Ctrl+-")


# ============================================================
# UI
# ============================================================

def draw_text_box(frame: np.ndarray, lines: List[str], origin=(14, 14), font_scale=0.50):
    x, y = origin
    line_h = 25
    width = min(frame.shape[1] - 25, 1040)
    height = 20 + line_h * len(lines)
    cv2.rectangle(frame, (x - 7, y - 8), (x + width, y + height), (0, 0, 0), -1)
    for i, line in enumerate(lines):
        cv2.putText(frame, line, (x, y + 20 + i * line_h), cv2.FONT_HERSHEY_SIMPLEX,
                    font_scale, (255, 255, 255), 2, cv2.LINE_AA)


def draw_progress_bar(frame: np.ndarray, progress: float, y_offset: int = 42, color=(0, 220, 120)):
    h, w = frame.shape[:2]
    x1, x2 = 24, w - 24
    y = h - y_offset
    cv2.rectangle(frame, (x1, y - 10), (x2, y + 10), (40, 40, 40), -1)
    filled = int((x2 - x1) * clamp(progress, 0.0, 1.0))
    cv2.rectangle(frame, (x1, y - 10), (x1 + filled, y + 10), color, -1)
    cv2.rectangle(frame, (x1, y - 10), (x2, y + 10), (255, 255, 255), 2)


def draw_zones(frame: np.ndarray):
    h, w = frame.shape[:2]
    cv2.line(frame, (0, int(h * UP_ZONE)), (w, int(h * UP_ZONE)), (255, 255, 0), 1)
    cv2.line(frame, (0, int(h * DOWN_ZONE)), (w, int(h * DOWN_ZONE)), (255, 255, 0), 1)


def draw_status_window(info: Dict[str, Any], enabled: bool = True):
    if not enabled:
        return
    img = np.zeros((286, 560, 3), dtype=np.uint8)
    active = info.get("active", False)
    color = (0, 210, 80) if active else (0, 0, 230)
    cv2.rectangle(img, (0, 0), (560, 286), (18, 18, 18), -1)
    cv2.circle(img, (34, 38), 18, color, -1)
    title = "TLETL ACTIVO" if active else "TLETL APAGADO"
    cv2.putText(img, title, (65, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.78, (255, 255, 255), 2, cv2.LINE_AA)

    lines = [
        f"Modo: {info.get('mode', '-')}",
        f"Manos: {info.get('hands', 0)} | FPS: {info.get('fps', 0):.1f}",
        f"Principal: {info.get('main_gesture', '-')}",
        f"Secundaria: {info.get('second_gesture', '-')}",
        f"Accion: {info.get('last_action', '-')}",
        f"Luz: {info.get('luma', 0):.0f} | Mejora: {info.get('light_mode', '-')}",
        f"Aprendizaje: {info.get('adaptive', '0')}",
    ]
    y = 84
    for line in lines:
        cv2.putText(img, line, (24, y), cv2.FONT_HERSHEY_SIMPLEX, 0.53, (230, 230, 230), 2, cv2.LINE_AA)
        y += 27

    cv2.putText(img, "Puño = emergencia | Q = salir", (24, 263), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (180, 180, 180), 1, cv2.LINE_AA)
    cv2.imshow("Tletl Estado", img)


class StatusNotifier:
    """Ventana de estado mejorada.

    Intenta usar Tkinter como mini-notificación always-on-top. Si Tkinter no existe
    o falla, cae a una ventana OpenCV normal. Porque incluso para enseñar un texto,
    Linux puede inventar una pequeña novela trágica.
    """
    def __init__(self, enabled: bool = True, backend: str = "auto"):
        self.enabled = enabled and backend != "off"
        self.backend = "off"
        self.root = None
        self.labels: Dict[str, Any] = {}
        if not self.enabled:
            return
        if backend in {"auto", "tk"}:
            try:
                import tkinter as tk
                self.root = tk.Tk()
                self.root.title("Tletl Estado")
                self.root.geometry("360x235+40+80")
                self.root.attributes("-topmost", True)
                self.root.configure(bg="#111111")
                self.root.resizable(False, False)
                title = tk.Label(self.root, text="TLETL", bg="#111111", fg="white", font=("Sans", 17, "bold"))
                title.pack(anchor="w", padx=16, pady=(12, 3))
                for key in ["active", "mode", "hands", "main", "second", "action", "light", "adaptive"]:
                    lbl = tk.Label(self.root, text="-", bg="#111111", fg="#dddddd", font=("Sans", 10))
                    lbl.pack(anchor="w", padx=16, pady=1)
                    self.labels[key] = lbl
                self.backend = "tk"
                return
            except Exception as exc:
                print(f"[AVISO] Tk status falló, usaré OpenCV: {exc}")
        self.backend = "cv2"
        cv2.namedWindow("Tletl Estado", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("Tletl Estado", 560, 286)

    def update(self, info: Dict[str, Any]):
        if not self.enabled:
            return
        if self.backend == "tk" and self.root is not None:
            active = bool(info.get("active", False))
            self.labels["active"].configure(
                text="Estado: ACTIVO" if active else "Estado: APAGADO",
                fg="#4dff88" if active else "#ff5555",
            )
            self.labels["mode"].configure(text=f"Modo: {info.get('mode', '-')}")
            self.labels["hands"].configure(text=f"Manos: {info.get('hands', 0)} | FPS: {info.get('fps', 0):.1f}")
            self.labels["main"].configure(text=f"Principal: {info.get('main_gesture', '-')}")
            self.labels["second"].configure(text=f"Secundaria: {info.get('second_gesture', '-')}")
            self.labels["action"].configure(text=f"Acción: {info.get('last_action', '-')}")
            self.labels["light"].configure(text=f"Luz: {info.get('luma', 0):.0f} | Mejora: {info.get('light_mode', '-')}")
            self.labels["adaptive"].configure(text=f"Aprendizaje: {info.get('adaptive', '0')}")
            try:
                self.root.update_idletasks()
                self.root.update()
            except Exception:
                self.enabled = False
        elif self.backend == "cv2":
            draw_status_window(info, enabled=True)

    def close(self):
        if self.root is not None:
            try:
                self.root.destroy()
            except Exception:
                pass


# ============================================================
# CÁMARA Y DETECCIÓN
# ============================================================

def open_camera(index: int, width: int, height: int, fps: int):
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"No pude abrir la cámara index={index}. Prueba --camera 1 o --camera 2.")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def get_hand_state(states: Dict[str, HandState], label: str, args) -> HandState:
    if label not in states:
        states[label] = HandState(args)
    return states[label]


def detect_hands(frame: np.ndarray, hands_model, states: Dict[str, HandState], enhancer: LowLightEnhancer,
                 profile: Optional[Dict[str, Any]], args) -> Tuple[np.ndarray, List[DetectedHand]]:
    frame = cv2.flip(frame, 1)
    enhanced = enhancer.enhance(frame)
    rgb = cv2.cvtColor(enhanced, cv2.COLOR_BGR2RGB)
    result = hands_model.process(rgb)

    detected: List[DetectedHand] = []
    now = time.time()

    if not result.multi_hand_landmarks:
        for st in states.values():
            st.stable.clear()
            st.motion.reset()
            st.cursor.reset()
        return frame, detected

    handedness_list = result.multi_handedness or []

    for i, raw_landmarks in enumerate(result.multi_hand_landmarks):
        label = f"Hand{i}"
        score = 0.0
        if i < len(handedness_list):
            classification = handedness_list[i].classification[0]
            label = classification.label
            score = classification.score
            # Evita colisión rara si MediaPipe etiqueta dos manos igual.
            if label in [h.label for h in detected]:
                label = f"{label}_{i}"

        state = get_hand_state(states, label, args)
        state.last_seen = now

        raw_points = points_from_landmarks(raw_landmarks)
        points = state.smoother.update(raw_points)
        features = extract_features(points)
        center_x = features["palm_center_x"]
        center_y = features["palm_center_y"]
        state.motion.update(center_x, center_y)
        swipe = state.motion.swipe()

        raw_gesture, confidence, source, fingers = classify_hybrid(points, features, profile)
        stable_gesture = state.stable.update(raw_gesture)

        # Pinza va por vía rápida. Si esperamos demasiados frames, seleccionar se siente horrible.
        action_gesture = stable_gesture
        if raw_gesture == "PINCH" and confidence >= 0.58:
            action_gesture = "PINCH"
        elif raw_gesture == "FIST" and confidence >= 0.72:
            action_gesture = "FIST"

        detected.append(DetectedHand(
            label=label,
            raw_landmarks=raw_landmarks,
            points=points,
            features=features,
            raw_gesture=raw_gesture,
            stable_gesture=stable_gesture,
            action_gesture=action_gesture,
            confidence=confidence,
            source=source,
            fingers=fingers,
            center_x=center_x,
            center_y=center_y,
            scale=palm_scale(points),
            speed=state.motion.last_velocity,
            alpha=state.smoother.last_alpha,
            swipe=swipe,
        ))

        mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)
        cv2.putText(frame, f"{label} {raw_gesture} {confidence:.2f}",
                    (int(center_x * frame.shape[1]) - 60, int(center_y * frame.shape[0]) - 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 255, 255), 2, cv2.LINE_AA)

    # Limpia estados de manos no vistas hace rato.
    for label in list(states.keys()):
        if now - states[label].last_seen > 1.0:
            states[label].reset()

    detected.sort(key=lambda h: h.scale, reverse=True)
    return frame, detected


# ============================================================
# LÓGICA PRINCIPAL
# ============================================================

def hand_summary(hand: Optional[DetectedHand]) -> str:
    if not hand:
        return "-"
    return f"{hand.label}:{hand.action_gesture}/{hand.stable_gesture} {hand.confidence:.2f}"


def any_hand_with(hands: List[DetectedHand], gesture: str) -> bool:
    return any(h.action_gesture == gesture or h.stable_gesture == gesture for h in hands)


def both_stable(hands: List[DetectedHand], gesture: str) -> bool:
    return len(hands) >= 2 and all(h.stable_gesture == gesture for h in hands[:2])


def choose_main_hand(hands: List[DetectedHand]) -> Tuple[Optional[DetectedHand], Optional[DetectedHand]]:
    if not hands:
        return None, None
    # Preferimos la mano más grande/visible. Menos romanticismo, más señal útil.
    main = hands[0]
    second = hands[1] if len(hands) > 1 else None
    return main, second


def run_control(args):
    profile_path = Path(args.profile).expanduser().resolve()
    base_profile = load_profile_optional(profile_path)
    adaptive_memory = AdaptiveGestureMemory(
        Path(args.adaptive_memory).expanduser().resolve(),
        enabled=not args.no_adaptive_learning,
        max_samples=args.adaptive_max_samples,
        min_conf=args.adaptive_min_conf,
        save_seconds=args.adaptive_save_seconds,
    )
    adaptive_profile = adaptive_memory.to_profile()
    profile = build_profile_ensemble(base_profile, adaptive_profile)
    last_adaptive_rebuild = 0.0

    # Arreglo amable para Fedora: si existe el socket común, úsalo automáticamente.
    if "YDOTOOL_SOCKET" not in os.environ and Path("/tmp/.ydotool_socket").exists():
        os.environ["YDOTOOL_SOCKET"] = "/tmp/.ydotool_socket"

    cap = open_camera(args.camera, args.width, args.height, args.fps)
    enhancer = LowLightEnhancer(enabled=not args.no_low_light)
    states: Dict[str, HandState] = {}
    actions = ActionRunner(dry_run=args.dry_run)
    hold_toggle = HoldTimer()
    hold_mode = HoldTimer()
    two_hand_distance = TwoHandDistanceTracker()

    modes = ["NAVEGADOR", "CURSOR", "VENTANAS", "SISTEMA"]
    mode_index = 0
    control_enabled = False

    last_toggle_time = 0.0
    last_fist_time = 0.0
    last_action_time = 0.0
    last_tab_time = 0.0
    last_big_time = 0.0
    last_mode_time = 0.0
    last_pinch_time = 0.0
    last_modifier_time = 0.0
    last_action_label = "-"

    pinch_active = False
    pinch_started_at = 0.0
    drag_active = False

    cv2.namedWindow(APP_NAME, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(APP_NAME, args.width, args.height)
    notifier = StatusNotifier(enabled=not args.no_status_window, backend=args.status_backend)

    print(f"\n[{APP_NAME}] Ejecutando")
    print(f"Perfil base: {profile_path if base_profile else 'sin perfil base, reglas geométricas'}")
    print(f"Memoria adaptativa: {adaptive_memory.path if adaptive_memory.enabled else 'apagada'}")
    print("- Palma abierta sostenida: ON/OFF más seguro")
    print("- Dos manos: zoom, workspaces, volumen y acciones modificadoras")
    print("- Ventana 'Tletl Estado': muestra modo/activo/acción")
    print("- Puño: emergencia")
    print("- Q: salir")
    if args.dry_run:
        print("- DRY RUN: no manda teclas reales")

    prev_time = time.time()

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=2,
        model_complexity=args.model_complexity,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands_model:
        while True:
            ok, raw_frame = cap.read()
            if not ok:
                print("[ERROR] No pude leer frame de cámara.")
                break

            now = time.time()
            fps = 1.0 / max(now - prev_time, 0.0001)
            prev_time = now

            frame, detected = detect_hands(raw_frame, hands_model, states, enhancer, profile, args)

            # Auto-calibración continua: guarda muestras buenas y reconstruye perfil adaptativo.
            if adaptive_memory.enabled:
                for learned_hand in detected:
                    adaptive_memory.observe(learned_hand)
                if now - last_adaptive_rebuild > max(args.adaptive_rebuild_seconds, 1.0):
                    adaptive_profile = adaptive_memory.to_profile()
                    profile = build_profile_ensemble(base_profile, adaptive_profile)
                    adaptive_memory.save_if_needed()
                    last_adaptive_rebuild = now

            main, second = choose_main_hand(detected)
            mode = modes[mode_index]
            toggle_progress = 0.0
            mode_progress = 0.0
            cursor_info = ""

            # ==========================
            # EMERGENCIA: cualquier puño claro apaga.
            # Dos puños también suelta drag.
            # ==========================
            if detected and any_hand_with(detected, "FIST") and control_enabled and now - last_fist_time > FIST_COOLDOWN:
                if drag_active:
                    actions.mouse_up_left()
                drag_active = False
                pinch_active = False
                control_enabled = False
                last_fist_time = now
                last_action_label = "Pausa de seguridad"
                print("[TLETL] Pausa de seguridad. Control OFF.")

            # ==========================
            # TOGGLE con palma sostenida.
            # Para apagar requiere más tiempo que para prender.
            # ==========================
            if main and main.stable_gesture == "OPEN_PALM" and not (second and second.stable_gesture == "OPEN_PALM"):
                required = TOGGLE_HOLD_OFF_SECONDS if control_enabled else TOGGLE_HOLD_ON_SECONDS
                toggle_progress = hold_toggle.progress("OPEN_PALM", required)
                if toggle_progress >= 1.0 and now - last_toggle_time > TOGGLE_COOLDOWN:
                    control_enabled = not control_enabled
                    last_toggle_time = now
                    hold_toggle.reset()
                    for st in states.values():
                        st.stable.clear()
                        st.motion.reset()
                    last_action_label = "Control ON" if control_enabled else "Control OFF"
                    print(f"[TLETL] Control: {'ON' if control_enabled else 'OFF'}")
            else:
                hold_toggle.reset()

            # ==========================
            # Dos palmas sostenidas: toggle maestro, todavía más intencional.
            # ==========================
            if len(detected) >= 2 and both_stable(detected, "OPEN_PALM"):
                required = 1.20 if not control_enabled else 2.45
                toggle_progress = max(toggle_progress, hold_toggle.progress("BOTH_OPEN", required))
                if toggle_progress >= 1.0 and now - last_toggle_time > TOGGLE_COOLDOWN:
                    control_enabled = not control_enabled
                    last_toggle_time = now
                    hold_toggle.reset()
                    last_action_label = "Toggle dos manos"
                    print(f"[TLETL] Control dos manos: {'ON' if control_enabled else 'OFF'}")

            # ==========================
            # Modo: tres dedos sostenidos.
            # ==========================
            if control_enabled and main and main.stable_gesture == "THREE":
                mode_progress = hold_mode.progress("THREE", MODE_HOLD_SECONDS)
                if mode_progress >= 1.0 and now - last_mode_time > 1.0:
                    if drag_active:
                        actions.mouse_up_left()
                    drag_active = False
                    pinch_active = False
                    mode_index = (mode_index + 1) % len(modes)
                    last_mode_time = now
                    hold_mode.reset()
                    for st in states.values():
                        st.stable.clear()
                        st.motion.reset()
                        st.cursor.reset()
                    mode = modes[mode_index]
                    last_action_label = f"Modo {mode}"
                    print(f"[TLETL] Modo: {mode}")
            else:
                hold_mode.reset()

            # ==========================
            # ACCIONES
            # ==========================
            if control_enabled and main:
                swipe = main.swipe
                modifier_open = second is not None and second.stable_gesture == "OPEN_PALM"
                two_hands_open = len(detected) >= 2 and detected[0].stable_gesture == "OPEN_PALM" and detected[1].stable_gesture == "OPEN_PALM"
                two_victory = len(detected) >= 2 and detected[0].stable_gesture == "VICTORY" and detected[1].stable_gesture == "VICTORY"

                # Dos manos abiertas: zoom por distancia.
                if len(detected) >= 2 and two_hands_open:
                    c1 = (detected[0].center_x, detected[0].center_y)
                    c2 = (detected[1].center_x, detected[1].center_y)
                    two_hand_distance.update(c1, c2)
                    zoom = two_hand_distance.spread_or_pinch()
                    if zoom == "SPREAD" and now - last_big_time > BIG_ACTION_COOLDOWN:
                        actions.zoom_in()
                        last_big_time = now
                        last_action_label = "Zoom + dos manos"
                        print("[TLETL] Zoom In dos manos")
                    elif zoom == "PINCH_IN" and now - last_big_time > BIG_ACTION_COOLDOWN:
                        actions.zoom_out()
                        last_big_time = now
                        last_action_label = "Zoom - dos manos"
                        print("[TLETL] Zoom Out dos manos")
                else:
                    two_hand_distance.reset()

                # Dos victorias con swipe: cambiar workspace.
                if two_victory:
                    swipes = {h.swipe for h in detected[:2] if h.swipe}
                    if "RIGHT" in swipes and now - last_big_time > BIG_ACTION_COOLDOWN:
                        actions.workspace_next()
                        last_big_time = now
                        last_action_label = "Workspace siguiente"
                        print("[TLETL] Workspace siguiente")
                    elif "LEFT" in swipes and now - last_big_time > BIG_ACTION_COOLDOWN:
                        actions.workspace_prev()
                        last_big_time = now
                        last_action_label = "Workspace anterior"
                        print("[TLETL] Workspace anterior")

                # Mano secundaria como modificador: palma secundaria + gestos principales.
                if modifier_open and now - last_modifier_time > 0.55:
                    if main.stable_gesture == "POINT" and main.center_y < UP_ZONE:
                        actions.volume_up()
                        last_modifier_time = now
                        last_action_label = "Volumen +"
                    elif main.stable_gesture == "POINT" and main.center_y > DOWN_ZONE:
                        actions.volume_down()
                        last_modifier_time = now
                        last_action_label = "Volumen -"
                    elif main.action_gesture == "PINCH":
                        actions.click_right()
                        last_modifier_time = now
                        last_action_label = "Click derecho"

                if mode == "NAVEGADOR":
                    # Navegación normal.
                    if main.stable_gesture == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab_time > TAB_ACTION_COOLDOWN:
                        if swipe == "RIGHT":
                            actions.next_tab(); last_action_label = "Siguiente pestaña"
                        else:
                            actions.previous_tab(); last_action_label = "Pestaña anterior"
                        print(f"[TLETL] {last_action_label}")
                        last_tab_time = now
                    elif main.stable_gesture == "OPEN_PALM" and swipe in {"LEFT", "RIGHT"} and toggle_progress < 0.55 and now - last_tab_time > TAB_ACTION_COOLDOWN:
                        if swipe == "LEFT":
                            actions.browser_back(); last_action_label = "Atrás"
                        else:
                            actions.browser_forward(); last_action_label = "Adelante"
                        print(f"[TLETL] {last_action_label}")
                        last_tab_time = now
                    elif main.stable_gesture == "POINT" and now - last_action_time > ACTION_COOLDOWN:
                        if main.center_y < EXTREME_UP_ZONE:
                            actions.page_up(); last_action_time = now + 0.18; last_action_label = "PageUp"
                        elif main.center_y > EXTREME_DOWN_ZONE:
                            actions.page_down(); last_action_time = now + 0.18; last_action_label = "PageDown"
                        elif main.center_y < UP_ZONE:
                            actions.scroll_up_small(); last_action_time = now; last_action_label = "Scroll arriba"
                        elif main.center_y > DOWN_ZONE:
                            actions.scroll_down_small(); last_action_time = now; last_action_label = "Scroll abajo"
                    elif main.action_gesture == "PINCH" and now - last_pinch_time > 0.36:
                        actions.click_left(); last_pinch_time = now; last_action_label = "Click izquierdo"

                elif mode == "CURSOR":
                    # Cursor controlado por mano principal. La secundaria puede ser modificador.
                    state = states.get(main.label)
                    if state and main.action_gesture in {"POINT", "OPEN_PALM", "PINCH"}:
                        dx, dy = state.cursor.update(main.center_x, main.center_y, velocity=main.speed)
                        if dx or dy:
                            actions.mousemove_relative(dx, dy)
                            cursor_info = f"Mouse dx={dx} dy={dy} vel={main.speed:.2f}"
                    elif state:
                        state.cursor.reset()

                    if main.action_gesture == "PINCH" and not modifier_open:
                        if not pinch_active:
                            pinch_active = True
                            pinch_started_at = now
                        if not drag_active and now - pinch_started_at >= DRAG_START_SECONDS:
                            actions.mouse_down_left()
                            drag_active = True
                            last_action_label = "Drag ON"
                            print("[TLETL] Drag ON / seleccionar")
                    else:
                        if pinch_active:
                            held = now - pinch_started_at
                            if drag_active:
                                actions.mouse_up_left()
                                last_action_label = "Drag OFF"
                                print("[TLETL] Drag OFF / soltar")
                            elif held <= CLICK_MAX_SECONDS and now - last_pinch_time > 0.23:
                                actions.click_left()
                                last_pinch_time = now
                                last_action_label = "Click izquierdo"
                            pinch_active = False
                            drag_active = False

                    if main.stable_gesture == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab_time > TAB_ACTION_COOLDOWN:
                        if swipe == "RIGHT":
                            actions.next_tab(); last_action_label = "Siguiente pestaña"
                        else:
                            actions.previous_tab(); last_action_label = "Pestaña anterior"
                        last_tab_time = now

                elif mode == "VENTANAS":
                    if main.stable_gesture == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab_time > TAB_ACTION_COOLDOWN:
                        if swipe == "RIGHT":
                            actions.alt_tab(); last_action_label = "Alt+Tab"
                        else:
                            actions.alt_shift_tab(); last_action_label = "Alt+Shift+Tab"
                        print(f"[TLETL] {last_action_label}")
                        last_tab_time = now
                    elif main.stable_gesture == "OPEN_PALM" and swipe == "UP" and now - last_big_time > BIG_ACTION_COOLDOWN:
                        actions.overview(); last_big_time = now; last_action_label = "Overview"
                    elif main.action_gesture == "PINCH" and now - last_pinch_time > 0.36:
                        actions.enter(); last_pinch_time = now; last_action_label = "Enter"

                elif mode == "SISTEMA":
                    if main.stable_gesture == "POINT" and now - last_action_time > 0.30:
                        if main.center_y < UP_ZONE:
                            actions.volume_up(); last_action_time = now; last_action_label = "Volumen +"
                        elif main.center_y > DOWN_ZONE:
                            actions.volume_down(); last_action_time = now; last_action_label = "Volumen -"
                    elif main.action_gesture == "PINCH" and now - last_pinch_time > 0.45:
                        actions.enter(); last_pinch_time = now; last_action_label = "Enter"
                    elif main.stable_gesture == "OPEN_PALM" and swipe == "UP" and now - last_big_time > BIG_ACTION_COOLDOWN:
                        actions.overview(); last_big_time = now; last_action_label = "Overview"

            else:
                if drag_active:
                    actions.mouse_up_left()
                drag_active = False
                pinch_active = False
                two_hand_distance.reset()

            # UI principal.
            draw_zones(frame)
            status = "ON" if control_enabled else "OFF"
            color = (0, 255, 0) if control_enabled else (0, 0, 255)
            lines = [
                f"TLETL V3.6 PRO: {status} | MODO: {mode} | FPS: {fps:.1f} | Manos: {len(detected)}",
                f"Principal: {hand_summary(main)} | Swipe: {main.swipe if main else '-'}",
                f"Secundaria: {hand_summary(second)} | Accion: {last_action_label}",
                f"Baja luz: {enhancer.last_mode} | Luma: {enhancer.last_luma:.0f} | Perfil: {'OK' if base_profile else 'reglas'} | Learn: {adaptive_memory.short_counts()}",
                "Palma hold=ON/OFF lento | Tres dedos=modo | Puño=emergencia | Q=salir",
            ]
            if mode == "NAVEGADOR":
                lines.append("NAVEGADOR: indice=scroll | victoria swipe=tabs | palma swipe=atras/adelante | dos palmas=zoom")
            elif mode == "CURSOR":
                drag_text = "DRAG ACTIVO" if drag_active else "pinza corta=click, pinza sostenida=seleccionar"
                lines.append(f"CURSOR: indice/palma/pinza mueve mouse | {drag_text} | palma secundaria+pinza=click derecho")
                if cursor_info:
                    lines.append(cursor_info)
            elif mode == "VENTANAS":
                lines.append("VENTANAS: victoria swipe=AltTab | dos victorias swipe=workspace | palma arriba=overview")
            else:
                lines.append("SISTEMA: indice arriba/abajo=volumen | pinza=Enter | palma arriba=overview")
            if toggle_progress > 0:
                lines.append(f"Mantén palma para toggle: {int(toggle_progress * 100)}%")
            if mode_progress > 0:
                lines.append(f"Mantén tres dedos para cambiar modo: {int(mode_progress * 100)}%")

            draw_text_box(frame, lines)
            cv2.circle(frame, (frame.shape[1] - 35, 35), 17, color, -1)
            if toggle_progress > 0:
                draw_progress_bar(frame, toggle_progress, y_offset=60, color=(0, 220, 120))
            if mode_progress > 0:
                draw_progress_bar(frame, mode_progress, y_offset=90, color=(255, 180, 0))

            # Ventana extra de estado.
            notifier.update({
                "active": control_enabled,
                "mode": mode,
                "hands": len(detected),
                "fps": fps,
                "main_gesture": hand_summary(main),
                "second_gesture": hand_summary(second),
                "last_action": last_action_label,
                "luma": enhancer.last_luma,
                "light_mode": enhancer.last_mode,
                "adaptive": adaptive_memory.short_counts(),
            })

            cv2.imshow(APP_NAME, frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                if drag_active:
                    actions.mouse_up_left()
                break

    adaptive_memory.save_if_needed(force=True)
    notifier.close()
    cap.release()
    cv2.destroyAllWindows()
    print("[TLETL] Cerrado.")


# ============================================================
# ARGUMENTOS
# ============================================================

def build_arg_parser():
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--profile", default=DEFAULT_PROFILE_PATH, help="Perfil JSON de V3.4. Si no existe, usa reglas.")
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--width", type=int, default=CAMERA_WIDTH)
    parser.add_argument("--height", type=int, default=CAMERA_HEIGHT)
    parser.add_argument("--fps", type=int, default=CAMERA_FPS)
    parser.add_argument("--det-conf", type=float, default=MIN_DETECTION_CONFIDENCE)
    parser.add_argument("--track-conf", type=float, default=MIN_TRACKING_CONFIDENCE)
    parser.add_argument("--model-complexity", type=int, default=MODEL_COMPLEXITY)
    parser.add_argument("--dry-run", action="store_true", help="No manda acciones reales, solo imprime comandos.")
    parser.add_argument("--no-low-light", action="store_true", help="Desactiva mejora de baja luz.")
    parser.add_argument("--no-status-window", action="store_true", help="Oculta la ventana extra de estado.")
    parser.add_argument("--status-backend", choices=["auto", "tk", "cv2", "off"], default="auto", help="Backend de ventana de estado/notificación.")
    parser.add_argument("--no-adaptive-learning", action="store_true", help="Desactiva auto-calibración continua.")
    parser.add_argument("--adaptive-memory", default=DEFAULT_ADAPTIVE_MEMORY_PATH, help="Archivo JSON de memoria adaptativa.")
    parser.add_argument("--adaptive-min-conf", type=float, default=0.78, help="Confianza mínima para aprender muestras nuevas.")
    parser.add_argument("--adaptive-max-samples", type=int, default=240, help="Muestras máximas por gesto en memoria adaptativa.")
    parser.add_argument("--adaptive-save-seconds", type=float, default=5.0, help="Cada cuántos segundos guardar memoria adaptativa.")
    parser.add_argument("--adaptive-rebuild-seconds", type=float, default=4.0, help="Cada cuántos segundos reconstruir perfil adaptativo.")
    parser.add_argument("--history", type=int, default=GESTURE_HISTORY_SIZE)
    parser.add_argument("--stable-count", type=int, default=STABLE_GESTURE_MIN_COUNT)
    parser.add_argument("--motion-history", type=int, default=9)
    parser.add_argument("--slow-alpha", type=float, default=SMOOTHING_SLOW_ALPHA)
    parser.add_argument("--fast-alpha", type=float, default=SMOOTHING_FAST_ALPHA)
    parser.add_argument("--fast-threshold", type=float, default=FAST_MOTION_THRESHOLD)
    parser.add_argument("--cursor-gain", type=int, default=CURSOR_GAIN)
    parser.add_argument("--cursor-max-step", type=int, default=CURSOR_MAX_STEP)
    parser.add_argument("--cursor-deadzone", type=float, default=CURSOR_DEADZONE)
    return parser


def main():
    args = build_arg_parser().parse_args()
    try:
        run_control(args)
    except KeyboardInterrupt:
        print("\n[TLETL] Interrumpido.")
    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        print("Tips: prueba --camera 1, baja --width 640 --height 480, o ejecuta con --dry-run.")


if __name__ == "__main__":
    main()
