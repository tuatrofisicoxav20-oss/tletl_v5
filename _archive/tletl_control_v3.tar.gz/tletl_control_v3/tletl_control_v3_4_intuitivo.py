
#!/usr/bin/env python3
"""
Tletl Control V3.4 Intuitivo
Control por gestos para Fedora / navegador usando OpenCV + MediaPipe + ydotool.

Modos:
  1) Calibrar:
       python tletl_control_v3_calibrado.py --calibrate

  2) Ejecutar:
       python tletl_control_v3_calibrado.py

  3) Probar sin mandar teclas:
       python tletl_control_v3_calibrado.py --dry-run

Requisitos:
  pip install opencv-python mediapipe numpy
  sudo dnf install -y ydotool
  sudo systemctl enable --now ydotool
"""

import argparse
import json
import math
import os
import subprocess
import sys
import time
from collections import Counter, deque
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any

import cv2
import mediapipe as mp


# ============================================================
# CONFIGURACIÓN GENERAL
# ============================================================

APP_NAME = "Tletl Control V3.4 Intuitivo"
DEFAULT_PROFILE_PATH = "tletl_profile_v3_4.json"

CAMERA_WIDTH = 1280
CAMERA_HEIGHT = 720
CAMERA_FPS = 30

# MediaPipe Hands clásico. Es ligero y suficiente para esta V3.
MIN_DETECTION_CONFIDENCE = 0.72
MIN_TRACKING_CONFIDENCE = 0.72
MODEL_COMPLEXITY = 1

# Suavizado exponencial. Menor = más suave pero más lento.
SMOOTHING_ALPHA = 0.32

# Estabilidad de gesto. V3.2 es más cómoda: responde antes, pero sigue filtrando ruido.
GESTURE_HISTORY_SIZE = 6
STABLE_GESTURE_MIN_COUNT = 3

# Cooldowns.
TOGGLE_COOLDOWN = 1.4
ACTION_COOLDOWN = 0.18
FIST_COOLDOWN = 0.55
TOGGLE_HOLD_SECONDS = 0.85
TAB_ACTION_COOLDOWN = 0.75
SWIPE_COOLDOWN = 0.80
MODE_HOLD_SECONDS = 0.75
CLICK_MAX_SECONDS = 0.28
DRAG_START_SECONDS = 0.34
CURSOR_GAIN = 1550
CURSOR_MAX_STEP = 65
CURSOR_DEADZONE = 0.006

# Zonas de navegación vertical.
UP_ZONE = 0.40
DOWN_ZONE = 0.60
EXTREME_UP_ZONE = 0.23
EXTREME_DOWN_ZONE = 0.77

# Clasificación por perfil calibrado.
MIN_STD = 0.055
CONFIDENCE_THRESHOLD = 0.24
MARGIN_THRESHOLD = 0.035

# Gestos que se calibran.
CALIBRATION_GESTURES = [
    {
        "id": "OPEN_PALM",
        "name": "PALMA ABIERTA",
        "instruction": "Abre la mano completa, dedos separados de forma natural.",
        "action": "Activa/desactiva el control."
    },
    {
        "id": "FIST",
        "name": "PUÑO",
        "instruction": "Cierra la mano en puño, sin apretar exagerado.",
        "action": "Pausa de seguridad."
    },
    {
        "id": "POINT",
        "name": "ÍNDICE",
        "instruction": "Deja solo el índice extendido, como si señalaras.",
        "action": "PageUp/PageDown según la altura de la mano."
    },
    {
        "id": "VICTORY",
        "name": "VICTORIA",
        "instruction": "Extiende índice y medio, baja anular y meñique.",
        "action": "Siguiente pestaña."
    },
    {
        "id": "PINCH",
        "name": "PINZA",
        "instruction": "Junta suavemente la punta del pulgar con la punta del índice. No cierres todo el puño.",
        "action": "Click, Enter o arrastrar/seleccionar."
    },
    {
        "id": "NEUTRAL",
        "name": "NEUTRAL",
        "instruction": "Mano relajada o gesto que NO deba hacer nada.",
        "action": "Evitar falsos positivos."
    },
]


# ============================================================
# MEDIAPIPE
# ============================================================

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils


# ============================================================
# UTILIDADES MATEMÁTICAS
# ============================================================

class Point:
    __slots__ = ("x", "y", "z")

    def __init__(self, x: float, y: float, z: float):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)


def dist(a: Point, b: Point) -> float:
    return math.sqrt(
        (a.x - b.x) ** 2 +
        (a.y - b.y) ** 2 +
        (a.z - b.z) ** 2
    )


def points_from_landmarks(hand_landmarks) -> List[Point]:
    return [Point(p.x, p.y, p.z) for p in hand_landmarks.landmark]


def palm_scale(lm: List[Point]) -> float:
    # Escala robusta: largo muñeca-base medio + ancho de palma.
    wrist_to_middle = dist(lm[0], lm[9])
    palm_width = dist(lm[5], lm[17])
    return max((wrist_to_middle + palm_width) / 2.0, 0.0001)


def palm_center_y(lm: List[Point]) -> float:
    ids = [0, 5, 9, 13, 17]
    return sum(lm[i].y for i in ids) / len(ids)


def palm_center_x(lm: List[Point]) -> float:
    ids = [0, 5, 9, 13, 17]
    return sum(lm[i].x for i in ids) / len(ids)


# ============================================================
# SUAVIZADO DE LANDMARKS
# ============================================================

class LandmarkSmoother:
    def __init__(self, alpha: float = SMOOTHING_ALPHA):
        self.alpha = alpha
        self.values: Optional[List[List[float]]] = None

    def reset(self):
        self.values = None

    def update(self, raw_points: List[Point]) -> List[Point]:
        if self.values is None:
            self.values = [[p.x, p.y, p.z] for p in raw_points]
        else:
            for i, p in enumerate(raw_points):
                self.values[i][0] = self.alpha * p.x + (1.0 - self.alpha) * self.values[i][0]
                self.values[i][1] = self.alpha * p.y + (1.0 - self.alpha) * self.values[i][1]
                self.values[i][2] = self.alpha * p.z + (1.0 - self.alpha) * self.values[i][2]

        return [Point(x, y, z) for x, y, z in self.values]


# ============================================================
# EXTRACCIÓN DE FEATURES
# ============================================================

FINGERS = {
    "index": (8, 6, 5),
    "middle": (12, 10, 9),
    "ring": (16, 14, 13),
    "pinky": (20, 18, 17),
}


def extract_features(lm: List[Point]) -> Dict[str, float]:
    """
    Convierte los 21 landmarks en números comparables.
    Casi todo se normaliza por tamaño de palma para que no dependa tanto
    de qué tan cerca está la mano de la cámara.
    """
    scale = palm_scale(lm)
    wrist = lm[0]
    features: Dict[str, float] = {}

    # Dedos largos.
    for name, (tip, pip, mcp) in FINGERS.items():
        features[f"{name}_tip_wrist"] = dist(lm[tip], wrist) / scale
        features[f"{name}_pip_wrist"] = dist(lm[pip], wrist) / scale
        features[f"{name}_mcp_wrist"] = dist(lm[mcp], wrist) / scale
        features[f"{name}_tip_mcp"] = dist(lm[tip], lm[mcp]) / scale
        features[f"{name}_tip_pip"] = dist(lm[tip], lm[pip]) / scale
        features[f"{name}_vertical"] = (lm[pip].y - lm[tip].y) / scale
        features[f"{name}_curl"] = (
            dist(lm[tip], wrist) - dist(lm[pip], wrist)
        ) / scale

    # Pulgar.
    features["thumb_tip_wrist"] = dist(lm[4], wrist) / scale
    features["thumb_ip_wrist"] = dist(lm[3], wrist) / scale
    features["thumb_tip_index_mcp"] = dist(lm[4], lm[5]) / scale
    features["thumb_tip_index_tip"] = dist(lm[4], lm[8]) / scale
    features["thumb_tip_middle_tip"] = dist(lm[4], lm[12]) / scale
    features["thumb_horizontal"] = abs(lm[4].x - lm[3].x) / scale
    features["thumb_vertical"] = abs(lm[4].y - lm[3].y) / scale

    # Separación entre dedos.
    features["index_middle_spread"] = dist(lm[8], lm[12]) / scale
    features["middle_ring_spread"] = dist(lm[12], lm[16]) / scale
    features["ring_pinky_spread"] = dist(lm[16], lm[20]) / scale
    features["index_pinky_spread"] = dist(lm[8], lm[20]) / scale

    # Rasgos de palma.
    features["palm_width"] = dist(lm[5], lm[17]) / scale
    features["wrist_middle_mcp"] = dist(lm[0], lm[9]) / scale

    # Posición de la mano en pantalla. No se usa para clasificar gesto base,
    # pero sí para decidir si POINT hace PageUp o PageDown.
    features["palm_center_y"] = palm_center_y(lm)
    features["palm_center_x"] = palm_center_x(lm)

    return features


def classifier_feature_keys(features: Dict[str, float]) -> List[str]:
    # No metemos posición absoluta para que el gesto POINT sirva arriba y abajo.
    excluded = {"palm_center_y", "palm_center_x"}
    return sorted([k for k in features.keys() if k not in excluded])


# ============================================================
# PERFIL CALIBRADO
# ============================================================

def compute_stats(samples: List[Dict[str, float]], keys: List[str]) -> Dict[str, Dict[str, float]]:
    if not samples:
        raise ValueError("No hay muestras para calcular estadísticas.")

    mean: Dict[str, float] = {}
    std: Dict[str, float] = {}

    for key in keys:
        vals = [s[key] for s in samples if key in s]
        if not vals:
            mean[key] = 0.0
            std[key] = 1.0
            continue

        m = sum(vals) / len(vals)
        var = sum((v - m) ** 2 for v in vals) / max(len(vals) - 1, 1)
        mean[key] = m
        std[key] = max(math.sqrt(var), MIN_STD)

    return {"mean": mean, "std": std}


def save_profile(profile: Dict[str, Any], path: Path):
    path.write_text(json.dumps(profile, indent=2, ensure_ascii=False), encoding="utf-8")


def load_profile(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(
            f"No existe el perfil {path}. Primero ejecuta: python {Path(sys.argv[0]).name} --calibrate"
        )
    return json.loads(path.read_text(encoding="utf-8"))


def classify_with_profile(features: Dict[str, float], profile: Dict[str, Any]) -> Tuple[str, float, Dict[str, float]]:
    keys = profile["feature_keys"]
    gestures = profile["gestures"]

    scores: Dict[str, float] = {}

    for gesture_id, data in gestures.items():
        mean = data["mean"]
        std = data["std"]

        total = 0.0
        used = 0

        for key in keys:
            if key not in features:
                continue

            s = max(float(std.get(key, MIN_STD)), MIN_STD)
            m = float(mean.get(key, 0.0))
            z = (features[key] - m) / s
            total += z * z
            used += 1

        if used == 0:
            scores[gesture_id] = 999.0
        else:
            scores[gesture_id] = math.sqrt(total / used)

    ordered = sorted(scores.items(), key=lambda item: item[1])
    best_gesture, best_score = ordered[0]
    second_score = ordered[1][1] if len(ordered) > 1 else 999.0

    confidence = 1.0 / (1.0 + best_score)
    margin = second_score - best_score

    if confidence < CONFIDENCE_THRESHOLD:
        return "UNKNOWN", confidence, scores

    if margin < MARGIN_THRESHOLD:
        return "UNKNOWN", confidence, scores

    return best_gesture, confidence, scores


# ============================================================
# CLASIFICADOR HÍBRIDO V3.2: PERFIL + REGLAS
# ============================================================

def _finger_extended_rule(lm: List[Point], tip: int, pip: int, mcp: int) -> bool:
    """
    Regla geométrica tolerante. No depende de que el perfil sea perfecto.
    Sirve como respaldo cuando la calibración quedó medio rara, porque claro,
    calibrar con webcam debería ser deporte olímpico de paciencia.
    """
    scale = palm_scale(lm)
    wrist = lm[0]
    vertical = (lm[pip].y - lm[tip].y) > 0.012
    length = (dist(lm[tip], wrist) - dist(lm[pip], wrist)) > (0.045 * scale)
    tip_far_from_mcp = dist(lm[tip], lm[mcp]) > (0.42 * scale)
    return (vertical and length) or (vertical and tip_far_from_mcp)


def _thumb_open_rule(lm: List[Point]) -> bool:
    scale = palm_scale(lm)
    return dist(lm[4], lm[5]) > 0.45 * scale and dist(lm[4], lm[8]) > 0.30 * scale


def pinch_ratio(lm: List[Point]) -> float:
    """
    Distancia pulgar-índice normalizada por palma.
    Más bajo = pinza más clara.
    """
    return dist(lm[4], lm[8]) / palm_scale(lm)


def _pinch_rule(lm: List[Point]) -> bool:
    """
    Pinza más cómoda y tolerante.

    La V3.3 fallaba porque pedía que el índice siguiera "extendido".
    En una pinza real el índice se dobla, así que esa condición era una
    estupidez geométrica con confianza injustificada. Aquí detectamos contacto
    pulgar-índice y evitamos confundirlo con puño completo.
    """
    scale = palm_scale(lm)

    thumb_index = dist(lm[4], lm[8]) / scale
    thumb_middle = dist(lm[4], lm[12]) / scale
    thumb_ring = dist(lm[4], lm[16]) / scale

    # En una pinza, pulgar e índice están cerca y normalmente son la pareja más cercana.
    close_enough = thumb_index < 0.46
    tight = thumb_index < 0.34
    index_is_closest = thumb_index < min(thumb_middle * 0.90, thumb_ring * 0.88)

    # Evita que un puño cerrado se lea como pinza: el índice debe seguir saliendo
    # algo de la palma, aunque esté curvado.
    index_tip_mcp = dist(lm[8], lm[5]) / scale
    index_tip_pip = dist(lm[8], lm[6]) / scale
    thumb_tip_to_palm = dist(lm[4], lm[9]) / scale
    not_full_fist = index_tip_mcp > 0.28 or index_tip_pip > 0.18 or thumb_tip_to_palm > 0.42

    return (tight or (close_enough and index_is_closest)) and not_full_fist


def rule_fingers(lm: List[Point]) -> Dict[str, bool]:
    return {
        "thumb": _thumb_open_rule(lm),
        "index": _finger_extended_rule(lm, 8, 6, 5),
        "middle": _finger_extended_rule(lm, 12, 10, 9),
        "ring": _finger_extended_rule(lm, 16, 14, 13),
        "pinky": _finger_extended_rule(lm, 20, 18, 17),
    }


def classify_by_rules(lm: List[Point]) -> Tuple[str, float, Dict[str, bool]]:
    f = rule_fingers(lm)
    long_count = sum([f["index"], f["middle"], f["ring"], f["pinky"]])
    total = long_count + int(f["thumb"])

    # Pinza se revisa primero. En una pinza real el índice puede estar curvado,
    # así que NO exigimos f["index"]. Eso era justo lo que hacía que no detectara.
    pr = pinch_ratio(lm)
    if _pinch_rule(lm):
        # Confianza más alta mientras más cerca estén pulgar e índice.
        conf = max(0.62, min(0.94, 1.04 - pr))
        return "PINCH", conf, f

    if long_count >= 4:
        return "OPEN_PALM", 0.78, f

    if long_count == 0 and not f["thumb"]:
        return "FIST", 0.78, f

    if f["index"] and not f["middle"] and not f["ring"] and not f["pinky"]:
        return "POINT", 0.74, f

    if f["index"] and f["middle"] and f["ring"] and not f["pinky"]:
        return "THREE", 0.72, f

    if f["index"] and f["middle"] and not f["ring"] and not f["pinky"]:
        return "VICTORY", 0.74, f

    # Mano relajada o gesto raro. Mejor no hacer nada que obedecer basura visual.
    if total <= 2:
        return "NEUTRAL", 0.55, f

    return "UNKNOWN", 0.0, f


def classify_hybrid(points: List[Point], features: Dict[str, float], profile: Dict[str, Any]) -> Tuple[str, float, str, Dict[str, bool]]:
    """
    Combina calibración y reglas:
    - Si ambos coinciden, confianza alta.
    - Si el perfil duda, la regla manda.
    - Si la regla ve FIST, OPEN_PALM o POINT claramente, no dejamos que el perfil se ponga exquisito.
    """
    profile_gesture, profile_conf, _scores = classify_with_profile(features, profile)
    rule_gesture, rule_conf, fingers = classify_by_rules(points)

    # Pinza debe ser rápida. Si la regla la ve clara, no esperamos a que el perfil
    # calibrado opine, porque el click/drag se siente horrible con retraso.
    if rule_gesture == "PINCH" and rule_conf >= 0.62:
        return "PINCH", rule_conf, "regla-pinza", fingers

    if profile_gesture == rule_gesture and profile_gesture != "UNKNOWN":
        return profile_gesture, min(1.0, max(profile_conf, rule_conf) + 0.12), "perfil+regla", fingers

    if rule_gesture in {"FIST", "OPEN_PALM", "POINT", "VICTORY", "PINCH", "THREE"} and profile_conf < 0.52:
        return rule_gesture, rule_conf, "regla", fingers

    if profile_gesture != "UNKNOWN" and profile_conf >= 0.33:
        return profile_gesture, profile_conf, "perfil", fingers

    if rule_gesture != "UNKNOWN":
        return rule_gesture, rule_conf, "regla", fingers

    return "UNKNOWN", 0.0, "ninguno", fingers


# ============================================================
# ESTABILIZADOR DE GESTOS
# ============================================================

class StableGestureFilter:
    def __init__(self, size: int = GESTURE_HISTORY_SIZE, min_count: int = STABLE_GESTURE_MIN_COUNT):
        self.history = deque(maxlen=size)
        self.min_count = min_count

    def clear(self):
        self.history.clear()

    def update(self, gesture: str) -> str:
        self.history.append(gesture)

        if len(self.history) < self.history.maxlen:
            return "WAITING"

        counts = Counter(self.history)
        gesture, amount = counts.most_common(1)[0]

        if gesture == "UNKNOWN":
            return "UNKNOWN"

        if amount >= self.min_count:
            return gesture

        return "UNSTABLE"


class MotionTracker:
    """Detecta swipe izquierda/derecha/arriba/abajo y velocidad básica."""
    def __init__(self, maxlen: int = 12):
        self.points = deque(maxlen=maxlen)  # (t, x, y)
        self.last_swipe_time = 0.0

    def reset(self):
        self.points.clear()

    def update(self, x: float, y: float):
        self.points.append((time.time(), x, y))

    def swipe(self) -> Optional[str]:
        if len(self.points) < 6:
            return None

        now = time.time()
        if now - self.last_swipe_time < SWIPE_COOLDOWN:
            return None

        t0, x0, y0 = self.points[0]
        t1, x1, y1 = self.points[-1]
        dt = max(t1 - t0, 0.001)
        dx = x1 - x0
        dy = y1 - y0

        # Swipe horizontal intencional.
        if dt <= 0.85 and abs(dx) > 0.16 and abs(dx) > abs(dy) * 1.65:
            self.last_swipe_time = now
            self.points.clear()
            return "RIGHT" if dx > 0 else "LEFT"

        # Swipe vertical intencional. En coordenadas de imagen, y mayor = abajo.
        if dt <= 0.85 and abs(dy) > 0.16 and abs(dy) > abs(dx) * 1.65:
            self.last_swipe_time = now
            self.points.clear()
            return "DOWN" if dy > 0 else "UP"

        return None


class CursorController:
    """Convierte movimiento de mano normalizado en movimiento relativo del mouse."""
    def __init__(self, gain: int = CURSOR_GAIN, max_step: int = CURSOR_MAX_STEP, deadzone: float = CURSOR_DEADZONE):
        self.prev: Optional[Tuple[float, float]] = None
        self.gain = gain
        self.max_step = max_step
        self.deadzone = deadzone

    def reset(self):
        self.prev = None

    def update(self, x: float, y: float) -> Tuple[int, int]:
        if self.prev is None:
            self.prev = (x, y)
            return 0, 0

        px, py = self.prev
        dx_norm = x - px
        dy_norm = y - py
        self.prev = (x, y)

        if abs(dx_norm) < self.deadzone:
            dx_norm = 0.0
        if abs(dy_norm) < self.deadzone:
            dy_norm = 0.0

        dx = int(max(-self.max_step, min(self.max_step, dx_norm * self.gain)))
        dy = int(max(-self.max_step, min(self.max_step, dy_norm * self.gain)))
        return dx, dy


class HoldTimer:
    """Sirve para activar/desactivar con palma abierta sostenida, no por accidente."""
    def __init__(self):
        self.gesture: Optional[str] = None
        self.started_at = 0.0

    def reset(self):
        self.gesture = None
        self.started_at = 0.0

    def progress(self, gesture: str, required_seconds: float) -> float:
        now = time.time()
        if self.gesture != gesture:
            self.gesture = gesture
            self.started_at = now
        return min(1.0, (now - self.started_at) / max(required_seconds, 0.001))


# ============================================================
# ACCIONES CON YDOTOOL
# ============================================================

class ActionRunner:
    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run

    def _run(self, cmd: List[str], label: str):
        if self.dry_run:
            print(f"[DRY-RUN] {label}: {' '.join(cmd)}")
            return

        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        except Exception as exc:
            print(f"[ERROR ydotool] {exc}")

    def key(self, sequence: str, label: str):
        self._run(["ydotool", "key"] + sequence.split(), label)

    def mousemove_relative(self, dx: int, dy: int):
        if dx == 0 and dy == 0:
            return
        self._run(["ydotool", "mousemove", "-x", str(dx), "-y", str(dy)], f"MouseMove {dx},{dy}")

    def click_left(self):
        self._run(["ydotool", "click", "0xC0"], "Left Click")

    def click_right(self):
        self._run(["ydotool", "click", "0xC1"], "Right Click")

    def mouse_down_left(self):
        self._run(["ydotool", "click", "0x40"], "Left Mouse Down")

    def mouse_up_left(self):
        self._run(["ydotool", "click", "0x80"], "Left Mouse Up")

    def page_down(self):
        self.key("109:1 109:0", "PageDown")

    def page_up(self):
        self.key("104:1 104:0", "PageUp")

    def next_tab(self):
        self.key("29:1 15:1 15:0 29:0", "Ctrl+Tab")

    def previous_tab(self):
        self.key("29:1 42:1 15:1 15:0 42:0 29:0", "Ctrl+Shift+Tab")

    def scroll_down_small(self):
        self.key("108:1 108:0", "ArrowDown")

    def scroll_up_small(self):
        self.key("103:1 103:0", "ArrowUp")

    def browser_back(self):
        self.key("56:1 105:1 105:0 56:0", "Alt+Left")

    def browser_forward(self):
        self.key("56:1 106:1 106:0 56:0", "Alt+Right")

    def alt_tab(self):
        self.key("56:1 15:1 15:0 56:0", "Alt+Tab")

    def alt_shift_tab(self):
        self.key("56:1 42:1 15:1 15:0 42:0 56:0", "Alt+Shift+Tab")

    def overview(self):
        # KEY_LEFTMETA / Super = 125. En GNOME normalmente abre la vista general.
        self.key("125:1 125:0", "Super / Overview")

    def escape(self):
        self.key("1:1 1:0", "Escape")

    def enter(self):
        self.key("28:1 28:0", "Enter")


# ============================================================
# CÁMARA
# ============================================================

def open_camera(index: int, width: int, height: int, fps: int):
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"No pude abrir la cámara index={index}. Prueba con --camera 1 o --camera 2.")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def draw_text_box(frame, lines: List[str], origin=(18, 18), font_scale=0.62):
    x, y = origin
    line_h = 30
    width = min(frame.shape[1] - 30, 900)
    height = 22 + line_h * len(lines)
    cv2.rectangle(frame, (x - 8, y - 8), (x + width, y + height), (0, 0, 0), -1)

    for i, line in enumerate(lines):
        cv2.putText(
            frame,
            line,
            (x, y + 22 + i * line_h),
            cv2.FONT_HERSHEY_SIMPLEX,
            font_scale,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )


def draw_zones(frame):
    h, w = frame.shape[:2]
    y_up = int(h * UP_ZONE)
    y_down = int(h * DOWN_ZONE)
    cv2.line(frame, (0, y_up), (w, y_up), (255, 255, 0), 2)
    cv2.line(frame, (0, y_down), (w, y_down), (255, 255, 0), 2)


def read_hand_frame(cap, hands, smoother: LandmarkSmoother):
    ok, frame = cap.read()
    if not ok:
        return None, None, None, None

    frame = cv2.flip(frame, 1)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb)

    if not result.multi_hand_landmarks:
        smoother.reset()
        return frame, None, None, None

    raw_landmarks = result.multi_hand_landmarks[0]
    raw_points = points_from_landmarks(raw_landmarks)
    smooth_points = smoother.update(raw_points)

    handedness = "Unknown"
    if result.multi_handedness:
        handedness = result.multi_handedness[0].classification[0].label

    return frame, raw_landmarks, smooth_points, handedness


# ============================================================
# CALIBRACIÓN POR INTERFAZ
# ============================================================

def wait_ui_key(delay: int = 1) -> int:
    """Lee tecla desde la ventana de OpenCV."""
    return cv2.waitKey(delay) & 0xFF


def draw_progress_bar(frame, progress: float, y_offset: int = 38):
    """Barra de progreso simple para captura."""
    h, w = frame.shape[:2]
    x1, x2 = 24, w - 24
    y = h - y_offset
    cv2.rectangle(frame, (x1, y - 12), (x2, y + 12), (40, 40, 40), -1)
    filled = int((x2 - x1) * max(0.0, min(1.0, progress)))
    cv2.rectangle(frame, (x1, y - 12), (x1 + filled, y + 12), (0, 220, 120), -1)
    cv2.rectangle(frame, (x1, y - 12), (x2, y + 12), (255, 255, 255), 2)


def show_calibration_screen(
    frame,
    gesture,
    index: int,
    total: int,
    state: str,
    samples_count: int = 0,
    min_samples: int = 0,
    extra_lines: Optional[List[str]] = None,
    progress: float = 0.0,
):
    """Dibuja toda la UI de calibración dentro de la ventana de cámara."""
    lines = [
        f"TLETL V3.2 CALIBRACION UI  |  Gesto {index + 1}/{total}",
        f"GESTO: {gesture['name']}",
        gesture["instruction"],
        f"Uso: {gesture['action']}",
        f"Estado: {state}",
    ]

    if min_samples:
        lines.append(f"Muestras: {samples_count}/{min_samples}")

    if extra_lines:
        lines.extend(extra_lines)

    lines.extend([
        "Controles en ESTA ventana: ESPACIO=iniciar/reintentar | N=saltar | Q=cancelar",
        "Tip: no cambies a terminal; deja esta ventana enfocada. Sí, por fin UX decente.",
    ])

    draw_text_box(frame, lines, origin=(18, 18), font_scale=0.58)
    if progress > 0:
        draw_progress_bar(frame, progress)


def calibrate(args):
    """
    Calibración V3.1:
    - Ya NO usa input() en terminal.
    - Todo se controla desde la ventana de cámara.
    - ESPACIO inicia o reintenta.
    - N salta gesto, solo recomendable si ya tienes perfil previo. Normalmente no lo uses.
    - Q cancela.
    """
    profile_path = Path(args.profile).expanduser().resolve()
    cap = open_camera(args.camera, args.width, args.height, args.fps)
    smoother = LandmarkSmoother(alpha=SMOOTHING_ALPHA)

    all_samples: Dict[str, List[Dict[str, float]]] = {}
    feature_keys: Optional[List[str]] = None

    print(f"\n[{APP_NAME}] Calibración por interfaz iniciada.")
    print("Ya no necesitas alternar terminal/cámara.")
    print("Usa la ventana de cámara: ESPACIO=iniciar, N=saltar, Q=cancelar.\n")

    window_title = APP_NAME + " - Calibracion UI"

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=args.model_complexity,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands:

        for idx, gesture in enumerate(CALIBRATION_GESTURES):
            gesture_id = gesture["id"]
            samples: List[Dict[str, float]] = []
            state = "PREPARATE"
            need_retry = True

            while need_retry:
                smoother.reset()
                samples.clear()

                # Pantalla de preparación: espera ESPACIO desde OpenCV.
                while True:
                    frame, raw_landmarks, points, handedness = read_hand_frame(cap, hands, smoother)
                    if frame is None:
                        raise RuntimeError("No pude leer la cámara durante calibración.")

                    if raw_landmarks is not None:
                        mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)

                    show_calibration_screen(
                        frame,
                        gesture,
                        idx,
                        len(CALIBRATION_GESTURES),
                        state="LISTO PARA CAPTURAR",
                        extra_lines=[
                            "Pon el gesto completo dentro del cuadro.",
                            "Cuando lo tengas cómodo, presiona ESPACIO aquí mismo.",
                        ],
                    )
                    cv2.imshow(window_title, frame)
                    key = wait_ui_key(1)

                    if key == ord("q"):
                        cap.release()
                        cv2.destroyAllWindows()
                        print("[TLETL] Calibración cancelada.")
                        return
                    if key == ord("n"):
                        print(f"[AVISO] Saltaste {gesture_id}. No recomendado si calibras desde cero.")
                        all_samples[gesture_id] = []
                        need_retry = False
                        break
                    if key == 32:  # SPACE
                        break

                if not need_retry:
                    continue

                # Cuenta regresiva visual.
                countdown_start = time.time()
                while time.time() - countdown_start < args.countdown:
                    frame, raw_landmarks, points, handedness = read_hand_frame(cap, hands, smoother)
                    if frame is None:
                        raise RuntimeError("No pude leer la cámara durante calibración.")

                    if raw_landmarks is not None:
                        mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)

                    remaining = args.countdown - (time.time() - countdown_start)
                    show_calibration_screen(
                        frame,
                        gesture,
                        idx,
                        len(CALIBRATION_GESTURES),
                        state=f"INICIA EN {remaining:.1f}s",
                        extra_lines=["Mantén el gesto estable, pero natural."],
                        progress=1.0 - (remaining / max(args.countdown, 0.001)),
                    )
                    cv2.imshow(window_title, frame)
                    key = wait_ui_key(1)
                    if key == ord("q"):
                        cap.release()
                        cv2.destroyAllWindows()
                        print("[TLETL] Calibración cancelada.")
                        return

                # Captura de muestras.
                capture_start = time.time()
                while time.time() - capture_start < args.seconds:
                    frame, raw_landmarks, points, handedness = read_hand_frame(cap, hands, smoother)
                    if frame is None:
                        raise RuntimeError("No pude leer la cámara durante calibración.")

                    if raw_landmarks is not None and points is not None:
                        mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)
                        features = extract_features(points)
                        if feature_keys is None:
                            feature_keys = classifier_feature_keys(features)
                        samples.append(features)

                    elapsed = time.time() - capture_start
                    progress = elapsed / max(args.seconds, 0.001)
                    show_calibration_screen(
                        frame,
                        gesture,
                        idx,
                        len(CALIBRATION_GESTURES),
                        state="CAPTURANDO",
                        samples_count=len(samples),
                        min_samples=args.min_samples,
                        extra_lines=[
                            "No cambies de gesto todavía.",
                            "Si se ve mal, espera a que termine y reintenta con ESPACIO.",
                        ],
                        progress=progress,
                    )
                    cv2.imshow(window_title, frame)
                    key = wait_ui_key(1)
                    if key == ord("q"):
                        cap.release()
                        cv2.destroyAllWindows()
                        print("[TLETL] Calibración cancelada.")
                        return

                # Resultado del gesto.
                if len(samples) >= args.min_samples:
                    all_samples[gesture_id] = list(samples)
                    print(f"[OK] {gesture['name']}: {len(samples)} muestras guardadas.")
                    ok_start = time.time()
                    while time.time() - ok_start < 1.0:
                        frame, raw_landmarks, points, handedness = read_hand_frame(cap, hands, smoother)
                        if frame is None:
                            break
                        if raw_landmarks is not None:
                            mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)
                        show_calibration_screen(
                            frame,
                            gesture,
                            idx,
                            len(CALIBRATION_GESTURES),
                            state="OK, GUARDADO",
                            samples_count=len(samples),
                            min_samples=args.min_samples,
                            extra_lines=["Pasando al siguiente gesto..."],
                            progress=1.0,
                        )
                        cv2.imshow(window_title, frame)
                        wait_ui_key(1)
                    need_retry = False
                else:
                    print(f"[AVISO] {gesture['name']}: solo {len(samples)} muestras. Reintenta desde UI.")
                    while True:
                        frame, raw_landmarks, points, handedness = read_hand_frame(cap, hands, smoother)
                        if frame is None:
                            raise RuntimeError("No pude leer la cámara durante calibración.")
                        if raw_landmarks is not None:
                            mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)
                        show_calibration_screen(
                            frame,
                            gesture,
                            idx,
                            len(CALIBRATION_GESTURES),
                            state="FALTAN MUESTRAS",
                            samples_count=len(samples),
                            min_samples=args.min_samples,
                            extra_lines=[
                                "Mejora luz/distancia y presiona ESPACIO para reintentar.",
                                "La mano debe verse completa. No la pegues tanto a la cámara.",
                            ],
                        )
                        cv2.imshow(window_title, frame)
                        key = wait_ui_key(1)
                        if key == ord("q"):
                            cap.release()
                            cv2.destroyAllWindows()
                            print("[TLETL] Calibración cancelada.")
                            return
                        if key == 32:
                            break

    cap.release()
    cv2.destroyAllWindows()

    # Validación: todos los gestos deben tener muestras.
    missing = [g["id"] for g in CALIBRATION_GESTURES if not all_samples.get(g["id"])]
    if missing:
        raise RuntimeError(
            "No se puede guardar perfil porque faltan gestos: " + ", ".join(missing)
        )

    if feature_keys is None:
        raise RuntimeError("No se pudo crear el perfil: no se capturó ninguna muestra válida.")

    gestures_stats: Dict[str, Dict[str, Any]] = {}
    for gesture_id, samples in all_samples.items():
        stats = compute_stats(samples, feature_keys)
        gestures_stats[gesture_id] = {
            "samples": len(samples),
            "mean": stats["mean"],
            "std": stats["std"],
        }

    profile = {
        "app": APP_NAME + " UI",
        "version": "3.3-acciones",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "feature_keys": feature_keys,
        "gestures": gestures_stats,
        "settings": {
            "smoothing_alpha": SMOOTHING_ALPHA,
            "gesture_history_size": GESTURE_HISTORY_SIZE,
            "stable_gesture_min_count": STABLE_GESTURE_MIN_COUNT,
            "min_std": MIN_STD,
            "confidence_threshold": CONFIDENCE_THRESHOLD,
            "margin_threshold": MARGIN_THRESHOLD,
            "up_zone": UP_ZONE,
            "down_zone": DOWN_ZONE,
        },
    }

    save_profile(profile, profile_path)

    print("\n[TLETL] Perfil calibrado guardado:")
    print(profile_path)
    print("\nAhora prueba primero:")
    print(f"python {Path(sys.argv[0]).name} --profile {profile_path} --dry-run --width 640 --height 480")

# ============================================================
# MODO NORMAL
# ============================================================

def run_control(args):
    profile_path = Path(args.profile).expanduser().resolve()
    try:
        profile = load_profile(profile_path)
    except FileNotFoundError as exc:
        print(f"[ERROR] {exc}")
        print("\nEjecuta primero:")
        print(f"python {Path(sys.argv[0]).name} --calibrate")
        return

    # Arreglo amable para Fedora: si el socket común existe, úsalo sin obligarte a exportar cada vez.
    if "YDOTOOL_SOCKET" not in os.environ and Path("/tmp/.ydotool_socket").exists():
        os.environ["YDOTOOL_SOCKET"] = "/tmp/.ydotool_socket"

    cap = open_camera(args.camera, args.width, args.height, args.fps)
    smoother = LandmarkSmoother(alpha=args.smoothing)
    stable_filter = StableGestureFilter(size=args.history, min_count=args.stable_count)
    motion = MotionTracker()
    cursor = CursorController(gain=args.cursor_gain, max_step=args.cursor_max_step)
    hold = HoldTimer()
    mode_hold = HoldTimer()
    actions = ActionRunner(dry_run=args.dry_run)

    modes = ["NAVEGADOR", "CURSOR", "VENTANAS"]
    mode_index = 0

    control_enabled = False
    last_toggle_time = 0.0
    last_action_time = 0.0
    last_fist_time = 0.0
    last_tab_time = 0.0
    last_pinch_time = 0.0
    last_overview_time = 0.0
    last_mode_time = 0.0

    pinch_active = False
    pinch_started_at = 0.0
    drag_active = False

    print(f"\n[{APP_NAME}] Ejecutando con perfil:")
    print(profile_path)
    print("\nV3.4 Intuitivo:")
    print("- Palma abierta sostenida = ON/OFF")
    print("- Tres dedos sostenidos = cambiar modo: NAVEGADOR -> CURSOR -> VENTANAS")
    print("- Modo NAVEGADOR: índice=scroll, victoria swipe=tabs, palma swipe=atrás/adelante")
    print("- Modo CURSOR: índice/palma mueve mouse, pinza suave=click, pinza sostenida=arrastrar/seleccionar")
    print("- Modo VENTANAS: victoria swipe=Alt+Tab, palma swipe arriba=overview")
    print("- Puño = pausa de seguridad")
    print("- Q en ventana = salir")
    if args.dry_run:
        print("- DRY RUN activo: no mandará teclas reales.\n")

    prev_time = time.time()

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=args.model_complexity,
        min_detection_confidence=args.det_conf,
        min_tracking_confidence=args.track_conf,
    ) as hands:

        while True:
            frame, raw_landmarks, points, handedness = read_hand_frame(cap, hands, smoother)
            if frame is None:
                print("[ERROR] No pude leer frame de la cámara.")
                break

            now = time.time()
            fps = 1.0 / max(now - prev_time, 0.0001)
            prev_time = now

            raw_gesture = "NO_HAND"
            stable_gesture = "NO_HAND"
            action_gesture = "NO_HAND"
            confidence = 0.0
            center_y = None
            center_x = None
            source = "-"
            finger_debug = ""
            toggle_progress = 0.0
            mode_progress = 0.0
            cursor_info = ""

            if raw_landmarks is not None and points is not None:
                mp_draw.draw_landmarks(frame, raw_landmarks, mp_hands.HAND_CONNECTIONS)

                features = extract_features(points)
                center_y = features["palm_center_y"]
                center_x = features["palm_center_x"]
                motion.update(center_x, center_y)

                raw_gesture, confidence, source, fingers = classify_hybrid(points, features, profile)
                stable_gesture = stable_filter.update(raw_gesture)

                # Para gestos de acción rápida, especialmente PINCH, usamos una ruta
                # más directa. Esperar a que pase por todo el historial se siente
                # torpe para click, como usar guantes de box para escribir.
                action_gesture = stable_gesture
                if raw_gesture == "PINCH" and confidence >= 0.60:
                    action_gesture = "PINCH"

                finger_debug = " ".join([k[0].upper() for k, v in fingers.items() if v]) or "cerrada"

                # ==========================
                # ACTIVAR / DESACTIVAR CON HOLD
                # ==========================
                if stable_gesture == "OPEN_PALM":
                    toggle_progress = hold.progress("OPEN_PALM", TOGGLE_HOLD_SECONDS)
                    if toggle_progress >= 1.0 and now - last_toggle_time > TOGGLE_COOLDOWN:
                        control_enabled = not control_enabled
                        last_toggle_time = now
                        stable_filter.clear()
                        motion.reset()
                        cursor.reset()
                        hold.reset()
                        print(f"[TLETL] Control: {'ON' if control_enabled else 'OFF'}")
                else:
                    hold.reset()

                # ==========================
                # CAMBIAR MODO CON TRES DEDOS
                # ==========================
                if control_enabled and stable_gesture == "THREE":
                    mode_progress = mode_hold.progress("THREE", MODE_HOLD_SECONDS)
                    if mode_progress >= 1.0 and now - last_mode_time > 1.0:
                        # Si estabas arrastrando, suelta antes de cambiar modo.
                        if drag_active:
                            actions.mouse_up_left()
                            drag_active = False
                            pinch_active = False
                        mode_index = (mode_index + 1) % len(modes)
                        last_mode_time = now
                        stable_filter.clear()
                        motion.reset()
                        cursor.reset()
                        mode_hold.reset()
                        print(f"[TLETL] Modo: {modes[mode_index]}")
                else:
                    mode_hold.reset()

                # ==========================
                # PAUSA DE SEGURIDAD
                # ==========================
                if stable_gesture == "FIST" and control_enabled and now - last_fist_time > FIST_COOLDOWN:
                    if drag_active:
                        actions.mouse_up_left()
                    drag_active = False
                    pinch_active = False
                    control_enabled = False
                    last_fist_time = now
                    stable_filter.clear()
                    motion.reset()
                    cursor.reset()
                    print("[TLETL] Pausa de seguridad. Control OFF.")

                # ==========================
                # ACCIONES POR MODO
                # ==========================
                if control_enabled:
                    mode = modes[mode_index]
                    swipe = motion.swipe()

                    if mode == "NAVEGADOR":
                        cursor.reset()

                        if stable_gesture == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab_time > TAB_ACTION_COOLDOWN:
                            if swipe == "RIGHT":
                                print("[TLETL] Siguiente pestaña")
                                actions.next_tab()
                            else:
                                print("[TLETL] Pestaña anterior")
                                actions.previous_tab()
                            last_tab_time = now
                            stable_filter.clear()

                        elif stable_gesture == "OPEN_PALM" and swipe in {"LEFT", "RIGHT"} and toggle_progress < 0.75 and now - last_tab_time > TAB_ACTION_COOLDOWN:
                            if swipe == "LEFT":
                                print("[TLETL] Atrás navegador")
                                actions.browser_back()
                            else:
                                print("[TLETL] Adelante navegador")
                                actions.browser_forward()
                            last_tab_time = now
                            stable_filter.clear()

                        elif stable_gesture == "POINT" and center_y is not None and now - last_action_time > ACTION_COOLDOWN:
                            if center_y < EXTREME_UP_ZONE:
                                print("[TLETL] PageUp")
                                actions.page_up()
                                last_action_time = now + 0.22
                            elif center_y > EXTREME_DOWN_ZONE:
                                print("[TLETL] PageDown")
                                actions.page_down()
                                last_action_time = now + 0.22
                            elif center_y < UP_ZONE:
                                print("[TLETL] Scroll arriba")
                                actions.scroll_up_small()
                                last_action_time = now
                            elif center_y > DOWN_ZONE:
                                print("[TLETL] Scroll abajo")
                                actions.scroll_down_small()
                                last_action_time = now

                        elif action_gesture == "PINCH" and now - last_pinch_time > 0.40:
                            print("[TLETL] Click izquierdo")
                            actions.click_left()
                            last_pinch_time = now
                            stable_filter.clear()

                    elif mode == "CURSOR":
                        # POINT/PALMA/PINZA mueven el cursor. Pinza permite click o arrastrar.
                        if action_gesture in {"POINT", "OPEN_PALM", "PINCH"} and center_x is not None and center_y is not None:
                            dx, dy = cursor.update(center_x, center_y)
                            if dx or dy:
                                actions.mousemove_relative(dx, dy)
                                cursor_info = f"Mouse dx={dx} dy={dy}"
                        else:
                            cursor.reset()

                        # Pinza corta = click. Pinza sostenida = arrastrar/seleccionar.
                        if action_gesture == "PINCH":
                            if not pinch_active:
                                pinch_active = True
                                pinch_started_at = now
                            if not drag_active and now - pinch_started_at >= DRAG_START_SECONDS:
                                print("[TLETL] Drag ON / seleccionar")
                                actions.mouse_down_left()
                                drag_active = True
                        else:
                            if pinch_active:
                                held = now - pinch_started_at
                                if drag_active:
                                    print("[TLETL] Drag OFF / soltar")
                                    actions.mouse_up_left()
                                elif held <= CLICK_MAX_SECONDS and now - last_pinch_time > 0.25:
                                    print("[TLETL] Click izquierdo")
                                    actions.click_left()
                                    last_pinch_time = now
                                pinch_active = False
                                drag_active = False

                        if stable_gesture == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab_time > TAB_ACTION_COOLDOWN:
                            # Atajo cómodo: incluso en cursor puedes cambiar pestaña.
                            if swipe == "RIGHT":
                                actions.next_tab()
                                print("[TLETL] Siguiente pestaña")
                            else:
                                actions.previous_tab()
                                print("[TLETL] Pestaña anterior")
                            last_tab_time = now
                            stable_filter.clear()

                    elif mode == "VENTANAS":
                        cursor.reset()

                        if stable_gesture == "VICTORY" and swipe in {"LEFT", "RIGHT"} and now - last_tab_time > TAB_ACTION_COOLDOWN:
                            if swipe == "RIGHT":
                                print("[TLETL] Ventana siguiente / Alt+Tab")
                                actions.alt_tab()
                            else:
                                print("[TLETL] Ventana anterior / Alt+Shift+Tab")
                                actions.alt_shift_tab()
                            last_tab_time = now
                            stable_filter.clear()

                        elif stable_gesture == "OPEN_PALM" and swipe == "UP" and now - last_overview_time > 1.0:
                            print("[TLETL] Overview GNOME / Super")
                            actions.overview()
                            last_overview_time = now
                            stable_filter.clear()

                        elif action_gesture == "PINCH" and now - last_pinch_time > 0.40:
                            print("[TLETL] Enter")
                            actions.enter()
                            last_pinch_time = now
                            stable_filter.clear()

                        elif stable_gesture == "FIST" and now - last_pinch_time > 0.65:
                            actions.escape()
                            last_pinch_time = now

            else:
                # Si pierdes la mano y estabas arrastrando, suelta el mouse para no dejarlo pegado.
                if drag_active:
                    actions.mouse_up_left()
                drag_active = False
                pinch_active = False
                smoother.reset()
                stable_filter.clear()
                motion.reset()
                cursor.reset()
                hold.reset()
                mode_hold.reset()

            draw_zones(frame)

            status = "ON" if control_enabled else "OFF"
            color = (0, 255, 0) if control_enabled else (0, 0, 255)
            mode = modes[mode_index]

            lines = [
                f"TLETL CONTROL V3.4 INTUITIVO: {status} | MODO: {mode} | FPS: {fps:.1f}",
                f"Raw: {raw_gesture} | Stable: {stable_gesture} | Acción: {action_gesture} | Conf: {confidence:.2f} | {source}",
                f"Dedos: {finger_debug} | Hand: {handedness}",
                "Palma hold=ON/OFF | Tres dedos hold=modo | Puño=pausa | Q=salir",
            ]

            if mode == "NAVEGADOR":
                lines.append("NAVEGADOR: índice=scroll | victoria swipe=tabs | palma swipe=atrás/adelante | pinza=click")
            elif mode == "CURSOR":
                drag_txt = "DRAG ACTIVO" if drag_active else "pinza corta=click, pinza sostenida=arrastrar/seleccionar"
                lines.append(f"CURSOR: índice/palma mueve mouse | {drag_txt}")
                if cursor_info:
                    lines.append(cursor_info)
            else:
                lines.append("VENTANAS: victoria swipe=Alt+Tab | palma swipe arriba=overview | pinza=Enter")

            if center_y is not None and center_x is not None:
                zone = "EXTREMO ARRIBA" if center_y < EXTREME_UP_ZONE else "ARRIBA" if center_y < UP_ZONE else "EXTREMO ABAJO" if center_y > EXTREME_DOWN_ZONE else "ABAJO" if center_y > DOWN_ZONE else "CENTRO"
                lines.append(f"Zona mano: {zone} | x={center_x:.2f} y={center_y:.2f}")

            if toggle_progress > 0:
                lines.append(f"Mantén palma para toggle: {int(toggle_progress * 100)}%")
            if mode_progress > 0:
                lines.append(f"Mantén tres dedos para cambiar modo: {int(mode_progress * 100)}%")

            draw_text_box(frame, lines, font_scale=0.52)
            cv2.circle(frame, (frame.shape[1] - 45, 45), 20, color, -1)

            if toggle_progress > 0:
                draw_progress_bar(frame, toggle_progress, y_offset=72)
            if mode_progress > 0:
                draw_progress_bar(frame, mode_progress, y_offset=105)

            cv2.imshow(APP_NAME, frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                if drag_active:
                    actions.mouse_up_left()
                break

    cap.release()
    cv2.destroyAllWindows()
    print("[TLETL] Cerrado.")

# ============================================================
# ARGUMENTOS
# ============================================================

def build_arg_parser():
    parser = argparse.ArgumentParser(description=APP_NAME)

    parser.add_argument(
        "--calibrate",
        action="store_true",
        help="Inicia calibración personalizada de gestos."
    )

    parser.add_argument(
        "--profile",
        default=DEFAULT_PROFILE_PATH,
        help=f"Ruta del perfil JSON. Default: {DEFAULT_PROFILE_PATH}"
    )

    parser.add_argument(
        "--camera",
        type=int,
        default=0,
        help="Índice de cámara. Si falla, prueba 1 o 2."
    )

    parser.add_argument("--width", type=int, default=CAMERA_WIDTH)
    parser.add_argument("--height", type=int, default=CAMERA_HEIGHT)
    parser.add_argument("--fps", type=int, default=CAMERA_FPS)

    parser.add_argument("--det-conf", type=float, default=MIN_DETECTION_CONFIDENCE)
    parser.add_argument("--track-conf", type=float, default=MIN_TRACKING_CONFIDENCE)
    parser.add_argument("--model-complexity", type=int, default=MODEL_COMPLEXITY)

    parser.add_argument(
        "--seconds",
        type=float,
        default=6.0,
        help="Segundos de captura por gesto durante calibración."
    )

    parser.add_argument(
        "--countdown",
        type=float,
        default=2.0,
        help="Cuenta regresiva antes de capturar cada gesto."
    )

    parser.add_argument(
        "--min-samples",
        type=int,
        default=30,
        help="Mínimo de muestras aceptadas por gesto."
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="No manda teclas reales; solo imprime acciones."
    )

    parser.add_argument(
        "--smoothing",
        type=float,
        default=SMOOTHING_ALPHA,
        help="Suavizado de landmarks. Menor = más estable, mayor = más rápido."
    )

    parser.add_argument(
        "--history",
        type=int,
        default=GESTURE_HISTORY_SIZE,
        help="Frames usados para confirmar gesto estable."
    )

    parser.add_argument(
        "--stable-count",
        type=int,
        default=STABLE_GESTURE_MIN_COUNT,
        help="Cuántos frames del historial deben coincidir."
    )

    parser.add_argument(
        "--cursor-gain",
        type=int,
        default=CURSOR_GAIN,
        help="Sensibilidad del mouse en modo CURSOR. Más alto = se mueve más rápido."
    )

    parser.add_argument(
        "--cursor-max-step",
        type=int,
        default=CURSOR_MAX_STEP,
        help="Máximo movimiento por frame del mouse. Más bajo = menos brusco."
    )

    return parser


def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    try:
        if args.calibrate:
            calibrate(args)
        else:
            run_control(args)
    except KeyboardInterrupt:
        print("\n[TLETL] Interrumpido por teclado.")
    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        print("Tip: si la cámara falla, prueba --camera 1. Si MediaPipe falla, revisa que estés en Python 3.12.")


if __name__ == "__main__":
    main()
